"""Plot independently evaluated common-environment risks for two fixed batches."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
with (ROOT/'experiments_v2'/'stretch_summary.csv').open(encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'font.size':10,'axes.titlesize':11,'axes.labelsize':10,'legend.fontsize':10,
    'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,
    'pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':'tight'})
laws=('Inverse square root','Uniform scales','Deterministic longest')
fig,axes=plt.subplots(1,3,figsize=(7.1,2.65))
for ax,law in zip(axes,laws):
    for mi,method in enumerate(('Revealed-stretch MOSS','MC-MOSS')):
        data=sorted([r for r in rows if r['law']==law and r['method']==method],key=lambda r:int(r['m']))
        x=np.array([int(r['m']) for r in data])
        mean=np.array([float(r['regret_over_W']) for r in data])
        error=np.array([1.96*float(r['mc_se'])/float(r['W']) for r in data])
        ax.errorbar(x,mean,yerr=error,marker='s' if mi==0 else 'o',color=('#D55E00','#0072B2')[mi],
                    capsize=2,ms=4,label=method)
    ratio=np.array([float(r['expected_capacity'])/float(r['W']) for r in data])
    ax.plot(x,ratio,'--',color='.45',marker='x',ms=4,label=r'$\mathbb{E}\,\mathcal{C}/W$ (geometry)')
    ax.set_title(law)
    ax.set_xlabel('$m$')
    ax.set_xticks(x)
    ax.set_ylim(bottom=0)
axes[0].set_ylabel('Regret / $W$, or\nexpected capacity / $W$')
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.54,-.045),ncol=3,frameon=False)
fig.tight_layout(rect=(0,.12,1,1),w_pad=1.7)
for ext in ('pdf','png'):
    fig.savefig(ROOT/'figures_v2'/f'fig_stretch_heldout.{ext}',dpi=300)
print('Wrote fig_stretch_heldout.pdf and .png')
