"""Figures and manuscript numbers for the completed random-arrival study."""
from pathlib import Path
import csv
import json
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'experiments_v2'
OUT=ROOT/'figures_v2'
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],'font.size':10,'axes.titlesize':11,'axes.labelsize':10,'legend.fontsize':10,'legend.frameon':False,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})

def rows(name):
    return list(csv.DictReader((DATA/name).open(encoding='utf-8')))

def save(fig,stem):
    fig.savefig(OUT/(stem+'.pdf'),bbox_inches='tight')
    fig.savefig(OUT/(stem+'.png'),dpi=220,bbox_inches='tight')
    plt.close(fig)

def main():
    archive=np.load(DATA/'random_raw.npz')
    ms=sorted(int(k.split('_')[0][1:]) for k in archive.files if k.endswith('_test'))
    m=max(ms); a=archive[f'm{m}_test']; env=archive[f'm{m}_gaps_signs']; hs=archive[f'm{m}_lifetimes']
    fig,axes=plt.subplots(1,2,figsize=(7.0,3.0),sharex=True,sharey=True,constrained_layout=True)
    chosen=np.flatnonzero(env[:,1]==1)
    fields=[a[:,:,:,method][:,chosen,:].mean(axis=2)/np.sqrt(hs[:,None]) for method in range(2)]
    norm=Normalize(0,max(float(x.max()) for x in fields))
    for method,ax in enumerate(axes):
        im=ax.imshow(fields[method],origin='lower',aspect='auto',cmap='viridis',norm=norm,extent=[-0.25,len(chosen)*.5-.25,-.5,m+.5])
        ax.plot(np.arange(m+1),np.arange(m+1),'w--',lw=1,label=r'$H\Delta^2=1/4$')
        ax.set(xlabel=r'$-\log_2(2\Delta)$',title=['Fresh-H MOSS: known endpoint','MC-MOSS: retained prefix'][method])
        ax.set_xticks(np.arange(0,len(chosen)*.5,2))
        ax.legend(loc='upper left',labelcolor='white',fontsize=10)
    axes[0].set_ylabel(r'Lifetime scale $j$, $H=4^j$')
    fig.colorbar(im,ax=axes,label=r'Held-out mean regret / $\sqrt{H}$',shrink=.82,pad=.03)
    save(fig,'random_gap_heatmap')
    selected=rows('random_selected_risks.csv')
    fig,axes=plt.subplots(1,2,figsize=(7.0,2.9),sharex=True)
    for method,ax in enumerate(axes):
        prefix=['Fresh','MC-'][method]
        for criterion,color,marker,label in [('common_fixed_environment','#0072B2','o','One environment across schedules'),('schedule_specific_environment','#D55E00','s','Environment chosen by schedule')]:
            data=sorted([r for r in selected if r['law']=='inverse_sqrt' and r['selection']==criterion and r['method'].startswith(prefix)],key=lambda r:int(r['m']))
            ax.errorbar([int(r['m'])+1 for r in data],[float(r['mean_regret']) for r in data],yerr=[1.96*float(r['mc_se']) for r in data],color=color,marker=marker,capsize=2,label=label)
        basic=sorted([r for r in selected if r['law']=='inverse_sqrt' and r['selection']=='common_fixed_environment' and r['method'].startswith(prefix)],key=lambda r:int(r['m']))
        ax.plot([int(r['m'])+1 for r in basic],[float(r['W']) for r in basic],':',color='#009E73',label=r'$W(Q)$ (geometry)')
        ax.plot([int(r['m'])+1 for r in basic],[float(r['expected_capacity']) for r in basic],'--',color='#777777',label=r'$E\sqrt{H}$ (geometry)')
        ax.set(xlabel='Number of lifetime scales',title=['Fresh-H MOSS: known endpoint','MC-MOSS: unknown endpoint'][method])
        ax.grid(alpha=.15)
    axes[0].set_ylabel('Regret or geometric reference')
    axes[0].legend(fontsize=10)
    fig.tight_layout()
    save(fig,'random_common_gap')
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.1),sharey=True)
    laws=['short_concentrated','inverse_sqrt','uniform_scales','two_long_scales','deterministic_long']
    labels=['Short','Inverse sqrt','Uniform','Two long','One long']
    for method,ax in enumerate(axes):
        prefix=['Fresh','MC-'][method]
        for criterion,color,shift,label in [('common_fixed_environment','#0072B2',-.13,'Common environment'),('schedule_specific_environment','#D55E00',.13,'Schedule-specific environment')]:
            data=[next(r for r in selected if int(r['m'])==m and r['law']==law and r['selection']==criterion and r['method'].startswith(prefix)) for law in laws]
            x=np.arange(len(laws))+shift
            ax.errorbar(x,[float(r['regret_over_W']) for r in data],yerr=[1.96*float(r['mc_se'])/float(r['W']) for r in data],fmt='o',color=color,capsize=2,label=label)
        ax.set_xticks(np.arange(len(laws)),labels,rotation=25,ha='right')
        ax.set_title(['Fresh-H MOSS: known endpoint','MC-MOSS: unknown endpoint'][method])
        ax.grid(axis='y',alpha=.15)
    axes[0].set_ylabel(r'Held-out mean regret / $W(Q)$')
    axes[0].legend(fontsize=7)
    fig.tight_layout()
    save(fig,'random_mixture_comparison')
    # Exact numerical values used in the narrative, always regenerated from CSV.
    focused=[r for r in selected if int(r['m'])==m and r['law']=='inverse_sqrt']
    fresh=[r for r in focused if r['method'].startswith('Fresh')]
    common=next(r for r in fresh if r['selection']=='common_fixed_environment')
    by_schedule=next(r for r in fresh if r['selection']=='schedule_specific_environment')
    tex=r'''\subsection{A common environment across random arrival scales}\label{sec:experiment-random}
The third study holds the two reward means fixed before drawing the
arrival schedule. At $T=4^m$, $m=4,5,6,7$, the competing arm has lifetime
$H=4^J$, $J=0,\ldots,m$. We consider probabilities proportional to
$2^{-J}$, uniform scale probabilities, probabilities proportional to
$4^{-J}$, an equal mixture of the last two scales, and a point mass at
the last scale. The anchor mean is $1/2$; the competitor mean is
$1/2\pm\Delta$, with $\Delta=2^{-1-r/2}$, $r=0,\ldots,2m+2$.

One rule starts a fresh two-arm MOSS run with the remaining horizon
revealed by the known endpoint. The other is the original MC-MOSS,
which does not know the endpoint and retains all anchor observations.
Their panels specify this information difference. We simulate the
forced prefix exactly through its binomial sufficient statistic.

We use 64 development replications to select a single gap and sign
for each mixture, or a separate gap and sign for each lifetime.
Both selections are then evaluated on 128 independent replications per
lifetime. Mixture means use the known schedule probabilities, with
stratified Monte Carlo standard errors. A separate check draws 2048
actual schedules for each selected common environment. These are
held-out risks of development-selected members of a finite grid, not
estimates of the full minimax risk or of a continuous supremum.

Figure~\ref{fig:random-heatmap} shows the conditional risk of a better
arriving competitor. The difficult gap changes with the remaining
lifetime. The retained prefix changes this surface, so the two panels
also differ for reasons beyond endpoint information alone.
Figure~\ref{fig:random-common} then averages over the inverse-square-root
mixture. At the largest endpoint, fresh-horizon MOSS has held-out mean
regret COMMON (standard error COMMONSE) under the selected common
environment, compared with ADAPTIVE (ADAPTIVESE) when the selected
environment is allowed to depend on the schedule. The corresponding
geometric values are $W(Q)=WVAL$ and $\mathbb E\sqrt H=CVAL$.
The latter curve is an arrival-only reference, not an observed risk.

The remaining mixtures, direct schedule draws and selected gaps are
reported in the computational supplement. For the two-long-scale
mixture the held-out ordering is reversed: development selection can
miss the best grid member. Independent evaluation removes reuse of
selection noise from the reported means; it does not make finite-grid
selection exact. None of these finite experiments estimates an
asymptotic rate or establishes that the anytime policy attains the
random-template theorem.

\begin{figure}[t]
\centering
\includegraphics[width=\textwidth]{figures_v2/random_gap_heatmap.pdf}
\caption{Held-out regret divided by $\sqrt H$ for a better arriving
competitor at $T=16384$. Each cell uses 128 replications. The dashed
line marks $H\Delta^2=1/4$; it is a scale reference, not a fitted ridge.
The policies differ in endpoint knowledge and retention of the forced
anchor prefix.}\label{fig:random-heatmap}
\end{figure}
\begin{figure}[t]
\centering
\includegraphics[width=\textwidth]{figures_v2/random_common_gap.pdf}
\caption{Common versus schedule-specific environments under
$\Pr(J=j)\propto2^{-j}$. Environments are selected on development
replications and evaluated independently. Bars are 1.96 stratified
Monte Carlo standard errors. The two geometric reference curves are
computed from the arrival law and are not risk estimates.}
\label{fig:random-common}
\end{figure}
'''
    values={'COMMON':float(common['mean_regret']),'COMMONSE':float(common['mc_se']),'ADAPTIVE':float(by_schedule['mean_regret']),'ADAPTIVESE':float(by_schedule['mc_se']),'WVAL':float(common['W']),'CVAL':float(common['expected_capacity'])}
    for key in sorted(values,key=len,reverse=True):
        tex=tex.replace(key,f'{values[key]:.3f}')
    (DATA/'random_results.tex').write_text(tex,encoding='utf-8')
    print('C figures and manuscript results generated.')

if __name__=='__main__':
    main()
