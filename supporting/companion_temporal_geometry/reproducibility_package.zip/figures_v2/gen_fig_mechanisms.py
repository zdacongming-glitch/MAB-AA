"""Generate all mechanism figures directly from released simulation CSV files."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'figures_v2'
EXP = ROOT/'experiments_v2'
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
    'font.size':10,'axes.titlesize':11,'axes.labelsize':10,'legend.fontsize':10,
    'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,
    'grid.alpha':.16,'lines.linewidth':1.1,'savefig.bbox':'tight',
    'pdf.fonttype':42,'ps.fonttype':42})
COLORS = ('#0072B2','#D55E00','#009E73','#CC79A7','#E69F00','#56B4E9')
CONFIGS = ('Near ties','Poor candidates','New record','Mixed late batch','Near upper bound')
HORIZONS = (2048,8192)


def read(name):
    with (EXP/name).open(encoding='utf-8') as f:
        return list(csv.DictReader(f))


def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'))
    fig.savefig(OUT/(name+'.png'),dpi=300)
    plt.close(fig)


def contrasts():
    data = read('mechanisms_paired.csv')
    labels = ['Global minus local; frozen','Global minus local; current',
              'Current minus frozen; local','Current minus frozen; global',
              'Cold minus retained']
    short = ['Clock | frozen','Clock | current','Capacity | local','Capacity | global','Discard history']
    fig,axes = plt.subplots(2,5,figsize=(7.4,4.0),sharey=True)
    for row,t in enumerate(HORIZONS):
        for col,config in enumerate(CONFIGS):
            ax = axes[row,col]
            for oi,order in enumerate(('Forward','Reverse batches')):
                selected = {r['contrast']:r for r in data if int(r['T'])==t and r['configuration']==config and r['order']==order}
                values = [float(selected[label]['mean_difference']) for label in labels]
                error = [1.96*float(selected[label]['paired_mc_se']) for label in labels]
                ax.errorbar(values,np.arange(5)+(.11 if oi else -.11),xerr=error,
                            fmt='s' if oi else 'o',ms=3,color=COLORS[oi],capsize=1.5,
                            label=order if row==0 and col==0 else None)
            ax.axvline(0,color='.5',lw=.8)
            if row==0:
                ax.set_title(config.replace(' ','\n',1) if config=='Near upper bound' else config)
            if col==0:
                ax.set_yticks(np.arange(5),short)
                ax.set_ylabel(f'$T={t:,}$')
            ax.tick_params(axis='x',labelsize=10)
            ax.locator_params(axis='x',nbins=3)
            ax.set_ylim(4.5,-.5)
    fig.supxlabel('Paired difference in mean pseudo-regret (positive favors local time, frozen capacity, or retained history)',fontsize=10,y=.02)
    fig.legend(loc='lower center',bbox_to_anchor=(.54,-.07),ncol=2,frameon=False)
    fig.tight_layout(rect=(0,.05,1,1),h_pad=1.1,w_pad=.65)
    save(fig,'fig_mechanisms_ablation')


def baselines():
    data = read('mechanisms_summary.csv')
    methods = ('MC-MOSS','Local/current','Global/frozen','Global/current','Cold MC','UCB1','AUER','KL-UCB','Thompson','Clipped MC')
    fig,axes = plt.subplots(2,1,figsize=(7.4,4.7))
    for ax,t in zip(axes,HORIZONS):
        selected = {(r['configuration'],r['method']):r for r in data if int(r['T'])==t and r['order']=='Forward'}
        values = np.array([[float(selected[c,m]['mean_regret']) for m in methods] for c in CONFIGS])
        ratio = values/values[:,0,None]
        # Log1p keeps the exact zero from clipping visible without a fabricated floor.
        color = np.log2(1+ratio)
        ax.imshow(color,cmap='cividis',vmin=0,vmax=3,aspect='auto')
        for i,c in enumerate(CONFIGS):
            for j,m in enumerate(methods):
                ax.text(j,i,f'{values[i,j]:.1f}',ha='center',va='center',fontsize=7.2,
                        color='white' if color[i,j]<1.2 else 'black')
        ax.set_xticks(np.arange(len(methods)),[m.replace('/','/\n').replace(' ','\n') for m in methods],fontsize=7.2)
        ax.set_yticks(np.arange(len(CONFIGS)),CONFIGS)
        ax.set_title(f'$T={t:,}$: mean pseudo-regret; forward batch labels',loc='left')
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(False)
    fig.text(.56,.007,'Cell values: raw regret. Shading: log2(1 + mean regret / MC-MOSS mean regret), capped at 3 within each row.',ha='center',fontsize=7.0)
    fig.tight_layout(rect=(0,.025,1,1),h_pad=1.4)
    save(fig,'fig_mechanisms_baselines')


def windows():
    data = read('mechanisms_windows.csv')
    methods = ('MC-MOSS','Global/frozen','Cold MC','KL-UCB','Thompson','Clipped MC')
    configs = ('Poor candidates','New record','Mixed late batch')
    fig,axes = plt.subplots(1,3,figsize=(7.2,2.55))
    for ax,config in zip(axes,configs):
        for mi,m in enumerate(methods):
            rows = [r for r in data if r['configuration']==config and r['method']==m and int(r['T'])==8192 and r['order']=='Forward']
            y,e,x = [],[],[]
            for wi in range(5):
                subset = [r for r in rows if int(r['window'])==wi]
                vals = np.array([float(r['regret']) for r in subset])
                length = int(subset[0]['end'])-int(subset[0]['start'])+1
                y.append(vals.mean()/length)
                e.append(1.96*vals.std(ddof=1)/np.sqrt(len(vals))/length)
                x.append((int(subset[0]['start'])+int(subset[0]['end']))/(2*8192))
            ax.errorbar(x,y,yerr=e,color=COLORS[mi],marker=('o','s','^','D','v','x')[mi],ms=3,capsize=1.5,label=m)
        ax.set_title(config)
        ax.set_xlabel('Window midpoint / $T$')
        ax.set_ylim(bottom=0)
    axes[0].set_ylabel('Regret per round in arrival window')
    fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.54,-.10),ncol=3,frameon=False)
    fig.tight_layout(rect=(0,.07,1,1),w_pad=1.4)
    save(fig,'fig_mechanisms_windows')


if __name__=='__main__':
    contrasts()
    baselines()
    windows()
    print('Wrote three mechanism figure pairs (vector PDF and 300 dpi PNG).')
