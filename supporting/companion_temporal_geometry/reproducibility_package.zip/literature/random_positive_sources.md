# 固定多批次公共伸缩结果：文献范围核查

核查日期：2026-10-13。本文只主张特定平稳奖励、共同环境与可揭示公共伸缩实验中的复杂度刻画；不主张随机 horizon、随机到达、MOSS、两点测试或弱尾量首次出现。检索和全文核查不构成穷尽的新颖性证明。

## 已核查的主要一手来源

1. Audibert and Bubeck (2009), *Minimax Policies for Adversarial and Stochastic Bandits*。[COLT 正文 PDF](https://www.learningtheory.org/colt2009/papers/022.pdf)。本轮核查 Figure 3 中固定 horizon MOSS 的指数形式以及 stochastic regret 分析。新证明使用这一成熟规则；实际所需的逐臂 gap 上界在 `random_positive_results.tex` 中重证，未将分布无关结果误当作逐 gap 结果。
2. Luo and Schapire (2014), *Towards Minimax Online Learning with Unknown Time Horizon*。[PMLR 原文](https://proceedings.mlr.press/v32/luo14.html)，[全文](https://proceedings.mlr.press/v32/luo14.pdf)。已核查 Section 2 的 adversarial full-information 游戏定义及 Section 4.1/Theorem 2：随机 horizon 对双方未知，basis-vector loss 子类下给出平均固定 horizon minimax 值的等式。其模型、反馈及信息结构与这里固定平稳奖励环境、首批揭示剩余日程的模型不同；不能只凭不同结论宣称推翻或改进该定理。
3. Ghalme et al., *Ballooning Multi-Armed Bandits*。[作者 arXiv 页面](https://arxiv.org/abs/2001.10055)，[全文](https://arxiv.org/pdf/2001.10055)。增长候选集合、随机到达和利用到达分布均已有先例。新结果不能以“加入随机到达”作为创新主张；这里的特定目标是相同有标签奖励环境必须跨随机伸缩共同承担困难时的可计算复杂度。
4. Jin et al. (2021), *Almost Optimal Anytime Algorithm for Batched Multi-Armed Bandits*。[PMLR 原文](https://proceedings.mlr.press/v139/jin21c.html)。核查 abstract 和正文引言：研究的是 unknown-horizon 的 batched feedback/decision 算法与 asymptotic optimality，本文的 batch 是新候选批次到达，非观测反馈批次。这篇检索命中不作为本定理的直接最近邻。

## 更早随机 horizon 线索的处理

主审发现 Gordon Simons 的 *A random horizon model for sequential clinical trials* 的 [NCSU 原始稿仓储条目](https://repository.lib.ncsu.edu/items/ddb93a7b-cda8-489f-8ccb-d6aed6856e49)。本子审打开条目遭到 bot 检测，未取得全文；目前不能据检索摘要确认其准确发表版本、目标损失或本结果是否已包含其中。因此将其列作需进一步核实的早期相关线索，不填入未经核实的期刊年份和页码，也不据此宣称优先权。

## 检索边界

本轮最后增加了两项邻近核查。Kleine Buening 等 (2023) 的 [AISTATS 正文](https://proceedings.mlr.press/v206/buening23a/buening23a.pdf) Section 2 理论设置主要固定有限时域；Section 4 讨论先验与策略博弈的值，Section 6.1 对几何折扣 Bernoulli bandit 使用 Gittins 指数探索最坏 Beta 先验。已检查部分不提供本稿公共伸缩分布的 $W(Q)$ 常数因子刻画。其一般 minimax–Bayes 思想和有限先验决策原则属于既有工具，不计作本稿新意。Novikov 与 Palacios-Soto (2020) 的 [作者上传原文](https://www.researchgate.net/publication/344211306_Sequential_hypothesis_tests_under_random_horizon) 及 [出版社卷期记录](https://www.tandfonline.com/toc/lsqa20/39/2?nav=tocList) 说明其目标是在错误概率约束下最小化平均样本量；到每个时刻仅获知随机终点是否已到。该序贯检验目标和信息结构不同于本稿的揭示伸缩 regret 问题。这里只核查其摘要、模型和目标部分，未完成所有定理的映射。出版社全文直接访问失败。以上均不构成排除所有等价结果的结论。

执行过 stochastic bandits/random horizon/minimax、horizon distribution、已知 horizon gap bound 等组合检索。没有找到明确陈述本文固定模板下

$$
W(Q)=\sup_{x\ge1}\frac{\mathbb E\min(H,x)}{\sqrt x}
$$

上下界的来源，但这只支持保守的当前检索判断。尾量 $\sup_h\sqrt h\,P(H\ge h)$ 本身是 $\sqrt H$ 的常见 weak-$L^1$ 型量，不是新概率范数。新证明的贡献边界在于其统计实验中的作用、合法共同环境下界、前缀 regret 完整记账、以及固定多批次模板上的统一于混合支持范围的结论。
