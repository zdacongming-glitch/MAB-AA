# JASA author and reproducibility requirements checked on 2026-10-13

This file is deliberately separate from the blinded literature evidence. It supplies preparation requirements, not an acceptance prediction or an innovation score.

## Official reproducibility guidance verified

The journal's reproducibility guide says invited revisions in both sections must supply code, data, and workflow. Initial submissions are encouraged, but not generally required by that guide, to include them. An Author Contributions Checklist (ACC) is required for reproducibility review. The accompanying package should separate the ACC PDF, other supplementary material such as proofs, and a single reproducibility archive. A Git repository alone does not ensure durable availability. [Official guide](https://jasa-acs.github.io/repro-guide/).

The author guidance states that, as of August 2026, authors are expected to review the reproducibility checklist before submitting reproducibility materials. The materials must explain data availability and document enough detail for reproduction; permanent repositories with DOIs are encouraged. Git-hosted materials should also be submitted as supplementary material if no permanent archive is used. [Official author guidance](https://jasa-acs.github.io/repro-guide/pages/author-guidelines.html).

The checklist requires an explanatory README, software/package versions, a clear directory structure, a mapping from scripts to figures/tables, execution order, output documentation, data access, and complete code for displayed simulations and competitors. Code should use relative paths. Seeds should be set where exact reproduction is intended. A master wrapper is strongly encouraged. Reproducibility scope must be justified if some results are excluded. Authors review the checklist but do not submit it as a separate completed form. [Official checklist](https://jasa-acs.github.io/repro-guide/pages/author-checklist.html).

## Consequences for the present draft

- Keep mathematical supplementary proofs separate from the code archive, and map each computational diagnostic to the claim it checks.
- Label finite numerical checks as diagnostics. They do not certify universal theorems or establish empirical superiority to baselines that were not run.
- Record actual seeds, dependencies, outputs, tested platform, command sequence, and runtime. Do not present a script that was not executed as a completed reproduction.
- A paper reporting no real-data analysis should state that its data are simulated/generated and give the generation code. Do not invent an application to satisfy a presumed journal preference.
- Prepare an ACC-compatible inventory; authors must ultimately verify contributions and submission declarations themselves.

## Author formatting access limitation

The official [instructions URL](https://www.tandfonline.com/action/authorSubmission?journalCode=uasa20&show=instructions) and [author-guidelines URL](https://www.tandfonline.com/journals/uasa20/author-guidelines) could not be fetched by the browser tool. The official [aims-and-scope URL](https://www.tandfonline.com/action/journalInformation?journalCode=uasa20&show=aimsScope) returned HTTP 403. Third-party summaries of page limits, abstract limits, keywords, and AI declarations were not adopted as verified journal policy. Therefore this audit does not certify current page/word limits or article formatting. A readable source draft with a separate supplement can be prepared now; final submission formatting should be checked against the accessible live journal instructions before submission.
