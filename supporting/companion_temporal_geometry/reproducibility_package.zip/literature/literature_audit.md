# Primary-source evidence audit

Frozen: 2026-10-13 (Asia/Shanghai). This evidence record contains no historical scores or venue ranking. It is a bounded literature search, not an exhaustive priority determination. The proposed mathematical results have not been certified by this literature audit.

## Scope and statistical target

The target problem has stationary independent bounded reward streams, deterministic exogenous arm arrivals, and permanent availability after arrival. At every deterministic horizon, risk is measured against the arm with the largest available mean. The proposed characterization fixes the entire arrival schedule before taking the minimax risk over reward distributions. The upper-bound policy does not receive the horizon or future arrivals. Finite batches, ties, and more arms than observations remain allowed.

The contribution to be compared is the constant-factor schedule-wise rate

$$
\mathscr S_T=\sum_{\ell}\min\{2^\ell,\sqrt{k_\ell2^\ell}\},
$$

where $k_\ell$ counts non-anchor arms with remaining lifetimes in dyadic group $\ell$. A second representation maximizes $\sum_i\min\{n_i,\sqrt{n_i}\}$ over feasible fractional occupancies. Further claims concern a history-preserving causal implementation, an $\ell_1$ versus $\ell_2$ explanation of a lifetime fixed point, and consequences of the characterization. These statements describe the object being compared; their proofs must be assessed separately.

## Checked closest primary works

### 1. Sleeping stochastic bandits

**Kleinberg, Niculescu-Mizil, and Sharma (2008 conference version; 2010 journal version).** Checked the author-hosted conference full text: Section 2 defines a fixed finite pool, availability sets and stochastic stationary rewards; the best ordering of means selects the best currently available arm. Section 3.2, Theorem 8 gives AUER regret at most $64\log T\sum_{j=1}^{n-1}(\mu_j-\mu_{j+1})^{-1}$ under strictly ordered means. The algorithm retains empirical counts. Thus the availability model, comparator, and use of history precede the present work. This theorem is expressed through adjacent mean gaps and worst-case availability, not the proposed minimax functional for each specified monotone schedule. **Verified difference:** the claimed schedule-wise matching rate is a different target; no claim that arriving arms or best-available regret are new is supportable. [Author full text](https://www.cs.cornell.edu/~rdk/papers/colt08.pdf).

### 2. Ballooning arms

**Ghalme, Dhamal, Jain, Gujar, and Narahari (2021).** Checked arXiv full text Sections 2–5, Theorem 1 and Algorithm 1. Arms persist after arrival; regret uses the best available arm. Theorem 1 constructs linear regret when one arm arrives per round and the best arm is uniformly located. BL-MOSS accepts an early collection and then stops accepting arms; its input includes $T$ and a parameter governing the best arm's arrival tail. Main sublinear guarantees impose sub-exponential or sub-Pareto arrival tails. Section 7 also treats arrival-rate restrictions, so the work must not be described as concerning only one particular prior. **Verified difference:** these are not the proposed constant-factor minimax bounds for every fixed arbitrary arrival schedule. The exact theorem numbering here is that of the arXiv version. [Full text](https://arxiv.org/pdf/2001.10055), [publisher record](https://www.sciencedirect.com/science/article/pii/S0004370221000369).

### 3. Fixed-pool MOSS

**Audibert and Bubeck (2009).** Checked full-text Figure 3 and Theorem 5. The index is the empirical mean plus $\sqrt{[\log(T/(Kn))]_+/n}$, with infinite index before a first pull. The theorem supplies the static bounded-reward bound $49\sqrt{KT}$; Remark 3 discusses a smaller constant with further tuning. **Verified difference:** a MOSS index and logarithm-free static minimax regret are established tools. The present claim requires additional arrival geometry and a compatible multi-scale lower bound. Neither changing the clock nor replacing $K$ by a current count alone establishes novelty or the claimed theorem. [Author/institution full text](https://www.microsoft.com/en-us/research/wp-content/uploads/2017/01/COLT09_AB.pdf).

### 4. Anytime MOSS and retained observations

**Degenne and Perchet (2016).** Checked Section 3 and Theorem 3. For a fixed set of $K$ arms, MOSS-anytime has, at their stated parameter, expected regret at most $113\sqrt{Kt}+\Delta_{\max}$ for every $t$, alongside a minimum-gap-dependent guarantee. It does not need a cold restart at each horizon doubling. **Verified difference:** horizon-free MOSS and retaining data are not independent new principles. The relevant proposed increment is their coexistence with the exact schedule-wise rate under an unknown growing action set, justified by a local full-history analysis. Any deterministic cold-restart separation must be described as a paired algorithm comparison, not superiority to all anytime algorithms. [PMLR record](https://proceedings.mlr.press/v48/degenne16.html), [Theorem 3](https://proceedings.mlr.press/v48/degenne16.pdf).

### 5. Nested allocation: direct structural overlap

**Vidal, Jaillet, and Maculan (2016).** Checked the author full text, problem (1.1)–(1.4) and Section 7, equations (7.1)–(7.4), Figure 7.1. The problem minimizes separable convex costs subject to upper bounds on partial sums. Section 7 obtains the allocation from a lower convex hull for shared-shape costs $f_i(x)=\gamma_i h(x/\gamma_i)$, using blockwise equal slopes and active partial-sum constraints. This is the same geometric mechanism as the proposed sorted-lifetime hull. Their displayed Section 7 derivation assumes strict convexity and differentiability, while the proposed clipped square-root objective has a corner and a linear segment. The latter can be handled by supergradients, but is not evidence of a new optimization framework. **Consequence:** attribute hull computation and nested allocation to established optimization; the proposed statistical contribution is the equivalence of that objective to the arriving-bandit minimax rate. [Author full text](https://www.mit.edu/~jaillet/general/RAP-LB-15.pdf), [published record](https://epubs.siam.org/doi/abs/10.1137/140965119).

**Vidal, Gribel, and Jaillet (2019; online 2018).** Checked publisher abstract and model (5)–(8). Their broader nested lower/upper allocation model explicitly allows convex costs that are neither strictly convex nor differentiable. This further rules out treating nonsmooth nested optimization itself as a new contribution. It does not establish the proposed bandit-risk equivalence. [Publisher record](https://pubsonline.informs.org/doi/abs/10.1287/ijoo.2018.0004), [model full text](https://pubsonline.informs.org/doi/pdf/10.1287/ijoo.2018.0004).

### 6. Other sleeping-regret notions

**Gaillard, Saha, and Dan (2023).** Checked the primary abstract and full-text Lemma 3 (including Appendix A.4). Sleeping internal regret implies an ordering-regret bound under i.i.d. losses, including availability sets depending on previous losses. This gives a general route to stochastic best-available comparison, and must not be omitted merely because the paper emphasizes adversarial settings. The checked result is a reduction between regret notions, not an exact fixed monotone-schedule minimax characterization. [PMLR record](https://proceedings.mlr.press/v206/gaillard23a.html), [Lemma 3](https://proceedings.mlr.press/v206/gaillard23a/gaillard23a.pdf).

**Nguyen and Mehta (2024).** Checked full-text Theorem 2: SB-EXP3 bounds expected per-action sleeping regret by $\log(G_T)/\eta+(\eta/2)\sum_t A_t$, hence a bound of order $\sqrt{\log(G_T)\sum_t A_t}$. Here $A_t$ is the number of active arms and $G_T$ the number ever active. The comparator is a fixed arm on the rounds it is active. This is not automatically the sum of regret against the best arm available in every round. **Verified difference:** the new claim cannot be established or refuted by comparing these displayed rates without a valid comparator reduction. [PMLR record](https://proceedings.mlr.press/v238/nguyen24d.html), [Theorem 2](https://proceedings.mlr.press/v238/nguyen24d/nguyen24d.pdf).

### 7. Useful boundaries checked at a narrower level

- **Lattimore (2015), The Pareto Regret Frontier for Bandits:** checked the author's arXiv record/abstract on nonuniform arm-wise regret tradeoffs. This prevents a claim that unequal exploration budgets are themselves new; no full theorem mapping to the proposed schedule functional was completed. [Primary record](https://arxiv.org/abs/1511.00048).
- **Ménard and Garivier (2017):** checked the PMLR record/abstract for kl-UCB++, which combines minimax and asymptotic optimality in static exponential-family bandits. An explicit but potentially loose gap upper bound is not an arriving-arm instance-optimality theorem. [Primary record](https://proceedings.mlr.press/v76/m%C3%A9nard17a.html).
- **Kaufmann, Cappé, and Garivier (2016):** checked JMLR publication metadata and abstract. It is an appropriate attribution for bandit information lower bounds; this audit did not re-prove or fully inspect its change-of-measure lemma. [Primary record](https://jmlr.org/papers/v17/kaufman16a.html).
- **Schneider and Zimmert (2024):** checked the arXiv abstract. Their cross-learning theorem gives nearly tight regret for sleeping bandits with i.i.d. action sets, via a contextual model with adversarial losses. The availability assumption differs from each fixed monotone arrival path. No full theorem mapping was completed. [Primary record](https://arxiv.org/abs/2401.01857).

## Strongest reasonable baseline and remaining uncertainty

A serious baseline is a natural all-history AUER or growing/anytime MOSS policy, analyzed using a sharper schedule decomposition. Existing static minimax kernels can be localized; elementary dyadic sums alone should not be counted as an independent conceptual advance. What needs to be judged is whether the complete proof establishes the exact additive complexity, in particular a single compatible hard family across scales while total means remain bounded, and a full-history causal upper bound without treating adaptively gathered old samples as conditionally fresh.

The nested-allocation computation substantially overlaps prior optimization geometry. Its role in identifying an observable schedule complexity may still add statistical content. A fixed-point versus spectral-norm identity is assessed relative to the project's own former fixed point, and should not be represented as the defeat of a universally accepted prior complexity if no such prior source is established.

Searches included arriving/ballooning/growing arms, sleeping stochastic minimax, arrival schedule, lifetime multiscale, anytime MOSS, and nested concave allocation/lower convex hull. Searches also returned the project's own public preprint; it was excluded as independent prior art. No checked primary source states the complete proposed schedule-wise constant-factor theorem or its entire chain of equivalent descriptions. This is a limited negative search finding, not proof of priority. Citation descendants, structured contextual reductions, and schedule-dependent sequential-complexity formulations have not been exhaustively covered. Novelty confidence should therefore remain bounded; proof correctness is a separate assessment.

## Bibliography use

The adjacent `references.bib` includes only real works verified through author, publisher, PMLR, JMLR, or arXiv records. An arXiv-only entry is intentionally used when full proceedings metadata was not checked. Exact theorem claims above identify the version actually inspected.
