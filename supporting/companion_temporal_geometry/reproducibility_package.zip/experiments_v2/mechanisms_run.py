"""Fixed-design clock/capacity ablations and Bernoulli baseline comparisons.

python mechanisms_run.py --replications 128 --seed 73061013
Development: --replications 2 --seed 41061013 --development
No parameters are selected from development or final regret values.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path
import numpy as np
import numba
from numba import njit
from scipy.optimize import brentq
from policies import METHODS, bernoulli_kl, kl_upper, choose, simulate

ROOT = Path(__file__).resolve().parent
CONFIGURATIONS = ('Near ties', 'Poor candidates', 'New record', 'Mixed late batch', 'Near upper bound')
HORIZONS = (2048, 8192)
ORDERS = ('Forward', 'Reverse batches')


def environment(configuration, horizon, order='Forward'):
    arrivals = np.r_[1, np.repeat([1, horizon//8+1, horizon//3+1,
                                  horizon//2+1, 3*horizon//4+1], [4,4,8,8,8])].astype(np.int64)
    means = np.zeros(33, dtype=np.float64)
    if configuration == 'Near ties':
        means[:] = .50
        means[0] = .52
        means[[4, 8, 16, 24, 32]] = .515
    elif configuration == 'Poor candidates':
        means[:] = .10 + .05*(np.arange(33) % 4)
        means[0] = .70
    elif configuration == 'New record':
        means[:] = .35
        means[0] = .45
        means[17] = .80
    elif configuration == 'Mixed late batch':
        means[:] = .40
        means[0] = .55
        means[25:] = [.15, .35, .52, .58, .62, .72, .48, .20]
    elif configuration == 'Near upper bound':
        means[:] = .94
        means[0] = 1.0
        means[[4, 8, 16, 24, 32]] = .985
    else:
        raise ValueError(configuration)
    physical = np.arange(33)
    if order == 'Reverse batches':
        # The designated initial anchor stays first in both labelings.
        for a in np.unique(arrivals):
            loc = np.flatnonzero((arrivals == a) & (physical != 0))
            physical[loc] = physical[loc][::-1]
        means = means[physical]
    return arrivals, means, physical


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


@njit(cache=True)
def beta_moments(a, b, seed, size):
    np.random.seed(seed)
    total = total2 = 0.0
    for _ in range(size):
        x = np.random.beta(a, b)
        total += x
        total2 += x*x
    return total/size, total2/size-(total/size)**2


def audit():
    sys.path.insert(0, str(ROOT.parent/'experiments'/'original_snapshot'))
    from mc_moss import MCMOSS
    rng = np.random.default_rng(51061013)
    maximum_error, kl_checks = 0.0, 0
    for p in np.r_[0., 1e-8, .01, .1, .5, .9, .99, 1-1e-8, 1.]:
        previous = p
        for budget in np.logspace(-7, 1, 21):
            got = float(kl_upper(float(p), float(budget)))
            assert p <= got <= 1.0 and got >= previous-1e-12
            previous = got
            if p in (0., 1.):
                expected = -math.expm1(-budget) if p == 0. else 1.
            elif bernoulli_kl(p, 1.-1e-15) <= budget:
                expected = 1.
            else:
                expected = brentq(lambda q: bernoulli_kl(p,q)-budget,
                                  p, 1.-1e-15, xtol=5e-15)
            maximum_error = max(maximum_error, abs(got-expected))
            assert abs(got-expected) < 3e-10
            kl_checks += 1
    api_checks, prefix_checks, replay_checks, tie_checks = 0, 0, 0, 0
    for case in range(6):
        tmax = 193
        arrivals = np.sort(np.r_[1, rng.integers(1,tmax+1,16)]).astype(np.int64)
        means = rng.uniform(.01,.99,len(arrivals))
        uniforms = rng.random(tmax)
        for method in range(len(METHODS)):
            r, pulls, actions, cumulative = simulate(arrivals,means,tmax,method,uniforms,51+case)
            short = 117
            present = arrivals <= short
            rr, nn, aa, cc = simulate(arrivals[present],means[present],short,method,uniforms[:short],51+case)
            assert np.array_equal(aa,actions[:short]) and np.array_equal(cc,cumulative[:short])
            assert np.all(arrivals[actions] <= np.arange(1,tmax+1))
            prefix_checks += 1
            r2,n2,a2,c2 = simulate(arrivals,means,tmax,method,uniforms,51+case)
            assert np.array_equal(actions,a2) and np.array_equal(cumulative,c2)
            replay_checks += 1
            if method in (0,4):
                policy = MCMOSS(cold_reset=(method==4))
                for tt in range(tmax):
                    selected = policy.select(np.flatnonzero(arrivals==tt+1).tolist())
                    assert selected == actions[tt]
                    policy.update(float(uniforms[tt]<means[selected]))
                    api_checks += 1
    # Independent factor check against the displayed index, on non-tied states.
    factor_checks = 0
    for _ in range(200):
        k, base, t, start = 10, 5, 100, 71
        n = rng.integers(1,30,k).astype(np.int64)
        sums = rng.binomial(n,.55).astype(np.float64)
        for method in range(4):
            clock = t if method in (2,3) else t-start+1
            capacity = 2*(k-1) if method in (1,3) else 2*base
            indices = sums/n + np.sqrt(np.maximum(0,np.log(clock/(capacity*n)))/n)
            selected,b,s = choose(n.copy(),sums.copy(),k,t,base,start,method)
            assert selected == int(np.argmax(indices)) and (b,s)==(base,start)
            factor_checks += 1
    for method in (0,1,2,3,4,5,6,7,9):
        selected,_,_ = choose(np.ones(4,dtype=np.int64),np.ones(4)*.5,4,12,3,1,method)
        assert selected == 0
        tie_checks += 1
    posterior = []
    for a,b in ((1.,1.),(3.,8.),(51.,7.)):
        avg,var = beta_moments(a,b,7654,100000)
        true_avg = a/(a+b)
        true_var = a*b/((a+b)**2*(a+b+1))
        assert abs(avg-true_avg) < 6*math.sqrt(true_var/100000)
        assert abs(var-true_var) < .004
        posterior.append({'alpha':a,'beta':b,'sample_mean':avg,'exact_mean':true_avg,
                          'sample_variance':var,'exact_variance':true_var})
    # With no earlier clocks and one initial batch, all four factors coincide.
    a,m,_ = environment('Near ties',257)
    a[:] = 1
    uniforms = rng.random(257)
    actions0 = simulate(a,m,257,0,uniforms)[2]
    for method in (1,2,3,4):
        assert np.array_equal(actions0,simulate(a,m,257,method,uniforms)[2])
    return dict(status='passed',kl_root_checks=kl_checks,kl_max_abs_error=maximum_error,
                original_mc_action_checks=api_checks,prefix_checks=prefix_checks,
                exact_replay_checks=replay_checks,factor_formula_checks=factor_checks,
                deterministic_tie_checks=tie_checks,initial_batch_factor_parity_checks=4,
                beta_posterior_checks=posterior)


def summary(raw):
    groups = {}
    for row in raw:
        key = (row['configuration'],row['T'],row['order'])
        groups.setdefault(key,{}) .setdefault(row['method'],[]).append(row['regret'])
    rows, differences = [], []
    comparisons = [('Global/frozen','MC-MOSS','Global minus local; frozen'),
                   ('Global/current','Local/current','Global minus local; current'),
                   ('Local/current','MC-MOSS','Current minus frozen; local'),
                   ('Global/current','Global/frozen','Current minus frozen; global'),
                   ('Cold MC','MC-MOSS','Cold minus retained'),
                   ('KL-UCB','MC-MOSS','KL-UCB minus MC'),
                   ('Thompson','MC-MOSS','Thompson minus MC'),
                   ('UCB1','MC-MOSS','UCB1 minus MC'),
                   ('AUER','MC-MOSS','AUER minus MC'),
                   ('Clipped MC','MC-MOSS','Clipped minus MC')]
    for (config,horizon,order), grouped in groups.items():
        arrays = {m:np.asarray(x) for m,x in grouped.items()}
        for method,values in arrays.items():
            rows.append(dict(configuration=config,T=horizon,order=order,method=method,
                             replications=len(values),mean_regret=float(values.mean()),
                             mc_se=float(values.std(ddof=1)/math.sqrt(len(values)))))
        for method,reference,label in comparisons:
            values = arrays[method]-arrays[reference]
            differences.append(dict(configuration=config,T=horizon,order=order,contrast=label,
                                    method=method,reference=reference,replications=len(values),
                                    mean_difference=float(values.mean()),
                                    paired_mc_se=float(values.std(ddof=1)/math.sqrt(len(values)))))
        interaction = arrays['Global/current']-arrays['Local/current']-arrays['Global/frozen']+arrays['MC-MOSS']
        differences.append(dict(configuration=config,T=horizon,order=order,contrast='Clock-capacity interaction',
                                method='Difference of differences',reference='Zero',replications=len(interaction),
                                mean_difference=float(interaction.mean()),
                                paired_mc_se=float(interaction.std(ddof=1)/math.sqrt(len(interaction)))))
    label_rows = []
    for config in CONFIGURATIONS:
        for horizon in HORIZONS:
            first = groups[(config,horizon,ORDERS[0])]
            second = groups[(config,horizon,ORDERS[1])]
            for method in METHODS:
                diff = np.asarray(second[method])-np.asarray(first[method])
                label_rows.append(dict(configuration=config,T=horizon,method=method,
                                       mean_reverse_minus_forward=float(diff.mean()),
                                       paired_mc_se=float(diff.std(ddof=1)/math.sqrt(len(diff)))))
    return rows,differences,label_rows


def run(replications, seed, development=False):
    started = time.perf_counter()
    result_audit = audit()
    directory = ROOT/'mechanisms_development' if development else ROOT
    directory.mkdir(exist_ok=True)
    raw, windows, environments = [], [], []
    rounds = 0
    design = dict(configurations=CONFIGURATIONS,horizons=HORIZONS,orders=ORDERS,
                  replications=replications,seed=seed,methods=METHODS,
                  choice='Fixed before regret simulation; no parameter selection.',
                  kl_ucb_c=0,beta_prior=[1,1],ucb_bonus_coefficients=[2,8])
    (directory/'mechanisms_design.json').write_text(json.dumps(design,indent=2),encoding='utf-8')
    for hi,horizon in enumerate(HORIZONS):
        for ci,config in enumerate(CONFIGURATIONS):
            for oi,order in enumerate(ORDERS):
                arrivals,means,physical = environment(config,horizon,order)
                for i in range(len(arrivals)):
                    environments.append(dict(configuration=config,T=horizon,order=order,label=i,
                                             physical_arm=int(physical[i]),arrival=int(arrivals[i]),mean=float(means[i])))
                ends = np.r_[np.unique(arrivals)[1:]-1,horizon]
                starts = np.r_[1,ends[:-1]+1]
                for rep in range(replications):
                    reward_seed = seed+1000000*hi+10000*ci+rep
                    policy_seed = seed+5000000+1000000*hi+10000*ci+rep
                    uniforms = np.random.default_rng(reward_seed).random(horizon)
                    for method_id,method in enumerate(METHODS):
                        r,pulls,actions,cumulative = simulate(arrivals,means,horizon,method_id,uniforms,policy_seed)
                        raw.append(dict(configuration=config,T=horizon,order=order,method=method,
                                        replication=rep,reward_seed=reward_seed,policy_seed=policy_seed,regret=r))
                        for wi,(lo,hiw) in enumerate(zip(starts,ends)):
                            prior = 0. if lo==1 else cumulative[lo-2]
                            windows.append(dict(configuration=config,T=horizon,order=order,method=method,
                                                replication=rep,window=wi,start=int(lo),end=int(hiw),
                                                regret=float(cumulative[hiw-1]-prior)))
                        rounds += horizon
                print(f'Completed {config}; T={horizon}; {order}; elapsed={time.perf_counter()-started:.1f}s',flush=True)
    results,paired,labels = summary(raw)
    for name,data in [('raw',raw),('windows',windows),('environments',environments),
                      ('summary',results),('paired',paired),('labels',labels)]:
        write_csv(directory/f'mechanisms_{name}.csv',data)
    manifest = dict(design=design,software_audit=result_audit,trajectories=len(raw),policy_rounds=rounds,
                    runtime_seconds=time.perf_counter()-started,python=platform.python_version(),
                    numpy=np.__version__,numba=numba.__version__,development=development,
                    source_sha256={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest()
                                   for f in ('policies.py','mechanisms_run.py')})
    (directory/'mechanisms_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps({k:manifest[k] for k in ('trajectories','policy_rounds','runtime_seconds','development')},indent=2),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--replications',type=int,default=128)
    parser.add_argument('--seed',type=int,default=73061013)
    parser.add_argument('--development',action='store_true')
    parser.add_argument('--audit-only',action='store_true')
    args = parser.parse_args()
    if args.audit_only:
        print(json.dumps(audit(),indent=2))
    elif args.replications < 2:
        parser.error('At least two replications are needed for Monte Carlo standard errors.')
    else:
        run(args.replications,args.seed,args.development)
