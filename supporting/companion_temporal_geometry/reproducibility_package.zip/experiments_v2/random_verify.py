"""Independent action-rule replay and reconstruction of experiment C outputs."""
from pathlib import Path
import json
import math
import sys
import csv

import numpy as np
from numba import njit

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'experiments/original_snapshot'))
from mc_moss import MCMOSS
from random_arrivals import cell, complexity


@njit
def inputs(t,h,reps,seed):
    np.random.seed(seed)
    prefixes = np.zeros(reps,dtype=np.int64)
    uniforms = np.zeros((reps,h))
    for r in range(reps):
        prefixes[r] = np.random.binomial(t-h,.5)
        for s in range(h):
            uniforms[r,s] = np.random.random()
    return prefixes,uniforms


def reference(t,h,mu1,prefix_success,uniforms):
    pi=MCMOSS()
    for s in range(t-h):
        pi.select([0] if s==0 else [])
        pi.update(1.0 if s<prefix_success else 0.0)
    n=[0,0]; sums=[0.0,0.0]; regrets=[0.0,0.0]
    means=[.5,mu1]
    for s,u in enumerate(uniforms):
        indices=[math.inf if count==0 else sums[i]/count+math.sqrt(max(0,math.log(h/(2*count)))/count) for i,count in enumerate(n)]
        a=0 if indices[0]>=indices[1] else 1
        regrets[0]+=max(means)-means[a]
        n[a]+=1; sums[a]+=float(u<means[a])
        a=pi.select(([0,1] if t==h else [1]) if s==0 else [])
        regrets[1]+=max(means)-means[a]
        pi.update(float(u<means[a]))
    return np.array(regrets)


def main():
    comparisons=0
    for t,h in [(1,1),(4,1),(4,4),(16,4),(16,16),(64,16),(64,64)]:
        for mu1 in [.1,.48,.5,.52,.9,1.0]:
            seed=700+t+h+round(mu1*100)
            prefixes,uniforms=inputs(t,h,12,seed)
            expected=np.array([reference(t,h,mu1,int(prefixes[r]),uniforms[r]) for r in range(12)])
            actual=cell(t,h,.5,mu1,12,seed)
            np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-12)
            comparisons+=12*2
    # Every stored grid summary is recomputed from the actual per-replicate arrays.
    archive=np.load(ROOT/'random_raw.npz')
    arrays={key:archive[key] for key in archive.files}
    rows=list(csv.DictReader((ROOT/'random_risk_grid.csv').open(encoding='utf-8')))
    for row in rows:
        m,j=int(row['m']),int(row['scale'])
        env=arrays[f'm{m}_gaps_signs']
        e=np.flatnonzero((np.abs(env[:,0]-float(row['gap']))<1e-14)&(env[:,1]==int(row['sign'])))[0]
        method=0 if row['method'].startswith('Fresh') else 1
        split='train' if row['split']=='development' else 'test'
        values=arrays[f'm{m}_{split}'][j,e,:,method]
        assert math.isclose(values.mean(),float(row['mean_regret']),abs_tol=1e-12)
        assert math.isclose(values.std(ddof=1)/math.sqrt(len(values)),float(row['mc_se']),abs_tol=1e-12)
    selected_rows=list(csv.DictReader((ROOT/'random_selected_risks.csv').open(encoding='utf-8')))
    from random_arrivals import mixture
    for row in selected_rows:
        m=int(row['m']); method=0 if row['method'].startswith('Fresh') else 1
        p=mixture(arrays[f'm{m}_lifetimes'],row['law'])
        train=arrays[f'm{m}_train'].mean(axis=2)[:,:,method]
        expected=np.full(m+1,int(np.argmax(p@train))) if row['selection']=='common_fixed_environment' else np.argmax(train,axis=1)
        recorded=np.array(list(map(int,row['selected_environment_indices'].split())))
        np.testing.assert_array_equal(expected,recorded)
        values=arrays[f'm{m}_test'][np.arange(m+1),expected,:,method]
        assert math.isclose(float(p@values.mean(axis=1)),float(row['mean_regret']),abs_tol=1e-12)
        assert math.isclose(math.sqrt(np.dot(p*p,values.var(axis=1,ddof=1))/values.shape[1]),float(row['mc_se']),abs_tol=1e-12)
    report=dict(status='passed',independent_reference_regret_replays=comparisons,raw_grid_summary_rows_reconstructed=len(rows),independently_selected_and_evaluated_rows=len(selected_rows),prefix_information='preserved exactly as counts and successes for MC; Fresh-H intentionally discards it')
    (ROOT/'random_verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
