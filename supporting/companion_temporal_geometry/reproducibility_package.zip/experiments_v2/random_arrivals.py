"""Experiment C: independent-arrival mixtures and held-out gap selection.

The policy receives only the currently available arms. Fresh-H MOSS knows
the terminal time and starts at the competing arm's arrival; MC-MOSS keeps
the entire anchor prefix and uses its local clock without a terminal time.
The simulator compresses the forced anchor-only prefix to one binomial draw.
All tuning is fixed before the development and held-out draws.
"""
from pathlib import Path
import argparse
import csv
import json
import math
import platform
import time

import numba
from numba import njit
import numpy as np

ROOT = Path(__file__).resolve().parent
METHODS = ['Fresh-H MOSS (known T)', 'MC-MOSS (unknown T)']


@njit(cache=True)
def cell(horizon, lifetime, mu0, mu1, replications, seed):
    np.random.seed(seed)
    result = np.zeros((replications, 2))
    prefix = horizon-lifetime
    for r in range(replications):
        n = np.zeros((2, 2), dtype=np.int64)
        sums = np.zeros((2, 2))
        n[1, 0] = prefix
        sums[1, 0] = np.random.binomial(prefix, mu0)
        for s in range(1, lifetime+1):
            u = np.random.random()
            for method in range(2):
                clock = lifetime if method == 0 else s
                chosen, best_index = 0, -np.inf
                for arm in range(2):
                    count = n[method, arm]
                    if count == 0:
                        index = np.inf
                    else:
                        index = sums[method, arm]/count + math.sqrt(max(0.0, math.log(clock/(2.0*count)))/count)
                    if index > best_index:
                        chosen, best_index = arm, index
                mu = mu0 if chosen == 0 else mu1
                result[r, method] += max(mu0,mu1)-mu
                n[method, chosen] += 1
                sums[method, chosen] += 1.0 if u < mu else 0.0
    return result


def mixture(lifetimes, name):
    j = np.arange(len(lifetimes))
    if name == 'inverse_sqrt':
        p = 2.0**(-j)
    elif name == 'uniform_scales':
        p = np.ones(len(j))
    elif name == 'short_concentrated':
        p = 4.0**(-j)
    elif name == 'two_long_scales':
        p = (j >= max(0,len(j)-2)).astype(float)
    elif name == 'deterministic_long':
        p = (j == len(j)-1).astype(float)
    else:
        raise ValueError(name)
    return p/p.sum()


def complexity(lifetimes, p):
    candidates = np.r_[1, lifetimes]
    values = np.array([np.dot(p,np.minimum(lifetimes,x))/math.sqrt(x) for x in candidates])
    return float(values.max()), int(candidates[values.argmax()])


def save_csv(name, rows):
    with (ROOT/name).open('w',newline='',encoding='utf-8') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def audit():
    # Horizon-one behavior checks both signs and the history contrast exactly.
    r = cell(4,1,.5,.75,20,101)
    assert np.all(r[:,0] == .25) and np.all(r[:,1] == 0)
    r = cell(4,1,.5,.25,20,101)
    assert np.all(r[:,0] == 0) and np.all(r[:,1] == .25)
    assert np.array_equal(cell(10,8,.5,.6,20,102),cell(10,8,.5,.6,20,102))
    assert np.all(cell(10,8,.5,.5,20,103) == 0)
    # For a deterministic H the truncation functional equals sqrt(H).
    for h in [1,4,16,100]:
        assert complexity(np.array([h]),np.array([1.0]))[0] == math.sqrt(h)
    return 8


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train',type=int,default=64)
    parser.add_argument('--test',type=int,default=128)
    parser.add_argument('--max-m',type=int,default=7)
    parser.add_argument('--seed',type=int,default=2026101303)
    parser.add_argument('--smoke',action='store_true')
    args = parser.parse_args()
    began = time.perf_counter()
    checks = audit()
    ms = [2] if args.smoke else list(range(4,args.max_m+1))
    names = ['inverse_sqrt','uniform_scales','short_concentrated','two_long_scales','deterministic_long']
    matrices, risks, mixtures, selections, joint_rows = {}, [], [], [], []
    trajectories = rounds = 0
    for m in ms:
        horizon = 4**m
        lifetimes = 4**np.arange(m+1,dtype=np.int64)
        gaps = .5*2.0**(-np.arange(2*m+3)/2)
        environments = [(float(gap),sign) for gap in gaps for sign in [-1,1]]
        train = np.zeros((m+1,len(environments),args.train,2))
        test = np.zeros((m+1,len(environments),args.test,2))
        for j,lifetime in enumerate(lifetimes):
            for e,(gap,sign) in enumerate(environments):
                # Separate streams for selection and final evaluation.
                for split, nrep, output, offset in [('development',args.train,train,0),('heldout',args.test,test,10000000)]:
                    seed = (args.seed+offset+100000*m+1000*j+e)%(2**32-1)
                    raw = cell(horizon,int(lifetime),.5,.5+sign*gap,nrep,seed)
                    output[j,e] = raw
                    trajectories += 2*nrep
                    rounds += 2*nrep*int(lifetime)
                    for method,label in enumerate(METHODS):
                        risks.append(dict(m=m,T=horizon,H=int(lifetime),scale=j,gap=gap,sign=sign,mu_anchor=.5,mu_competitor=.5+sign*gap,split=split,method=label,replications=nrep,mean_regret=raw[:,method].mean(),mc_se=raw[:,method].std(ddof=1)/math.sqrt(nrep),seed=seed))
        matrices[f'm{m}_train'] = train
        matrices[f'm{m}_test'] = test
        matrices[f'm{m}_gaps_signs'] = np.array(environments)
        matrices[f'm{m}_lifetimes'] = lifetimes
        train_mean = train.mean(axis=2)
        for law in names:
            p = mixture(lifetimes,law)
            w,xstar = complexity(lifetimes,p)
            expected_c = float(np.dot(p,np.sqrt(lifetimes)))
            for j,h in enumerate(lifetimes):
                mixtures.append(dict(m=m,T=horizon,law=law,scale=j,H=int(h),probability=p[j],W=w,maximizing_truncation=xstar,expected_capacity=expected_c,capacity_over_W=expected_c/w))
            for method,label in enumerate(METHODS):
                common = int(np.argmax(p@train_mean[:,:,method]))
                adaptive = np.argmax(train_mean[:,:,method],axis=1)
                for selection,indices in [('common_fixed_environment',np.full(m+1,common)),('schedule_specific_environment',adaptive)]:
                    selected = test[np.arange(m+1),indices,:,method]
                    means = selected.mean(axis=1)
                    est = float(p@means)
                    se = float(math.sqrt(np.dot(p*p,selected.var(axis=1,ddof=1))/args.test))
                    selections.append(dict(m=m,T=horizon,law=law,method=label,information='T known, H revealed at arrival' if method==0 else 'T and future arrivals unknown',selection=selection,mean_regret=est,mc_se=se,regret_over_W=est/w,regret_over_expected_capacity=est/expected_c,W=w,expected_capacity=expected_c,selected_environment_indices=' '.join(map(str,indices)),training_reps=args.train,test_reps=args.test))
                # A separate actual draw of the random schedule, for the selected
                # common environment only. No environment is selected after J.
                gap, sign = environments[common]
                gen = np.random.default_rng(args.seed+20000000+100000*m+1000*names.index(law)+method)
                n_joint = 2048 if not args.smoke else 32
                js = gen.choice(m+1,size=n_joint,p=p)
                random_values = np.empty(n_joint)
                for j in range(m+1):
                    positions = np.flatnonzero(js==j)
                    if len(positions):
                        v = cell(horizon,int(lifetimes[j]),.5,.5+sign*gap,len(positions),int(gen.integers(1,2**31)))
                        random_values[positions] = v[:,method]
                        trajectories += 2*len(positions)
                        rounds += 2*len(positions)*int(lifetimes[j])
                matrices[f'joint_m{m}_{law}_{method}'] = np.c_[js,random_values]
                joint_rows.append(dict(m=m,T=horizon,law=law,method=label,selection='development-selected common environment',gap=gap,sign=sign,random_schedule_replications=n_joint,mean_regret=random_values.mean(),mc_se=random_values.std(ddof=1)/math.sqrt(n_joint),W=w,expected_capacity=expected_c))
        print(f'Completed C: T={horizon}, scales={m+1}, gap/sign configurations={len(environments)}',flush=True)
    suffix = '_smoke' if args.smoke else ''
    save_csv('random_risk_grid'+suffix+'.csv',risks)
    save_csv('random_mixtures'+suffix+'.csv',mixtures)
    save_csv('random_selected_risks'+suffix+'.csv',selections)
    save_csv('random_joint_draws'+suffix+'.csv',joint_rows)
    np.savez_compressed(ROOT/('random_raw'+suffix+'.npz'),**matrices)
    manifest = dict(status='complete',design='fixed before final outcomes; disjoint development, held-out and direct-joint streams',seed=args.seed,train=args.train,test=args.test,ms=ms,methods=METHODS,mixtures=names,policy_trajectories=trajectories,post_arrival_policy_rounds=rounds,prefix_simulation='exact binomial compression of forced anchor observations, not a realized prefix trajectory',software_checks=checks,elapsed_seconds=time.perf_counter()-began,python=platform.python_version(),numpy=np.__version__,numba=numba.__version__,limitations='Finite gap grid; held-out evaluation of development-selected environments. No continuous supremum or minimax risk is estimated. Fresh-H deliberately discards the available prefix; MC keeps it.')
    (ROOT/('random_manifest'+suffix+'.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(manifest,indent=2))


if __name__ == '__main__':
    main()
