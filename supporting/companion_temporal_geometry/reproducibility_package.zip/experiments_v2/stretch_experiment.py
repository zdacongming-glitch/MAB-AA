"""Independent held-out check of the fixed two-batch stretch theorem.

Both policies face the same fixed reward vector across every possible stretch.
One environment per (m,Q) is selected from 64 development replications by the
informed policy's law-averaged risk, then evaluated on 128 independent final
replications for both policies.  H is enumerated with exact probability weights.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import time
import numpy as np
from numba import njit
from policies import choose, simulate

ROOT = Path(__file__).resolve().parent
MS = (3,4,5,6)
GAPS = np.array([.025,.05,.10,.20,.40])
SIGNS = (-1,1)
METHODS = ('Revealed-stretch MOSS','MC-MOSS')
LAWS = ('Inverse square root','Uniform scales','Deterministic longest')


@njit(cache=True)
def fixed_choose(n,sums,k,length):
    selected,maximum = 0,-np.inf
    for i in range(k):
        if n[i]==0:
            return i
        ratio = length/(k*n[i])
        index = sums[i]/n[i]+(math.sqrt(math.log(ratio)/n[i]) if ratio>1 else 0.)
        if index>maximum:
            selected,maximum=i,index
    return selected


@njit(cache=True)
def compressed_simulate(horizon,h,means,method,initial_successes,uniforms):
    """Retain the anchor's exact sufficient statistic before the first batch."""
    prefix = horizon-4*h
    n = np.zeros(5,dtype=np.int64)
    sums = np.zeros(5,dtype=np.float64)
    n[0],sums[0] = prefix,initial_successes
    base,start=0,0
    total=first=0.
    actions=np.empty(4*h,dtype=np.int64)
    for tt in range(4*h):
        k = 3 if tt<3*h else 5
        if method==0:
            if tt==0 or tt==3*h:
                n[:]=0
                sums[:]=0.
            selected=fixed_choose(n,sums,k,3*h if tt<3*h else h)
        else:
            selected,base,start=choose(n,sums,k,prefix+tt+1,base,start,0)
        reward=1. if uniforms[tt]<means[selected] else 0.
        n[selected]+=1
        sums[selected]+=reward
        best=max(means[:k])
        total+=best-means[selected]
        actions[tt]=selected
        if tt==3*h-1:
            first=total
    return total,first,total-first,actions


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)


def weights(law,m):
    if law==LAWS[0]:
        q=2.**(-np.arange(m+1));return q/q.sum()
    if law==LAWS[1]:
        return np.full(m+1,1/(m+1))
    q=np.zeros(m+1);q[-1]=1.;return q


def audit():
    rng=np.random.default_rng(655013)
    checked=0
    means=np.array([.5,.45,.55,.65,.5])
    for tmax in (64,256,1024):
        for h in (1,4,16):
            if 4*h>tmax:continue
            uniforms=rng.random(tmax)
            prefix=tmax-4*h
            arrivals=np.array([1,prefix+1,prefix+1,tmax-h+1,tmax-h+1],dtype=np.int64)
            reference=simulate(arrivals,means,tmax,0,uniforms)[2]
            got=compressed_simulate(tmax,h,means,1,int(np.sum(uniforms[:prefix]<.5)),uniforms[prefix:])[3]
            assert np.array_equal(got,reference[prefix:]);checked+=1
    # First arrival reveals H using only T and observed time.
    for m in MS:
        for j in range(m+1):
            tmax,h=4*4**m,4**j
            first=tmax-4*h+1
            assert (tmax-first+1)//4==h
    return dict(status='passed',compressed_prefix_action_parity_checks=checked,
                arrival_revelation_checks=sum(m+1 for m in MS))


def main():
    started=time.perf_counter();checks=audit()
    raw=[];arrays={};rounds=0
    for split,reps,seed in [('Development',64,841013),('Held out',128,951013)]:
        for m in MS:
            tmax=4*4**m
            values=np.zeros((len(GAPS),2,m+1,2,reps))
            for gi,gap in enumerate(GAPS):
                for si,sign in enumerate(SIGNS):
                    means=np.array([.5,.45,.55,.55+sign*gap,.5])
                    for j in range(m+1):
                        h=4**j;prefix=tmax-4*h
                        for rep in range(reps):
                            run_seed=seed+100000*m+1000*j+rep
                            rng=np.random.default_rng(run_seed)
                            successes=int(rng.binomial(prefix,.5))
                            uniforms=rng.random(4*h)
                            for mi,method in enumerate(METHODS):
                                regret,first,second,_=compressed_simulate(tmax,h,means,mi,successes,uniforms)
                                values[gi,si,j,mi,rep]=regret
                                raw.append(dict(split=split,m=m,T=tmax,gap=float(gap),sign=sign,
                                                scale=j,H=h,method=method,replication=rep,seed=run_seed,
                                                regret=regret,first_interval_regret=first,last_interval_regret=second))
                                rounds+=4*h
            arrays[split,m]=values
            print(f'Completed {split}; m={m}; elapsed={time.perf_counter()-started:.1f}s',flush=True)
    selected=[];summary=[];complexities=[]
    for m in MS:
        hs=4.**np.arange(m+1)
        for law in LAWS:
            q=weights(law,m)
            w=float(max(np.sum(q*np.minimum(hs,h))/math.sqrt(h) for h in hs))
            # Hull allocations are (3H/2,3H/2,H/2,H/2). At H=1 the last two use phi(x)=x.
            capacities=np.array([2*math.sqrt(1.5*h)+(2*math.sqrt(.5*h) if h>=2 else h) for h in hs])
            ec=float(q@capacities)
            dev=np.einsum('j,gsjmr->gsmr',q,arrays['Development',m]).mean(axis=-1)
            flat=int(np.argmax(dev[:,:,0]));gi,si=np.unravel_index(flat,(len(GAPS),2))
            selected.append(dict(m=m,law=law,gap=float(GAPS[gi]),sign=SIGNS[si],
                                  development_informed_mean=float(dev[gi,si,0]),
                                  selection_rule='Maximize law-averaged informed-policy development risk; one common environment for both policies and all schedules.'))
            risks=np.einsum('j,jmr->mr',q,arrays['Held out',m][gi,si])
            for mi,method in enumerate(METHODS):
                values=risks[mi]
                summary.append(dict(m=m,T=4*4**m,law=law,method=method,gap=float(GAPS[gi]),sign=SIGNS[si],
                                    replications=128,W=w,expected_capacity=ec,mean_regret=float(values.mean()),
                                    mc_se=float(values.std(ddof=1)/math.sqrt(128)),
                                    regret_over_W=float(values.mean()/w),regret_over_EC=float(values.mean()/ec),
                                    mean_MC_minus_informed=float((risks[1]-risks[0]).mean()),
                                    paired_mc_se=float((risks[1]-risks[0]).std(ddof=1)/math.sqrt(128))))
            complexities.append(dict(m=m,law=law,W=w,expected_sqrt_H=float(q@np.sqrt(hs)),expected_capacity=ec,capacity_over_W=ec/w))
    for name,rows in [('raw',raw),('selected',selected),('summary',summary),('complexities',complexities)]:
        write_csv(ROOT/f'stretch_{name}.csv',rows)
    # Check the exact capacity formula against the independent original hull implementation.
    import sys
    sys.path.insert(0,str(ROOT.parent/'experiments'/'original_snapshot'))
    from geometry import capacity
    for h in 4**np.arange(7):
        exact=capacity([int(4*h),int(4*h),int(h),int(h)],int(4*h))['C']
        formula=2*math.sqrt(1.5*h)+(2*math.sqrt(.5*h) if h>=2 else h)
        assert abs(exact-formula)<1e-10
    checks['capacity_formula_checks']=7
    manifest=dict(status='completed',template=dict(alpha=[4,1],batch_sizes=[2,2],K=5),
                  grid_gaps=GAPS.tolist(),grid_signs=list(SIGNS),m=list(MS),laws=list(LAWS),
                  development_replications=64,heldout_replications=128,raw_trajectories=len(raw),
                  simulated_policy_rounds=rounds,runtime_seconds=time.perf_counter()-started,
                  prefix='Binomial sufficient-statistic compression; zero regret before first batch. MC retains count and sum.',
                  comparison='Same development-selected gap and sign for both policies and all H; exact-law stratification, independent held-out rewards.',
                  audit=checks,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (ROOT/'stretch_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k in ('raw_trajectories','simulated_policy_rounds','runtime_seconds','audit')},indent=2))


if __name__=='__main__':main()
