# Experiment A: compatible finite-prior risk and exact Bayes reference

This experiment uses the academic-plotting data workflow, the stat-journal-writing evidence contract, and the prove-stat-ml-probability-theorems protocol. It evaluates actual bandit trajectories, rather than treating a plot of a deterministic complexity as observed risk.

## Frozen design and assumptions

- Endpoints: 1024, 4096, 16384, and 65536.
- Multiscale batches: $k_j=2\cdot4^j$ competitors and $H_j=T/4^j$, $j=0,\ldots,L-1$. Use $L=1,2,3$ for the first two endpoints, and $L=1,2,3,4$ for the latter two.
- Each multiscale schedule has a compressed partner with the same labeled arms and endpoint: the first $2L$ competitors arrive at time one and all remaining labels arrive at $T$. The $L=1$ schedules are identical and are not run twice.
- One common, finite, independent null/spike product prior is constructed by the manuscript's retained-scale selection. Reference levels depend on gap sizes only, never on latent configurations. Native prior details, every reference/candidate label, increment and test window are in `geometry_manifest.json`.
- Gap multipliers 1, 4, and 8 were specified before simulation. They are not selected by outcome. Multiplier 1 preserves the proof's conservative information constant. Multipliers 4 and 8 preserve a legal common stationary prior and compatibility, but no claim is made that the same total-variation constant holds.
- 128 independent replications; each replication resamples both latent means and rewards. Calendar reward uniforms are shared across methods, and across arrival schedules when crossing the same mean vector. A separate seed component identifies the native prior source.
- MC-MOSS and Cold MC share the same local clock, frozen capacity and label tie order. Clearing history at a clock reset is their only implementation difference.
- Every algorithm is causal and does not receive $T$, a future arrival, the prior or the true means. The simulator alone receives those quantities.
- No tuning or development instance was used. Root seed is 20261013041.

The primary multiplier is 4. For this multiplier, both source priors are crossed with both receiving schedules. These comparisons hold the labeled mean vector fixed while changing arrivals. Native-prior comparisons change both the schedule and the prior, and are explicitly labeled as such. Multipliers 1 and 8 run only the native-prior comparisons.

## Inference target and exclusions

For each specified finite prior and policy, the estimated target is the expectation of pseudo-regret over both the latent mean vector and reward observations. The estimator is the arithmetic mean of independent replications, with sample standard deviation divided by the square root of 128 as its Monte Carlo standard error. Paired contrasts use the standard deviation of the paired differences. Displayed error bars are 1.96 times this standard error.

These means are not estimates of the full minimax value, and confidence bars do not measure uncertainty about that value. No environment in a later scale is selected after viewing earlier data. There is no separate incompatible worst-case choice for each window.

Windows are those of the receiving schedule's native construction. Their loss is a diagnostic partition of a subset of the full horizon. Loss outside their union remains in the data and in the total; it is not discarded when reporting normalized risk. The figure's curves cover at most four effective scales and do not certify an asymptotic order separation.

## Exact small-instance reference

The Bayes reference is a separate finite decision problem with six labeled arms, six possible stationary Bernoulli environments, two gap choices, and $T=4,6,8,10$. Its complete rational means, prior probabilities and arrival times appear in `bayes_manifest.json`. The optimizing rule knows the full schedule and prior; MC-MOSS and Cold MC receive their ordinary information. This additional information is reported rather than hidden in a relative-performance claim.

For successes and failures $s$, let $p_e(s)$ be the exact finite-prior posterior, $q_i(s)$ the posterior predictive success probability and $g_t(i,s)$ the posterior expected one-step pseudo-regret. With $V_{T+1}=0$, the recursion is

$$
V_t(s)=\min_{i\in A_t}\{g_t(i,s)+q_i(s)V_{t+1}(s^{i,1})+[1-q_i(s)]V_{t+1}(s^{i,0})\}.
$$

The sufficient-state argument follows from the adaptive likelihood: the policy action kernels are identical functions of history in every environment and cancel, leaving the product of observed Bernoulli likelihoods. Conditional on this state, the next observation has the predictive law above. Backward induction then proves optimality, and randomized actions cannot improve a finite minimum. There are finitely many states, every posterior denominator is positive, and all inputs are rational. Python `fractions.Fraction` therefore computes every posterior, value and action comparison exactly. Known-mean arms do not change the posterior and may be omitted from its state.

For any policy, its worst reward-environment risk is at least its risk averaged over this prior. Infimizing gives the Bayes optimum as a lower bound for the deterministic-schedule minimax risk. The prior is not asserted to be least favorable. This is a complete finite decision calculation, not a new general minimax theorem.

Each returned optimal policy is independently integrated over each environment's full reward tree; its weighted risk equals the Bellman value exactly. The two numerical index policies are also integrated over their complete reward trees. Their action choices follow the specified numerical implementation, while their expected losses are exact fractions. All eight checks passed.

## Reproduction and outputs

From the reconstruction root, run:

```powershell
python -X utf8 experiments_v2/geometry_run.py --reps 128
python -X utf8 experiments_v2/bayes_exact.py
python -X utf8 experiments_v2/geometry_analyze.py
python -X utf8 experiments_v2/geometry_verify.py
```

`geometry_raw.csv` contains every replication; `geometry_environments.npz` contains every sampled labeled mean vector and latent configuration. Window-level data, schedule complexities, cell summaries and paired contrasts are separate CSV files. The three figures are exported as vector PDF and PNG previews. The run manifest records script hashes, seeds, environment information, counts and the full prior definitions.

The completed run contains 23,552 trajectories and 591,134,720 policy rounds. The exact benchmark covers eight cases, and its rational results are recorded in `bayes_exact_results.csv`. Files `geometry_results.tex` and `bayes_supplement.tex` contain manuscript-ready methods, results, the finite-prior recursion proof and qualifications.

## Findings and limits

At $T=65536$, $L=4$, both matched schedules have 171 total arms and fixed point 725. Their spectra are 1448.15 and 725.08. Under their respective native priors MC-MOSS has risk 146.67 (MCSE 3.00) and 87.57 (3.31). Crossing a common mean vector changes the comparison: compression reduces regret by 18.82 (paired MCSE 5.84) for the multiscale prior and by 185.04 (3.52) for the compressed prior. These are separate effects, not interchangeable evidence.

Cold MC is better by 5.92 (paired MCSE 1.38) on the largest native multiscale prior, but worse by 40.44 (2.00) for the compressed prior run on the multiscale schedule. The window contributions for MC-MOSS in the former case are 3.87, 9.59, 13.75 and 15.39, with 104.07 outside the windows. All positive window losses arise from one common stationary environment draw; their sum is not treated as the full loss.

The original small-gap constant yields small losses. The normalized curves agree fairly closely across endpoints at fixed effective scale count, but are not constant as the number of scales grows. This finite experiment supports the presence of simultaneous learning costs and illustrates what total count and the fixed point omit. It does not estimate an optimal minimax constant, prove the asymptotic separation, or establish uniform superiority of history retention.
