"""Audit saved experiment A data and replay selected trajectories independently."""
from __future__ import annotations
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import numpy as np
from geometry_run import schedules, SEED
from policies import simulate, METHODS

HERE=Path(__file__).resolve().parent


def read(name):
    with (HERE/name).open(newline="",encoding="utf-8") as f:return list(csv.DictReader(f))


def verify():
    manifest=json.loads((HERE/"geometry_manifest.json").read_text(encoding="utf-8"))
    raw=read("geometry_raw.csv")
    window=read("geometry_windows.csv")
    env=np.load(HERE/"geometry_environments.npz")
    assert len(raw)==manifest["trajectories"]
    assert sum(int(r["T"]) for r in raw)==manifest["total_policy_rounds"]
    for name in ("geometry_run.py","policies.py"):
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==manifest[name+"_sha256"],name
    means_checks=0
    for s in manifest["prior_specifications"]:
        vectors=env[s["id"]]
        states=env[s["id"]+"_latent"]
        assert len(vectors)==manifest["repetitions"]
        for v,latent in zip(vectors,states):
            expected=np.full(len(v),.25);expected[0]=.5
            for g,z in zip(s["groups"],latent):
                expected[g["reference"]]=g["theta"]
                expected[g["candidates"]]=g["theta"]-g["epsilon"]
                if z!=-1:
                    assert z in g["candidates"]
                    expected[z]=g["theta"]+g["epsilon"]
            assert np.array_equal(v,expected)
            assert np.all((0<v)&(v<1))
            means_checks+=1
    wlookup={}
    keys=("T","nominal_scales","schedule","prior_source","gap_multiplier","rep","method")
    for r in window:
        key=tuple(r[k] for k in keys)
        wlookup.setdefault(key,[]).append(r)
    for r in raw:
        ww=wlookup[tuple(r[k] for k in keys)]
        covered=sum(float(w["regret"]) for w in ww)
        assert abs(covered-float(r["window_regret"]))<1e-8
        assert abs(covered+float(r["outside_window_regret"])-float(r["regret"]))<1e-8
        intervals=sorted((int(w["start"]),int(w["end"])) for w in ww)
        assert all(a[1]<b[0] for a,b in zip(intervals,intervals[1:]))
    replays=0
    # Prespecified endpoints/replications include both native and crossed cases.
    for r in raw:
        if r["T"]!="65536" or r["nominal_scales"]!="4" or r["gap_multiplier"]!="4" or r["rep"] not in ("0","127"):
            continue
        T=int(r["T"]);L=int(r["nominal_scales"]);rep=int(r["rep"]);a=int(r["gap_multiplier"])
        means=env[f"T{T}_L{L}_{r['prior_source']}_g{a}"][rep]
        ar=schedules(T,L)[r["schedule"]]
        rng=np.random.default_rng(np.random.SeedSequence([SEED,T,L,a,rep,1]))
        total,_,actions,_=simulate(ar,means,T,METHODS.index(r["method"]),rng.random(T))
        # Recompute pseudo-regret from actions and the exact current comparator,
        # independently of the simulator's cumulative array.
        best=np.empty(T)
        current=-1.;j=0
        for tt in range(T):
            while j<len(ar) and ar[j]<=tt+1:
                current=max(current,means[j]);j+=1
            best[tt]=current
        losses=best-means[actions]
        assert abs(float(losses.sum())-float(r["regret"]))<1e-7
        assert abs(total-float(r["regret"]))<1e-8
        for w in wlookup[tuple(r[k] for k in keys)]:
            assert abs(losses[int(w["start"])-1:int(w["end"])].sum()-float(w["regret"]))<1e-7
        replays+=1
    exact=read("bayes_exact_results.csv")
    for r in exact:
        f=Fraction(int(r["exact_numerator"]),int(r["exact_denominator"]))
        assert abs(float(f)-float(r["risk"]))<1e-15
        if not r["method"].startswith("Bayes"):
            b=next(x for x in exact if x["T"]==r["T"] and x["gap_denominator"]==r["gap_denominator"] and x["method"].startswith("Bayes"))
            assert f>=Fraction(int(b["exact_numerator"]),int(b["exact_denominator"]))
    bm=json.loads((HERE/"bayes_manifest.json").read_text(encoding="utf-8"))
    assert bm["complete_environment_tree_checks"]==8 and all(c["exact_tree_check"] for c in bm["cases"])
    # The exact DP executable itself verifies agreement by two distinct recursions.
    md=(HERE/"geometry_protocol.md").read_text(encoding="utf-8")
    assert "\\(" not in md and "\\)" not in md and "\\[" not in md and "\\]" not in md
    report=dict(status="PASS",saved_mean_vectors_reconstructed=means_checks,
                full_window_partitions_checked=len(raw),independent_trajectory_replays=replays,
                exact_rational_results_checked=len(exact),exact_DP_reward_tree_cases=8,
                total_policy_rounds=manifest["total_policy_rounds"],
                figure_visual_review="all three PNG previews inspected; labels, legends and uncertainty bars legible",
                mathematical_scope="finite-prior risk and exact finite-state benchmark; no numerical minimax identification")
    (HERE/"geometry_verification.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__=="__main__":verify()
