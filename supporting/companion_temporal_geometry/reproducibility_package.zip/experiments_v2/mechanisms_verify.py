"""Validate released mechanism data independently and regenerate the TeX table."""
from pathlib import Path
import csv
import hashlib
import json
import math
import numpy as np
from policies import METHODS, choose, kl_upper, simulate
from mechanisms_run import CONFIGURATIONS, environment

ROOT = Path(__file__).resolve().parent


def read(name):
    with (ROOT/name).open(encoding='utf-8') as f:
        return list(csv.DictReader(f))


def main():
    raw = read('mechanisms_raw.csv')
    groups = {}
    for r in raw:
        key = (r['configuration'],int(r['T']),r['order'],r['method'])
        groups.setdefault(key,{})[int(r['replication'])] = float(r['regret'])
        assert 0 <= float(r['regret']) <= int(r['T'])
    assert len(raw)==25600 and len(groups)==200
    for values in groups.values():
        assert set(values)==set(range(128))
    summary = read('mechanisms_summary.csv')
    for row in summary:
        key = (row['configuration'],int(row['T']),row['order'],row['method'])
        values = np.array([groups[key][i] for i in range(128)])
        assert abs(values.mean()-float(row['mean_regret'])) < 1e-10
        assert abs(values.std(ddof=1)/math.sqrt(128)-float(row['mc_se'])) < 1e-10
    paired = read('mechanisms_paired.csv')
    for row in paired:
        k = (row['configuration'],int(row['T']),row['order'])
        if row['contrast']=='Clock-capacity interaction':
            v = np.array([groups[k+('Global/current',)][i]-groups[k+('Local/current',)][i]
                          -groups[k+('Global/frozen',)][i]+groups[k+('MC-MOSS',)][i] for i in range(128)])
        else:
            v = np.array([groups[k+(row['method'],)][i]-groups[k+(row['reference'],)][i] for i in range(128)])
        assert abs(v.mean()-float(row['mean_difference'])) < 1e-10
        assert abs(v.std(ddof=1)/math.sqrt(128)-float(row['paired_mc_se'])) < 1e-10
    totals = {}
    for row in read('mechanisms_windows.csv'):
        key = (row['configuration'],int(row['T']),row['order'],row['method'],int(row['replication']))
        totals[key] = totals.get(key,0.)+float(row['regret'])
    assert len(totals)==25600
    for key,v in totals.items():
        assert abs(v-groups[key[:-1]][key[-1]]) < 1e-10
    # The independent reference here solves every KL index without screening.
    rng = np.random.default_rng(7194)
    for _ in range(500):
        n = rng.integers(1,100,17).astype(np.int64)
        sums = rng.binomial(n,rng.uniform(.01,.99,17)).astype(np.float64)
        t = int(rng.integers(101,100000))
        index = np.array([kl_upper(sums[i]/n[i],math.log(t)/n[i]) for i in range(17)])
        got,_,_ = choose(n,sums,17,t,16,1,7)
        assert got==int(np.argmax(index))
    replays = 0
    for r in raw:
        if r['order']=='Forward' and int(r['T'])==8192 and int(r['replication'])==17:
            a,m,_ = environment(r['configuration'],8192,r['order'])
            uniforms = np.random.default_rng(int(r['reward_seed'])).random(8192)
            actual = simulate(a,m,8192,METHODS.index(r['method']),uniforms,int(r['policy_seed']))[0]
            assert abs(actual-float(r['regret'])) < 1e-12
            replays += 1
    keep = ('MC-MOSS','KL-UCB','Thompson','Clipped MC')
    table = ['\\begin{table}[t]','\\centering',
             '\\caption{Pseudo-regret for four policies under five reward configurations.}',
             '\\label{tab:mechanisms-baselines}',
             '\\normalsize','\\setlength{\\tabcolsep}{3pt}',
             '\\begin{tabular*}{\\linewidth}{@{\\extracolsep{\\fill}}lrrrr@{}}','\\toprule',
             'Configuration & MC-MOSS & KL-UCB & Thompson & Clipped MC \\\\',
             '\\midrule']
    selected = {(r['configuration'],r['method']):r for r in summary if int(r['T'])==8192 and r['order']=='Forward'}
    for config in CONFIGURATIONS:
        cells = []
        for method in keep:
            r = selected[config,method]
            cells.append(f"{float(r['mean_regret']):.2f} ({float(r['mc_se']):.2f})")
        table.append(config+' & '+' & '.join(cells)+' \\\\')
    table += ['\\bottomrule','\\end{tabular*}',
              '\\par\\medskip\\noindent\\begin{minipage}{\\linewidth}\\normalsize\\setstretch{1}',
              '\\textit{Notes:} Entries are mean pseudo-regret with Monte Carlo standard errors in parentheses at $T=8192$, forward labels, and 128 replications. The complete two-horizon, two-label-order results, including UCB1 and AUER, are in the computational supplement and released CSV files.',
              '\\end{minipage}','\\end{table}']
    (ROOT/'mechanisms_table_baselines.tex').write_text('\n'.join(table)+'\n',encoding='utf-8')
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('mechanisms_*.csv')}
    result = dict(status='passed',complete_trajectories=len(raw),complete_cells=len(groups),
                  summary_rows_recomputed=len(summary),paired_rows_recomputed=len(paired),
                  window_sum_checks=len(totals),independent_kl_screening_checks=500,
                  final_seed_exact_replays=replays,data_sha256=hashes)
    (ROOT/'mechanisms_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='data_sha256'},indent=2))


if __name__=='__main__':
    main()
