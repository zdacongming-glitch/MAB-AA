# Experiment B: clock, capacity, and history

This is a fixed simulation design, specified before the final run. No environment or parameter was selected from its regret values. The development run uses separate seeds and only two repetitions; it serves software validation. The final run uses 128 replications for every combination of five configurations, two horizons, two label orders, and ten policies.

## Commands

Run from the reconstruction root:

```text
python experiments_v2/mechanisms_run.py --replications 128 --seed 73061013
python experiments_v2/mechanisms_verify.py
python figures_v2/gen_fig_mechanisms.py
```

Dependencies: Python 3.11, NumPy, Numba, SciPy, Matplotlib. The recorded versions and measured runtime are in `mechanisms_manifest.json`. The final run completed 25,600 trajectories and 131,072,000 policy rounds in approximately 106 seconds on the session machine. No parallel workers were used. Timing depends on hardware and on whether Numba has compiled the functions.

## Scientific design

There are 32 candidates and one designated initial anchor. Candidate batch sizes are 4, 4, 8, 8, and 8; their arrivals are 1, floor(T/8)+1, floor(T/3)+1, floor(T/2)+1, and floor(3T/4)+1. Horizons are 2,048 and 8,192. Exact means and physical-label mappings are recorded in `mechanisms_environments.csv`; the function `environment` is their source. Configurations cover near ties, many poor candidates, a persistent new record at the fourth batch, a heterogeneous last batch, and the reward boundary. The last case deliberately has anchor mean exactly one, rather than an interior mean close to one; its conclusions are restricted accordingly.

The factorial comparison retains all historical observations and changes only two index inputs. Clock is either local $s_t$ or global $t$; capacity is either the segment's frozen $d_j$ or the current $2(K_t-1)$. Every factorial cell uses

$$
\widehat\mu_i+\sqrt{\frac{\log_+(u_t/(v_tN_i))}{N_i}}.
$$

The separate Cold MC policy has the same clocks, capacities, initialization, and ties as MC-MOSS, and only clears observations at the same capacity-doubling times. Clipped MC caps every index, including an unobserved arm's index, at one. All index ties favor the first available label. Both label orders are run in full; reverse order changes only labels within candidate batches and keeps the anchor first.

UCB1 uses coefficient two and AUER coefficient eight inside the square-root bonus. These are a confidence-constant comparison within the same index family, not two fundamentally distinct mechanisms. Bernoulli KL-UCB uses its original authors' recommended simulation choice $c=0$; Thompson sampling uses independent Beta(1,1) priors and the exact beta posterior for every arrived arm. None of these experimental implementations is assigned an unproved schedule-wise spectral guarantee.

Reward uniforms are independent across rounds and shared between methods at each calendar time to form a coupling for paired differences. The random posterior draws used by Thompson sampling have a separate, reproducible seed. Each policy's observed rewards have the required Bernoulli conditional law. The policy decision function receives only present labels, current time, observations, and its current clock state; it receives no true mean, terminal horizon, or future arrival.

## Primary-source checks

- [Garivier and Cappé (2011), Algorithm 1 and Section 2](https://proceedings.mlr.press/v19/garivier11a/garivier11a.pdf): Bernoulli KL index with exploration budget log(t) + c log log(t); the authors recommend c=0 for their experiments, whereas the displayed theorem uses c=3. Our c=0 is fixed before simulation, and we do not claim their c=3 theorem for it.
- [Agrawal and Goyal (2012), Algorithm 1](https://proceedings.mlr.press/v23/agrawal12/agrawal12.pdf): each arm's Beta(1,1) prior is updated by its observed successes and failures. New labels receive the same prior upon arrival, and all earlier posteriors are retained.
- [Kleinberg, Niculescu-Mizil, and Sharma (2008), Algorithm 2](https://www.cs.cornell.edu/~rdk/papers/colt08.pdf): AUER uses the bonus with coefficient eight. It is a full-history sleeping-bandit UCB rule. Our permanent-availability implementation selects only present arms.

The bibliographic additions for the first two sources are in `mechanisms_references.bib`. AUER and UCB1 are already in the manuscript bibliography. Checked 2026-10-13.

## Outputs and interpretation

`mechanisms_raw.csv` contains one pseudo-regret per trajectory. `mechanisms_windows.csv` gives the five disjoint intervals between batch arrivals, including the terminal interval. `mechanisms_summary.csv` gives mean and Monte Carlo standard error. `mechanisms_paired.csv` contains four factorial contrasts, the clock-capacity interaction, and matched policy differences. `mechanisms_labels.csv` contains paired reverse-minus-forward differences. Standard errors use variation across independent replications; intervals shown in figures are pointwise mean ± 1.96 standard errors, not simultaneous bands.

`mechanisms_verify.py` independently reconstructs means and standard errors, sums all window regrets, checks every replication is present exactly once, compares screened KL maximization with unscreened root calculations, and exactly replays one recorded final-seed replication for all fifty configuration-method combinations at the larger horizon. It also regenerates the main-text table directly from the summary data. The run audit additionally compares MC and Cold MC with the original online API, verifies hidden-future prefix invariance for all methods, and checks beta posterior moments and KL roots. Numerical checks validate software, not theorems.

The paired plots show clock and capacity effects can offset one another. Current capacity often improves on frozen capacity, and the exact-boundary example substantially favors KL-UCB, Thompson sampling, and clipping over the unclipped MC rule. These outcomes are retained. The experiment does not estimate a minimax supremum and does not show universal finite-sample dominance.

The prose file `mechanisms_results.tex` is intended for the main paper; `mechanisms_appendix.tex` supplies full design and additional figures. Three plots are exported as vector PDF and 300 dpi PNG with their generating script. The baseline heatmap reports raw means numerically and uses a separate within-row ratio only for shading, capped at three on the displayed log scale; shading does not represent uncertainty.
