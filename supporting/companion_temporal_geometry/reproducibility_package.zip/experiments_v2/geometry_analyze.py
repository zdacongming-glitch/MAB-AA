"""Summarize and plot experiment A without running or selecting new instances."""
from __future__ import annotations
from collections import defaultdict
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
FIG=HERE.parent/"figures_v2"
FIG.mkdir(exist_ok=True)
KEYS=("T","nominal_scales","schedule","prior_source","gap_multiplier","method")


def read(name):
    with (HERE/name).open(encoding="utf-8",newline="") as f:
        return list(csv.DictReader(f))


def write(name, rows):
    with (HERE/name).open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def aggregate(rows,keys,values):
    groups=defaultdict(list)
    for r in rows:
        groups[tuple(r[k] for k in keys)].append(r)
    result=[]
    for key, rr in sorted(groups.items()):
        out=dict(zip(keys,key));out["replications"]=len(rr)
        for v in values:
            x=np.asarray([float(r[v]) for r in rr])
            out[v+"_mean"]=float(np.mean(x))
            out[v+"_mcse"]=float(np.std(x,ddof=1)/np.sqrt(len(x)))
        result.append(out)
    return result


def select(rows,**conditions):
    return [r for r in rows if all(str(r[k])==str(v) for k,v in conditions.items())]


def only(rows,**conditions):
    rr=select(rows,**conditions)
    assert len(rr)==1,conditions
    return rr[0]


def save(fig,name):
    fig.savefig(FIG/(name+".pdf"),bbox_inches="tight",pad_inches=.04)
    fig.savefig(FIG/(name+".png"),dpi=250,bbox_inches="tight",pad_inches=.04)
    plt.close(fig)


def main():
    raw=read("geometry_raw.csv")
    summary=aggregate(raw,KEYS,("regret","R_over_S","R_over_Gamma","window_regret","outside_window_regret"))
    write("geometry_summary.csv",summary)
    windows=aggregate(read("geometry_windows.csv"),KEYS+("window","start","end"),("regret",))
    write("geometry_window_summary.csv",windows)
    pairrows=[]
    lut={tuple(r[k] for k in KEYS)+(r["rep"],):r for r in raw}
    for r in raw:
        if r["method"]!="Cold MC":
            continue
        key=tuple(r[k] if k!="method" else "MC-MOSS" for k in KEYS)+(r["rep"],)
        z=dict(r)
        z["regret_difference"]=float(r["regret"])-float(lut[key]["regret"])
        pairrows.append(z)
    paired=aggregate(pairrows,KEYS[:-1],("regret_difference",))
    for p in paired:p["contrast"]="Cold MC minus MC-MOSS"
    write("geometry_paired_methods.csv",paired)
    schedulepairs=[]
    for r in raw:
        if r["schedule"]!="compressed" or r["gap_multiplier"]!="4":
            continue
        key=tuple(r[k] if k!="schedule" else "multiscale" for k in KEYS)+(r["rep"],)
        z=dict(r);z["regret_difference"]=float(r["regret"])-float(lut[key]["regret"])
        schedulepairs.append(z)
    schedule_summary=aggregate(schedulepairs,("T","nominal_scales","prior_source","gap_multiplier","method"),("regret_difference",))
    for p in schedule_summary:p["contrast"]="compressed schedule minus multiscale schedule, same means"
    write("geometry_paired_schedules.csv",schedule_summary)

    plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman","DejaVu Serif"],
        "font.size":10,"axes.labelsize":10,"axes.titlesize":11,"xtick.labelsize":10,"ytick.labelsize":10,
        "legend.fontsize":10,"legend.frameon":False,"axes.spines.top":False,"axes.spines.right":False,
        "axes.grid":True,"grid.alpha":.15,"pdf.fonttype":42,"ps.fonttype":42})
    colors=("#0072B2","#E69F00","#009E73","#CC79A7")
    fig,ax=plt.subplots(2,2,figsize=(6.9,4.8),constrained_layout=True)
    for T,color,marker in zip((1024,4096,16384,65536),colors,("o","s","^","D")):
        ss=sorted(select(summary,T=T,schedule="multiscale",prior_source="multiscale",gap_multiplier=4,method="MC-MOSS"),key=lambda r:int(r["nominal_scales"]))
        x=[int(r["nominal_scales"]) for r in ss]
        for a,v in zip(ax[0],("R_over_S","R_over_Gamma")):
            a.errorbar(x,[r[v+"_mean"] for r in ss],yerr=[1.96*r[v+"_mcse"] for r in ss],
                       color=color,marker=marker,markersize=4,capsize=2,linewidth=1.2,label=f"$T={T:,}$")
    ax[0,0].set(title="(a) Native multiscale prior",ylabel=r"Mean $R_T/\mathcal{S}_T$")
    ax[0,1].set(title="(b) The same trajectories",ylabel=r"Mean $R_T/\Gamma_T$")
    ax[0,0].legend(loc="lower right")
    for a in ax[0]:a.set(xlabel=r"Effective scales $D_T^{\rm eff}=L$",xticks=[1,2,3,4])
    for sn,color in zip(("multiscale","compressed"),("#D55E00","#0072B2")):
        for method,ls,marker in (("MC-MOSS","-","o"),("Cold MC","--","s")):
            ss=sorted(select(summary,T=65536,schedule=sn,prior_source=sn,gap_multiplier=4,method=method),key=lambda r:int(r["nominal_scales"]))
            ax[1,0].errorbar([int(r["nominal_scales"]) for r in ss],[r["regret_mean"] for r in ss],
                  yerr=[1.96*r["regret_mcse"] for r in ss],color=color,ls=ls,marker=marker,markersize=3.5,capsize=2,linewidth=1.2,
                  label=f"{'Multi' if sn=='multiscale' else 'Compressed'}, {'MC' if method=='MC-MOSS' else 'cold'}")
    ax[1,0].set(title="(c) Matched counts, native priors",xlabel="Number of multiscale batches $L$",ylabel="Mean regret",xticks=[1,2,3,4])
    ax[1,0].legend(loc="upper left",fontsize=10)
    x=np.arange(2);width=.34
    for j,(sn,color) in enumerate(zip(("multiscale","compressed"),("#D55E00","#0072B2"))):
        rr=[only(summary,T=65536,nominal_scales=4,schedule=sn,prior_source=pn,gap_multiplier=4,method="MC-MOSS") for pn in ("multiscale","compressed")]
        ax[1,1].bar(x+(j-.5)*width,[r["regret_mean"] for r in rr],width,color=color,
                    yerr=[1.96*r["regret_mcse"] for r in rr],capsize=2,label=f"{sn.capitalize()} schedule")
    ax[1,1].set(title="(d) Crossed common environments",xticks=x,xticklabels=["Multiscale prior","Compressed prior"],ylabel="Mean regret (MC-MOSS)")
    ax[1,1].legend(loc="upper left",fontsize=9)
    save(fig,"fig_geometry_risk")

    fig,ax=plt.subplots(1,2,figsize=(6.9,2.8),constrained_layout=True)
    for multiplier,color in zip((1,4,8),("#0072B2","#E69F00","#009E73")):
        for method,ls in (("MC-MOSS","-"),("Cold MC","--")):
            ss=sorted(select(summary,T=65536,schedule="multiscale",prior_source="multiscale",gap_multiplier=multiplier,method=method),key=lambda r:int(r["nominal_scales"]))
            ax[0].errorbar([int(r["nominal_scales"]) for r in ss],[r["R_over_S_mean"] for r in ss],
                yerr=[1.96*r["R_over_S_mcse"] for r in ss],color=color,ls=ls,marker="o",markersize=3,capsize=2,linewidth=1.1,
                label=f"$a={multiplier}$, {'MC' if method=='MC-MOSS' else 'cold'}")
    ax[0].set(title="(a) Prespecified gap sensitivity",xlabel="Effective scales $L$",ylabel=r"Mean $R_T/\mathcal{S}_T$",xticks=[1,2,3,4])
    ax[0].legend(ncol=2,fontsize=6.5)
    for j,(method,color) in enumerate((("MC-MOSS","#D55E00"),("Cold MC","#0072B2"))):
        ss=sorted(select(windows,T=65536,nominal_scales=4,schedule="multiscale",prior_source="multiscale",gap_multiplier=4,method=method),key=lambda r:int(r["window"]))
        out=only(summary,T=65536,nominal_scales=4,schedule="multiscale",prior_source="multiscale",gap_multiplier=4,method=method)
        means=[r["regret_mean"] for r in ss]+[out["outside_window_regret_mean"]]
        se=[r["regret_mcse"] for r in ss]+[out["outside_window_regret_mcse"]]
        ax[1].bar(np.arange(5)+(j-.5)*.34,means,.34,color=color,yerr=1.96*np.asarray(se),capsize=2,label=method)
    ax[1].set(title="(b) Disjoint testing windows",ylabel="Mean regret contribution",xticks=np.arange(5),xticklabels=["$Q_1$","$Q_2$","$Q_3$","$Q_4$","Outside"])
    ax[1].legend(loc="upper left")
    save(fig,"fig_geometry_sensitivity")

    exact=read("bayes_exact_results.csv")
    fig,ax=plt.subplots(1,2,figsize=(6.9,2.55),constrained_layout=True)
    for a,denominator in zip(ax,(16,8)):
        for method,color,marker,ls in (("Bayes optimal (known schedule/prior)","#009E73","D","-"),("MC-MOSS","#D55E00","o","-"),("Cold MC","#0072B2","s","--")):
            ss=sorted(select(exact,gap_denominator=denominator,method=method),key=lambda r:int(r["T"]))
            a.plot([int(r["T"]) for r in ss],[float(r["risk"]) for r in ss],color=color,marker=marker,ls=ls,markersize=4,label="Bayes optimal" if method.startswith("Bayes") else method)
        a.set(xlabel="Endpoint $T$",ylabel="Exact finite-prior Bayes risk",xticks=[4,6,8,10],title=f"$\\epsilon_1=1/{denominator},\\;\\epsilon_2=2/{denominator}$")
    ax[0].legend(loc="upper left")
    save(fig,"fig_bayes_exact")
    print("Wrote summaries, paired contrasts, and three PDF/PNG figures.")


if __name__=="__main__":main()
