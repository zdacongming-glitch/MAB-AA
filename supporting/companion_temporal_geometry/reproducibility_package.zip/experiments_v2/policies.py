"""Causal arriving-arm policies used by the stage-two experiments.

The simulator owns arrivals, means, and the stopping horizon.  choose() is the
decision boundary: it sees only current observations, current labels and time.
Index ties use the first present label.  All policies retain lifetime data except
the expressly named Cold MC.  Numba's random stream is used only for TS draws;
reward uniforms are supplied separately and coupled across methods.
"""
from __future__ import annotations
import math
import numpy as np
from numba import njit

METHODS = ('MC-MOSS', 'Local/current', 'Global/frozen', 'Global/current',
           'Cold MC', 'UCB1', 'AUER', 'KL-UCB', 'Thompson', 'Clipped MC')


@njit(cache=True)
def bernoulli_kl(p, q):
    if p == q:
        return 0.0
    if q <= 0.0 or q >= 1.0:
        return np.inf
    if p <= 0.0:
        return -math.log1p(-q)
    if p >= 1.0:
        return -math.log(q)
    return p * math.log(p / q) + (1.0-p) * math.log((1.0-p)/(1.0-q))


@njit(cache=True)
def kl_upper(p, budget):
    """Supremum q >= p with kl(p,q) <= budget; error at most 2**-32."""
    if p >= 1.0:
        return 1.0
    if budget <= 0.0:
        return p
    if p <= 0.0:
        return -math.expm1(-budget)
    lo, hi = p, min(1.0, p + math.sqrt(budget / 2.0))
    for _ in range(32):
        mid = (lo + hi) / 2.0
        if bernoulli_kl(p, mid) <= budget:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


@njit(cache=True)
def choose(n, sums, k, t, base, start, method):
    """No future arrivals, terminal horizon, or true means cross this boundary."""
    if k == 1:
        return 0, base, start
    if base == 0 or k - 1 >= 2 * base:
        base = k - 1
        start = t
        if method == 4:
            for i in range(k):
                n[i] = 0
                sums[i] = 0.0
    clock = t if method in (2, 3) else t-start+1
    denom = 2*(k-1) if method in (1, 3) else 2*base
    chosen, maximum = 0, -np.inf
    log_t = math.log(t)
    for i in range(k):
        if method == 8:
            index = np.random.beta(1.0+sums[i], 1.0+n[i]-sums[i])
        elif n[i] == 0:
            if method != 9:
                return i, base, start
            index = 1.0
        else:
            average = sums[i] / n[i]
            if method in (5, 6):
                index = average + math.sqrt((2.0 if method == 5 else 8.0)*log_t/n[i])
            elif method == 7:
                # The paper's recommended experimental c=0, fixed in advance.
                budget = log_t / n[i]
                # Exact monotonic screening avoids solving a root known to lose.
                if average < maximum and bernoulli_kl(average, maximum) > budget:
                    continue
                index = kl_upper(average, budget)
            else:
                q = clock / (denom*n[i])
                index = average + (math.sqrt(math.log(q)/n[i]) if q > 1.0 else 0.0)
                if method == 9:
                    index = min(1.0, index)
        if index > maximum:
            chosen, maximum = i, index
    return chosen, base, start


@njit(cache=True)
def simulate(arrivals, means, horizon, method, uniforms, policy_seed=1, deterministic=False):
    """Return regret, lifetime pulls, actions, and cumulative pseudo-regret.

    Arrays are sorted by (arrival, desired tie priority).  T is used only by the
    simulator; no policy is given T.  For a prefix audit, omit future labels and
    preserve the first uniforms and policy_seed.  TS then makes identical draws.
    """
    np.random.seed(policy_seed)
    n = np.zeros(len(arrivals), dtype=np.int64)
    sums = np.zeros(len(arrivals), dtype=np.float64)
    pulls = np.zeros(len(arrivals), dtype=np.int64)
    actions = np.empty(horizon, dtype=np.int64)
    cumulative = np.empty(horizon, dtype=np.float64)
    k = base = start = 0
    best, regret = -1.0, 0.0
    for tt in range(horizon):
        t = tt + 1
        while k < len(arrivals) and arrivals[k] <= t:
            best = max(best, means[k])
            k += 1
        chosen, base, start = choose(n, sums, k, t, base, start, method)
        reward = means[chosen] if deterministic else (1.0 if uniforms[tt] < means[chosen] else 0.0)
        n[chosen] += 1
        sums[chosen] += reward
        pulls[chosen] += 1
        regret += best - means[chosen]
        actions[tt] = chosen
        cumulative[tt] = regret
    return regret, pulls, actions, cumulative
