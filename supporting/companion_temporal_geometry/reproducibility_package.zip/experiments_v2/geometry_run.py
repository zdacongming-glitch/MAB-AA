"""Experiment A: one compatible finite product prior and matched schedules.

Run from any directory. No reward data or tuning output are used in the design.
The scalar gap multipliers and all seeds below are fixed before simulation.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "experiments" / "original_snapshot"))
from geometry import spectrum, fixed_point, capacity, compatible_scales
from policies import simulate, METHODS

SEED = 20261013041
HORIZONS = (1024, 4096, 16384, 65536)
MULTIPLIERS = (1, 4, 8)
METHOD_IDS = (0, 4)


def schedules(T, L):
    hs = [T // 4**j for j in range(L)]
    sizes = [2 * 4**j for j in range(L)]
    mult = np.array([1] + [T-h+1 for h, k in zip(hs, sizes) for _ in range(k)], dtype=np.int64)
    M = sum(sizes)
    compressed = np.array([1] + [1] * (2*L) + [T] * (M-2*L), dtype=np.int64)
    return {"multiscale": mult, "compressed": compressed}


def template(arrivals, T, multiplier):
    lifetimes = [int(T-t+1) for t in arrivals[1:]]
    selected = compatible_scales(lifetimes, T)["selected"]
    groups = []
    theta = .5
    for ell, b, k, v in selected:
        labels = [i for i in range(1, len(arrivals)) if 1 << (int(T-arrivals[i]+1)-1).bit_length() == b]
        epsilon = multiplier*v/32
        groups.append(dict(ell=ell, b=b, v=v, reference=labels[0], candidates=labels[1:],
                           theta=theta, epsilon=epsilon,
                           null_probability=.5, each_spike_probability=.5/(k-1),
                           window_start=T-b//2+1, window_end=T-b//4))
        theta += epsilon
    assert groups
    previous_max = .5
    previous_end = 0
    for j, g in enumerate(groups):
        assert 0 < g["theta"]-g["epsilon"] < g["theta"]+g["epsilon"] < 1
        assert previous_max <= g["theta"] + 1e-14
        assert g["window_start"] > previous_end
        assert max(arrivals[[g["reference"]]+g["candidates"]]) <= g["window_start"]
        if j+1 < len(groups):
            assert min(arrivals[[groups[j+1]["reference"]]+groups[j+1]["candidates"]]) > g["window_end"]
        previous_end = g["window_end"]
        previous_max = g["theta"]+g["epsilon"]
    return groups


def draw_means(K, groups, rng):
    means = np.full(K, .25)
    means[0] = .5
    states = []
    for g in groups:
        means[g["reference"]] = g["theta"]
        means[g["candidates"]] = g["theta"]-g["epsilon"]
        if rng.random() < .5:
            state = -1
        else:
            state = int(rng.choice(g["candidates"]))
            means[state] = g["theta"]+g["epsilon"]
        states.append(state)
    return means, states


def csv_write(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def run(reps):
    started = time.time()
    raw, window_rows, geom_rows, specs, mean_arrays = [], [], [], [], {}
    total_rounds = 0
    mass_checks = 0
    # L=4 is included once every candidate group has at least 256 rounds left.
    for T in HORIZONS:
        max_L = 3 if T < 16384 else 4
        for L in range(1, max_L+1):
            scheds = schedules(T, L)
            if L == 1:
                scheds.pop("compressed")  # identical schedules are not counted twice
            for sn, ar in scheds.items():
                hs = [int(T-t+1) for t in ar[1:]]
                sp = spectrum(hs, T)
                geom_rows.append(dict(T=T, nominal_scales=L, schedule=sn, K=len(ar),
                                      S=sp["S"], Gamma=fixed_point(hs, T), Q=sp["Q"],
                                      D_eff=sp["D_eff"], C=capacity(hs, T)["C"]))
            for multiplier in MULTIPLIERS:
                templates = {sn: template(ar, T, multiplier) for sn, ar in scheds.items()}
                for pn, groups in templates.items():
                    key = f"T{T}_L{L}_{pn}_g{multiplier}"
                    means_rep = []
                    state_rep = []
                    specs.append(dict(id=key, T=T, nominal_scales=L, prior_source=pn,
                                      gap_multiplier=multiplier, arrivals=scheds[pn].tolist(),
                                      groups=groups, means_unused=.25, anchor_mean=.5))
                    # Different prior sources have independent latent draws. For a fixed
                    # source, the same means and reward uniforms are used across schedules.
                    for rep in range(reps):
                        reward_rng = np.random.default_rng(np.random.SeedSequence([SEED, T, L, multiplier, rep, 1]))
                        latent_rng = np.random.default_rng(np.random.SeedSequence([SEED, T, L, multiplier, rep, 2, int(pn=="compressed")]))
                        means, states = draw_means(len(scheds[pn]), groups, latent_rng)
                        means_rep.append(means)
                        state_rep.append(states)
                        uniforms = reward_rng.random(T)
                        for sn, ar in scheds.items():
                            if sn != pn and multiplier != 4:
                                continue
                            gg = next(g for g in geom_rows if g["T"] == T and g["nominal_scales"] == L and g["schedule"] == sn)
                            # Windows describe the receiving schedule's native construction.
                            windows = templates[sn]
                            for method in METHOD_IDS:
                                reg, pulls, actions, cumulative = simulate(ar, means, T, method, uniforms)
                                assert pulls.sum() == T and np.all(ar[actions] <= np.arange(1, T+1))
                                wr = []
                                for w, g in enumerate(windows):
                                    lo, hi = g["window_start"], g["window_end"]
                                    value = float(cumulative[hi-1] - (cumulative[lo-2] if lo > 1 else 0.))
                                    wr.append(value)
                                    window_rows.append(dict(T=T, nominal_scales=L, schedule=sn, prior_source=pn,
                                                            gap_multiplier=multiplier, rep=rep, method=METHODS[method],
                                                            window=w, start=lo, end=hi, regret=value))
                                outside = float(reg-sum(wr))
                                assert outside >= -1e-8
                                mass_checks += 1
                                raw.append(dict(T=T, nominal_scales=L, schedule=sn, prior_source=pn,
                                                gap_multiplier=multiplier, rep=rep, method=METHODS[method],
                                                regret=reg, R_over_S=reg/gg["S"], R_over_Gamma=reg/gg["Gamma"],
                                                window_regret=sum(wr), outside_window_regret=outside))
                                total_rounds += T
                    mean_arrays[key] = np.asarray(means_rep)
                    mean_arrays[key+"_latent"] = np.asarray(state_rep, dtype=np.int64)
            print(f"finished T={T} L={L}, trajectories={len(raw)}, seconds={time.time()-started:.1f}", flush=True)
    csv_write(HERE / "geometry_raw.csv", raw)
    csv_write(HERE / "geometry_windows.csv", window_rows)
    csv_write(HERE / "geometry_schedules.csv", geom_rows)
    np.savez_compressed(HERE / "geometry_environments.npz", **mean_arrays)
    # Every pair uses the same T and K; report the actual fixed-point ratio.
    pairchecks=[]
    for row in geom_rows:
        if row["schedule"] != "compressed":
            continue
        other=next(g for g in geom_rows if g["T"]==row["T"] and g["nominal_scales"]==row["nominal_scales"] and g["schedule"]=="multiscale")
        assert other["K"]==row["K"]
        pairchecks.append(dict(T=row["T"], L=row["nominal_scales"], K=row["K"],
                               Gamma_ratio_compressed_over_multiscale=row["Gamma"]/other["Gamma"],
                               S_ratio_multiscale_over_compressed=other["S"]/row["S"]))
    manifest=dict(experiment="A: compatible finite-prior Bayes averages", seed=SEED,
                  repetitions=reps, horizons=HORIZONS, gap_multipliers=MULTIPLIERS,
                  methods=[METHODS[m] for m in METHOD_IDS],
                  design_fixed_before_run=True, method_parameters_tuned=False,
                  coupling="same calendar reward uniforms across methods and receiving schedules; same latent environment across receiving schedules",
                  uncertainty="independent replication Monte Carlo SE; latent environments and rewards both resampled",
                  cross_evaluation="gap multiplier 4 only; same labeled mean vector evaluated under both schedules",
                  native_prior_scope="legal common null/spike product prior across all selected scales; not a minimax-risk estimate",
                  sensitivity_scope="multipliers 4 and 8 preserve valid stationary means and compatibility, but not the conservative TV constant in the theorem proof",
                  window_scope="native windows of receiving schedule; outside-window regret is retained",
                  trajectories=len(raw), total_policy_rounds=total_rounds, window_partition_checks=mass_checks,
                  python=platform.python_version(), numpy=np.__version__, elapsed_seconds=time.time()-started,
                  pair_checks=pairchecks, prior_specifications=specs)
    for name in ("geometry_run.py", "policies.py"):
        manifest[name+"_sha256"]=hashlib.sha256((HERE/name).read_bytes()).hexdigest()
    (HERE/"geometry_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k:manifest[k] for k in ("trajectories", "total_policy_rounds", "elapsed_seconds")}), flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=128)
    args=parser.parse_args()
    if args.reps < 2:
        raise ValueError("at least two independent replications are required")
    run(args.reps)
