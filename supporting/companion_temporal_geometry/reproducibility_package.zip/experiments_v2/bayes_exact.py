"""Exact finite-prior Bayes decision benchmark using rational arithmetic.

All probabilities, posterior expectations, and Bellman comparisons are exact
fractions.  Independent environment-by-environment tree integration verifies
the value returned by the posterior-state dynamic program.
"""
from __future__ import annotations
import csv
from fractions import Fraction as F
from functools import lru_cache
import itertools
import json
from pathlib import Path
import sys
import time
import numpy as np
from policies import choose, METHODS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0, str(ROOT/"experiments"/"original_snapshot"))
from geometry import spectrum, fixed_point


def finite_prior(T, denominator):
    e1, e2=F(1,denominator), F(2,denominator)
    arrivals=(1,1,1,T-1,T-1,T-1)
    environments=[]
    probabilities=[]
    for first, second in itertools.product((-1,2),(-1,4,5)):
        mu=[F(1,2),F(1,2),F(1,2)-e1,F(1,2)+e1,F(1,2)+e1-e2,F(1,2)+e1-e2]
        if first>=0:
            mu[first]=F(1,2)+e1
        if second>=0:
            mu[second]=F(1,2)+e1+e2
        environments.append(tuple(mu))
        probabilities.append(F(1,2)*(F(1,2) if second<0 else F(1,4)))
    assert sum(probabilities)==1 and all(0<x<1 for mu in environments for x in mu)
    return arrivals,tuple(environments),tuple(probabilities)


def solve(T, denominator):
    arrivals, envs, prior=finite_prior(T,denominator)
    uncertain=(2,4,5)
    ui={a:j for j,a in enumerate(uncertain)}
    zero=(0,)*6
    decisions={}
    gaps={}

    @lru_cache(None)
    def posterior(state):
        weights=[]
        for mu,w in zip(envs,prior):
            for j,a in enumerate(uncertain):
                w*=mu[a]**state[2*j]*(1-mu[a])**state[2*j+1]
            weights.append(w)
        total=sum(weights)
        assert total>0
        return tuple(w/total for w in weights)

    def update(state,a,y):
        if a not in ui:
            return state
        s=list(state)
        s[2*ui[a]+(0 if y else 1)]+=1
        return tuple(s)

    @lru_cache(None)
    def value(t,state):
        if t>T:
            return F(0)
        weights=posterior(state)
        available=[a for a in range(len(arrivals)) if arrivals[a]<=t]
        oracle=sum(w*max(mu[a] for a in available) for w,mu in zip(weights,envs))
        options=[]
        for a in available:
            q=sum(w*mu[a] for w,mu in zip(weights,envs))
            immediate=oracle-q
            v=immediate+q*value(t+1,update(state,a,1))+(1-q)*value(t+1,update(state,a,0))
            options.append((v,a))
        v,a=min(options)
        decisions[(t,state)]=a
        if len(options)>1:
            distinct=sorted(set(z[0] for z in options))
            if len(distinct)>1:
                gaps[(t,state)]=distinct[1]-distinct[0]
        return v

    optimum=value(1,zero)

    def integrate_opt(mu,t=1,state=zero):
        if t>T:
            return F(0)
        a=decisions[(t,state)]
        best=max(mu[i] for i in range(len(arrivals)) if arrivals[i]<=t)
        return best-mu[a]+mu[a]*integrate_opt(mu,t+1,update(state,a,1))+(1-mu[a])*integrate_opt(mu,t+1,update(state,a,0))

    check=sum(w*integrate_opt(mu) for w,mu in zip(prior,envs))
    assert optimum==check

    def integrate_method(mu,method,t=1,n=None,sums=None,base=0,start=0):
        if t>T:
            return F(0)
        if n is None:
            n=np.zeros(len(arrivals),dtype=np.int64)
            sums=np.zeros(len(arrivals),dtype=np.float64)
        n=n.copy(); sums=sums.copy()
        k=sum(x<=t for x in arrivals)
        a,base,start=choose(n,sums,k,t,base,start,method)
        immediate=max(mu[:k])-mu[a]
        n[a]+=1
        sums[a]+=1
        success=integrate_method(mu,method,t+1,n,sums,base,start)
        sums[a]-=1
        failure=integrate_method(mu,method,t+1,n,sums,base,start)
        return immediate+mu[a]*success+(1-mu[a])*failure

    results={"Bayes optimal (known schedule/prior)":optimum}
    for method in (0,4):
        risk=sum(w*integrate_method(mu,method) for w,mu in zip(prior,envs))
        assert risk>=optimum
        results[METHODS[method]]=risk
    hs=[T-t+1 for t in arrivals[1:]]
    S=spectrum(hs,T)["S"]
    gamma=fixed_point(hs,T)
    rows=[dict(T=T,gap_denominator=denominator,method=m,risk=float(v),
               exact_numerator=str(v.numerator),exact_denominator=str(v.denominator),
               ratio_to_Bayes=float(v/optimum),S=S,Gamma=gamma,R_over_S=float(v)/S,
               R_over_Gamma=float(v)/gamma) for m,v in results.items()]
    report=dict(T=T,gap_denominator=denominator,arrivals=arrivals,
                means=[[str(x) for x in mu] for mu in envs],prior=[str(w) for w in prior],
                uncertain_labels=uncertain,states=value.cache_info().currsize,
                posterior_states=posterior.cache_info().currsize,
                exact_tree_check=True,Bayes_risk=str(optimum),
                minimum_positive_Bellman_action_gap=str(min(gaps.values())) if gaps else None)
    return rows,report


if __name__=="__main__":
    start=time.time()
    rows=[]; reports=[]
    for T in (4,6,8,10):
        for denominator in (16,8):
            rr,report=solve(T,denominator)
            rows.extend(rr); reports.append(report)
            print(f"T={T} denominator={denominator}, exact Bayes={report['Bayes_risk']}, states={report['states']}",flush=True)
    with (HERE/"bayes_exact_results.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    manifest=dict(arithmetic="Python fractions.Fraction; all Bellman probabilities, risks and comparisons exact",
                  policy_risks="exact reward-tree integration of the explicitly implemented MC-MOSS and Cold MC numerical indices",
                  information="Bayes rule knows the full deterministic schedule and finite joint reward prior; compared policies see only arrivals and past rewards",
                  lower_bound_scope="Bayes optimal risk for this stated finite prior lower-bounds the full deterministic-schedule minimax risk",
                  complete_environment_tree_checks=len(reports),elapsed_seconds=time.time()-start,cases=reports)
    (HERE/"bayes_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
