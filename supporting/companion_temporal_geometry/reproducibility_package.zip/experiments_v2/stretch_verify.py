"""Independent reconstruction of development selection and held-out risks."""
from pathlib import Path
import csv
import json
import math
import numpy as np

ROOT=Path(__file__).resolve().parent


def read(name):
    with (ROOT/name).open(encoding='utf-8') as f:return list(csv.DictReader(f))


def law_weights(law,m):
    if law=='Inverse square root':
        a=np.array([1/(2**j) for j in range(m+1)]);return a/a.sum()
    if law=='Uniform scales':return np.full(m+1,1/(m+1))
    a=np.zeros(m+1);a[-1]=1;return a


def main():
    rows=read('stretch_raw.csv');data={};seeds={'Development':set(),'Held out':set()}
    for r in rows:
        key=(r['split'],int(r['m']),float(r['gap']),int(r['sign']),int(r['scale']),r['method'],int(r['replication']))
        assert key not in data
        data[key]=float(r['regret'])
        assert abs(float(r['regret'])-float(r['first_interval_regret'])-float(r['last_interval_regret']))<1e-10
        seeds[r['split']].add(int(r['seed']))
    assert len(rows)==84480 and not seeds['Development'].intersection(seeds['Held out'])
    selections=read('stretch_selected.csv')
    for r in selections:
        m=int(r['m']);q=law_weights(r['law'],m);scores=[]
        for gap in (.025,.05,.10,.20,.40):
            for sign in (-1,1):
                avg=np.mean([sum(q[j]*data['Development',m,gap,sign,j,'Revealed-stretch MOSS',rep]
                                      for j in range(m+1)) for rep in range(64)])
                scores.append((avg,gap,sign))
        best=max(scores,key=lambda x:x[0])
        assert best[1:]==(float(r['gap']),int(r['sign']))
    summary=read('stretch_summary.csv')
    for r in summary:
        m=int(r['m']);q=law_weights(r['law'],m);gap=float(r['gap']);sign=int(r['sign'])
        risks={method:np.array([sum(q[j]*data['Held out',m,gap,sign,j,method,rep]
                                      for j in range(m+1)) for rep in range(128)])
               for method in ('Revealed-stretch MOSS','MC-MOSS')}
        v=risks[r['method']];diff=risks['MC-MOSS']-risks['Revealed-stretch MOSS']
        assert abs(v.mean()-float(r['mean_regret']))<1e-10
        assert abs(v.std(ddof=1)/math.sqrt(128)-float(r['mc_se']))<1e-10
        assert abs(diff.mean()-float(r['mean_MC_minus_informed']))<1e-10
        assert abs(diff.std(ddof=1)/math.sqrt(128)-float(r['paired_mc_se']))<1e-10
    report=dict(status='passed',raw_trajectory_count=len(rows),interval_sum_checks=len(rows),
                independent_development_selections=len(selections),heldout_summary_rows=len(summary),
                development_heldout_seeds_disjoint=True,development_rows=sum(r['split']=='Development' for r in rows),
                heldout_rows=sum(r['split']=='Held out' for r in rows))
    (ROOT/'stretch_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
