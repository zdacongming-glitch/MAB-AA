# Fixed two-batch stretch experiment

Run from the reconstruction root:

```text
python experiments_v2/stretch_experiment.py
python figures_v2/gen_fig_stretch.py
```

The script uses the fixed template with two candidates per batch, relative lifetimes $(4,1)$, and one initial anchor. The endpoint is $T=4\cdot4^m$, with $m=3,4,5,6$. The support of $H$ is $1,4,\ldots,4^m$. Three laws are evaluated by exact discrete weighting: probabilities proportional to $2^{-j}$, uniform probabilities over scales, and a point mass at the longest scale.

The informed policy is the exact constructive upper-bound rule in `theory/random_positive_results.tex`. At the first arrival it derives the realized stretch from the known endpoint and observed arrival time, then runs independently initialized fixed-horizon MOSS on the three present arms for $3H$ rounds and on all five arms for $H$ rounds. Its index uses the known interval length and present arm count, including the anchor. The comparator is unchanged MC-MOSS with all history retained. Their information classes differ and are explicitly stated in the figure and prose.

The common mean vector is $(0.50,0.45,0.55,0.55+\eta\delta,0.50)$, for $\eta\in\{-1,1\}$ and $\delta\in\{0.025,0.05,0.10,0.20,0.40\}$. There are 64 development and 128 held-out replications at each stratum and grid point. For each pair $(m,Q)$, the development data choose the single mean vector maximizing the informed rule's law-averaged risk. Both methods then face that same vector, for every possible $H$, on independent held-out data. A method is never allowed to choose a different gap after seeing the schedule. All grid points are retained in the released raw data. The selected held-out result is not a continuous-environment minimax estimate and does not optimize MC-MOSS's environment separately.

The base seeds are 841013 for development and 951013 for held-out evaluation. The exact seed is base + 100000m + 1000j + replication, so the two splits and all independent strata have disjoint seeds. Both methods and all gap/sign choices share reward randomness within each replication and scale. Across scales, replications are independent. The reported standard error is the sample standard deviation of the probability-weighted per-replication risk divided by the square root of 128. This is exact stratified integration over the arrival law, not a simulation that first samples one schedule per replication.

Before the first batch only the anchor is available and regret is zero. Its complete sufficient statistics are a count of $T-4H$ and a binomial number of successes with probability 0.5. We generate those statistics exactly, retain them for MC-MOSS, and generate all subsequent rewards individually. The informed policy discards those observations according to its definition. Nine checks against the original full-calendar MC simulation verified identical subsequent actions when the same realized prefix count and sum were supplied. All regret from the first arrival through the endpoint is included and split into both batch intervals in the raw data.

The capacity for this template is computed independently from the original hull routine and checked against the formula

$$
\mathcal C(H)=2\sqrt{3H/2}+2\phi(H/2),\qquad \phi(x)=\min\{x,\sqrt x\}.
$$

The complexity $W(Q)$ is evaluated exactly at support points, using the theorem's finite maximization. The dashed figure curve is expected capacity divided by $W$, not risk. The solid curves are actual held-out risks divided by $W$. Four finite endpoints cannot establish an asymptotic rate, and the selected fixed grid need not attain the minimax risk. MC-MOSS outperforms the informed reset construction in all selected cells; this is retained as a limit on finite-sample interpretations of the existence proof.

The final manifest records 84,480 development/held-out stratum trajectories and 111,390,720 explicitly simulated policy rounds, plus the compressed zero-regret prefixes. Of these trajectories, 56,320 belong to the held-out split. The three laws reuse the same strata rather than being counted as three independent experiments. The session run took approximately 10 seconds. Files `stretch_raw.csv`, `stretch_selected.csv`, `stretch_summary.csv`, `stretch_complexities.csv`, and `stretch_manifest.json` contain the complete outputs.
