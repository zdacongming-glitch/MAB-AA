"""Write a narrative using the actual independent assessment records."""
from pathlib import Path
import json
import shutil

R=Path(__file__).resolve().parents[1]
O=R/'assessment/stage2'
first=json.loads((O/'assessment-summary-first-5.json').read_text(encoding='utf-8'))
if first['recommendation']['action']=='report_results':
    for kind in ['batch','summary']:
        shutil.copyfile(O/f'assessment-{kind}-first-5.json',O/f'assessment-{kind}.json')
    shutil.copyfile(O/'assessment-summary-first-5.md',O/'assessment-summary.md')
summary=json.loads((O/'assessment-summary.json').read_text(encoding='utf-8'))
batch=json.loads((O/'assessment-batch.json').read_text(encoding='utf-8'))
items={v['object_id']:v for v in summary['results']}
v=items['overall']
n=summary['executed_rounds']
scores=[r['scores']['overall']['innovation']['score'] for r in batch['rounds']]
t=f'''# 全部第二阶段成果的创新性评估

评估日期：2026-10-13。对象为已完成的正文、数学补充、计算补充和实际验证记录。按 statistical-innovation-assessment 的同一规则进行了 {n} 个隔离上下文独立评分；不评价假设中的未来成果，不以期刊声望或实验规模赋分。

**整体定位：第二级，实质性理论与分析框架创新；当前贡献均值 {v['mean']:.1f}/10。** 样本方差 {v['sample_variance']:.3f}，标准差 {v['standard_deviation']:.2f}，范围 {v['minimum']:.1f}–{v['maximum']:.1f}；有效点分 {v['scored_rounds']}/{n}。整体分来自每轮对核心成果的直接判断，不是下表贡献分的平均。

整体逐轮分数为：{', '.join(f'{x:.1f}' for x in scores)}。五轮整体均判为第二级。低方差描述固定材料下模型判断的稳定程度，不证明判断正确，也不是录用概率或客观价值的置信区间。

## 逐项记录

| 贡献 | 均值 | 样本方差 | 标准差 | 范围 | 层级次数 |
| --- | ---: | ---: | ---: | --- | --- |
'''
for obj in summary['results']:
    counts='；'.join(f'第{k}级 {num}' for k,num in obj['tier_counts'].items())
    t+=f"| {obj['label']} | {obj['mean']:.1f} | {obj['sample_variance']:.3f} | {obj['standard_deviation']:.2f} | {obj['minimum']:.1f}–{obj['maximum']:.1f} | {counts} |\n"
t+=r'''
## 为什么属于第二级，为什么没有自动升级

核心仍是任意确定到达日程的常数因子谱 minimax 刻画：相容的多尺度硬先验使不同尺度能在同一个合法奖励环境中共同变难；全历史的无条件前缀分析使同一个不知道终点和未来到达的策略达到这一成本。这些内容不是在静态 MOSS 保证中直接替换臂数。已有 sleeping bandit 比较器、MOSS 核和 anytime 数据保留原则是工具，不能另算作发明。

本轮的新增实质是随机公共伸缩下的正面结论。固定标签和批次顺序让每个区间的 gap 在所有伸缩值下保持一致；共同末批先验给出合法下界，固定 gap 平均引理和完整区间记账给出匹配上界。由此得到可直接计算的 $W(Q)$，以及 $D(Q)$ 有界与平均确定容量同阶正确之间的对应。这超过再举一个两臂反例，也没有将最优策略风险换一个符号作为定义。

范围仍然实质受限：模板固定，常数依赖模板；终点已知，首批揭示后续时间安排；达到上界的规则是已揭示区间内的 MOSS 重置构造，而非原 MC-MOSS 的新保证。固定模板条件使多批次结构主要进入常数，当前结果还没有识别臂数或批次数增长时的联合几何复杂度。因此，新增定理强化主线，却不意味着整体达到基础概念或范式创新，也不能机械兑现阶段评审中的条件性更高分区间。

实验扩充弥补了具体证据缺口：多尺度合法先验、精确 Bayes 基准、干净的 2×2 消融、强基线、共同环境随机日程和真实多批次实现均完成。它们主要提高可核查性和机制解释，不靠轨迹数或图数增加创新分。概率上界、次模性和整数容量结果依其自身增量评价；评分低于核心并不等于没有数学或应用价值。

分歧最大的是容量—风险对应，评分为 4.3–5.2：几何优化结构有直接先例，评分差别主要在其统计风险解释应占多大分量。所有轮次都认可其越过第二级门槛。新增随机伸缩定理为 6.0–6.1，整体为 6.8–6.9。没有发现需要修正冻结事实的跨轮次冲突。所有对象的未舍入标准差均小于 0.4，且无跨层级分歧，因此按预设规则在五轮结束，没有选择性追加或删除评分。

## 最近邻、核验状态和置信度

最邻近材料包括 [Audibert–Bubeck 的 MOSS](https://www.learningtheory.org/colt2009/papers/022.pdf)、[Degenne–Perchet 的 anytime MOSS](https://proceedings.mlr.press/v48/degenne16.html)、[ballooning bandit](https://arxiv.org/abs/2001.10055)、[Luo–Schapire 的随机时域在线学习](https://proceedings.mlr.press/v32/luo14.html) 和 [Vidal 等的嵌套资源分配](https://www.mit.edu/~jaillet/general/RAP-LB-15.pdf)。已查范围没有直接给出本文完整结论链；这不是穷尽优先权证明。随机时域早期文献的部分全文仍未取得，若发现等价刻画，需要重新评估。

新颖性判断置信度为中。完整解析证明和独立新理论审查均已提供；统一计算核查与三份 PDF 编译通过，独立目录复现也通过。评分代理读取了冻结源文稿、证明和核查记录，但没有在评分回合重新执行模拟或作形式验证。模型代理不等于外部人工审稿人。

若后续只做一项能够实质改变创新定位的研究，优先检验固定模板限制：在至少两批、候选数增长的族上，是否必须出现一个联合描述到达律与批次采样约束的复杂度，而不是把模板吸收到常数中。这属于后续研究方向，不是本轮交付或投稿准备的额外前置要求。

## 执行和材料冻结

各轮只接收同一证据包和评分任务，没有接收历史分数、阶段评审的潜力分数、其他轮次结果或目标期刊排名。每项贡献均先判断性质和层级，再按锚点评分。运行模型和设置由父环境继承，没有切换模型或推理配置；精确模型快照和采样参数未暴露，因此不编造它们。

'''
t+='冻结包：'+batch['packet_id']+'。协议：'+batch['protocol_id']+'。\n\n实际执行标识：'+', '.join(r['context_id'] for r in batch['rounds'])+'。\n\n'
t+='原始记录和机器汇总分别见 stage2/round_r*.json、stage2/assessment-batch.json、stage2/assessment-summary.json。首五轮汇总另行保留。分数只评价当前创新性；本轮不附加重要性、可靠性、表达质量或投稿契合度分数。\n'
(R/'assessment/final_innovation_report.md').write_text(t,encoding='utf-8')
print('Wrote final report using',n,'actual rounds.')
