# Frozen evidence: completed second-stage research

Evaluate current completed innovation. Read the three complete flattened manuscripts, bibliography, literature audit and verification record listed in manifest.json. Do not consult previous assessments, the stage-review ratings, other agents' results or venue ranking. File paths are organizational labels only. Do not count proof length, simulations, reporting polish or theorem count as novelty.

The core experiment has deterministic exogenous permanent arm arrivals, arbitrary finite batches, independent stationary bounded reward laws, and regret against the largest available mean. The deterministic lower bound permits advance knowledge of the schedule and horizon. One history-retaining upper policy knows neither. The separate random experiment has a fixed reward environment chosen before an independent schedule draw; policies may know the endpoint and arrival law, but see arrivals causally.

| ID | Completed contribution | Role |
| --- | --- | --- |
| c1 | Schedule-wise spectral minimax equivalence; one compatible multiscale hard prior; one causal unknown-horizon upper rule | Core |
| c2 | Lifetime fixed point as Euclidean norm, effective scale count and sharp square-root-log separation | Explanation of core |
| c3 | Full-history clock reset analysis and actual logarithmic versus squared-logarithmic cold-reset separation | Supporting principle, overlaps c1 |
| c4 | Concave occupancy capacity and its equivalence to risk; computable hull representation | Statistical representation; optimization predecessors explicit |
| c5 | Probability lower bound, stability, gap bound, uniform learning boundary and other corollaries | Auxiliary; distinguish consequences from independent advances |
| c6 | Capped cut and mixture identities, submodularity specialization, sharp integer capacity constant | Auxiliary geometry; general optimization mechanisms established |
| c7 | Independent-random-schedule logarithmic separation between expected conditional capacity and joint risk | Boundary result |
| c8 | Fixed-template common-random-stretch minimax characterization by W(Q), executable revealing rule, and bounded-D criterion for validity of averaging | New positive theory; overlaps c7, fixed-template only |
| overall | Entire current contribution, assessed directly from its core and interaction | Never average or add the contribution scores |

For c8, finite fixed disjoint batches have relative lifetimes alpha_1 > ... > alpha_b = 1. Positive integer H has known finite law Q, every alpha_j H is integral, and known T is at least alpha_1 max H. The first batch reveals H through its time. Reward laws are fixed before H. The complexity is

$$
W(Q)=\sup_{x\ge1}\frac{\mathbb E\min(H,x)}{\sqrt x}
=\max_{h\in\operatorname{supp}(Q)}\frac{\mathbb E\min(H,h)}{\sqrt h}.
$$

The theorem bounds joint risk between W/32 and A_template W, with explicit finite template-dependent A. The upper rule uses fresh fixed-horizon MOSS on every revealed batch interval and includes every post-first-batch loss; the lower bound uses a single final-candidate sign prior fixed across all H and remains valid even if H is revealed at the start. The average deterministic capacity/joint risk ratio is equivalent, with template-dependent constants, to D(Q)=E sqrt(H)/W(Q). This is not uniform or optimal as the template grows, not a guarantee for anytime MC-MOSS, and not a characterization of nonrevealing random schedules. The weak tail functional itself is a familiar probability quantity; its role in this specific experiment is what is claimed. The raw ingredients MOSS, gap integration and two-point testing have predecessors. Judge their statistical interaction, rather than crediting their names or the new notation.

The numerical expansion contains compatible priors over four endpoints and multiple scales, paired schedules and crossed environments, an exact finite-prior Bayes DP, complete 2x2 clock/capacity interventions, history pairs, KL-UCB and TS, five mean families and two label orders, lifetime-by-gap surfaces, disjoint development/held-out risk selection, and a fixed multi-batch stretch implementation. Negative comparisons remain in the text. The Bayes DP uses a standard posterior Bellman recursion and is not claimed as a new statistical method. None of the simulations estimates the continuous minimax supremum or proves an asymptotic rate.

The earlier fixed point is internal to this project, not an external established optimal benchmark. MOSS, data retention, nested resource allocation and general concave-polymatroid submodularity are prior tools. The integer constant compares capacities, not regret constants. No arbitrary sleeping availability, reward-dependent arrival, sharp tail, instance-optimality or empirical dominance claim is made. Literature checks are bounded and some early related full texts remain unavailable. Current evidence supports assessment but not exhaustive priority certification.
