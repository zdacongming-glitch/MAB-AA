"""Verify the saved studies, rerun all experiments, and build three documents."""
from pathlib import Path
import argparse
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'audit' / 'execution_logs'
LOG.mkdir(parents=True, exist_ok=True)
DOCUMENTS = ('manuscript', 'supplement', 'computational_supplement')

def run(args, name):
    with (LOG / (name + '.log')).open('w', encoding='utf-8') as stream:
        result = subprocess.run(args, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
    if result.returncode:
        raise SystemExit(f'Failed: {name}; see {LOG / (name + ".log")}')
    print(f'Passed: {name}', flush=True)

def build():
    for command in ['pdflatex', 'bibtex']:
        if not shutil.which(command):
            raise SystemExit(f'{command} is required for --build.')
    for stem in DOCUMENTS:
        if not (ROOT / (stem + '.tex')).is_file():
            raise SystemExit(f'Missing document source: {stem}.tex')
    # All .aux files must exist before the final cross-reference passes.
    for stem in DOCUMENTS:
        run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', stem + '.tex'], stem + '_initial')
        aux = (ROOT / (stem + '.aux')).read_text(encoding='utf-8', errors='replace')
        if r'\bibdata{' in aux:
            run(['bibtex', stem], stem + '_bibtex')
    for iteration in range(3):
        for stem in DOCUMENTS:
            run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', stem + '.tex'], f'{stem}_pass_{iteration + 1}')
    report = {}
    for stem in DOCUMENTS:
        log = (ROOT / (stem + '.log')).read_text(encoding='utf-8', errors='replace')
        issues = [line for line in log.splitlines() if any(word in line for word in ['LaTeX Warning:', 'Package natbib Warning:', 'Overfull', 'multiply defined', 'undefined'])]
        report[stem] = {'issues': issues, 'output': re.findall(r'Output written on[^\n]+', log)}
    (ROOT / 'audit' / 'build_report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    if any(item['issues'] for item in report.values()):
        raise SystemExit('Build completed with issues; inspect audit/build_report.json.')

def python(script, name, *options):
    run([sys.executable, '-X', 'utf8', script, *options], name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true',
                        help='run all theory diagnostics, exact Bayes DP, software audits and saved-data verifiers (default)')
    parser.add_argument('--full', action='store_true',
                        help='rerun the original study and all stage-two studies, regenerate figures/tables, then verify')
    parser.add_argument('--stage2', action='store_true',
                        help='rerun A, B, C and the two-batch stretch study; regenerate their figures/tables, then verify')
    parser.add_argument('--figures', action='store_true',
                        help='regenerate all figures and TeX tables from saved raw data without rerunning simulations')
    parser.add_argument('--build', action='store_true',
                        help='compile manuscript, theory supplement and computational supplement')
    args = parser.parse_args()
    if not any(vars(args).values()):
        args.verify = True
    rerun_stage2 = args.full or args.stage2
    if args.full:
        for name in ['audit_geometry', 'test_online_api', 'policy_diagnostics']:
            python(f'experiments/original_snapshot/{name}.py', name)
        python('experiments/run_experiments.py', 'original_bernoulli_study',
               '--replications', '256', '--horizon', '16384', '--seed', '20261013')
    if rerun_stage2:
        python('experiments_v2/geometry_run.py', 'stage2_A_geometry', '--reps', '128')
        python('experiments_v2/mechanisms_run.py', 'stage2_B_development',
               '--replications', '2', '--seed', '41061013', '--development')
        python('experiments_v2/mechanisms_run.py', 'stage2_B_mechanisms',
               '--replications', '128', '--seed', '73061013')
        python('experiments_v2/random_arrivals.py', 'stage2_C_random_arrivals',
               '--train', '64', '--test', '128', '--max-m', '7', '--seed', '2026101303')
        python('experiments_v2/stretch_experiment.py', 'stage2_stretch')
        python('experiments_v2/bayes_exact.py', 'stage2_exact_Bayes_DP')
    if args.full or args.figures:
        python('figures/gen_fig_experiments.py', 'original_figures_tables')
    if rerun_stage2 or args.figures:
        python('experiments_v2/geometry_analyze.py', 'stage2_A_figures_tables')
        # This verifier also writes the main-text baseline table from saved CSVs.
        python('experiments_v2/mechanisms_verify.py', 'stage2_B_table_and_verify')
        python('figures_v2/gen_fig_mechanisms.py', 'stage2_B_figures')
        python('figures_v2/plot_random_arrivals.py', 'stage2_C_figures')
        python('figures_v2/gen_fig_stretch.py', 'stage2_stretch_figures')
    if args.verify or rerun_stage2:
        python('theory/check_new_results.py', 'original_theory_diagnostics')
        python('theory/check_random_positive.py', 'stage2_positive_theory_diagnostics')
        if not rerun_stage2:
            python('experiments_v2/bayes_exact.py', 'stage2_exact_Bayes_DP')
        python('experiments/verify_release.py', 'original_release_verification')
        python('experiments_v2/geometry_verify.py', 'stage2_A_verification')
        python('experiments_v2/mechanisms_run.py', 'stage2_B_policy_audit', '--audit-only')
        if not (rerun_stage2 or args.figures):
            python('experiments_v2/mechanisms_verify.py', 'stage2_B_data_verification')
        python('experiments_v2/random_verify.py', 'stage2_C_verification')
        python('experiments_v2/stretch_verify.py', 'stage2_stretch_verification')
    if args.build:
        build()


if __name__ == '__main__':
    main()
