# 随机到达正面定理独立技术审计

审计日期：2026-10-13。审计角色：与稿件写作分离的数学复核；不评分。

**结论：Complete proof——在稿件明确限定的独立同分布奖励、有限支持共同伸缩、已知终点和固定模板信息类下，主定理、三个辅助引理及容量比较推论的证明义务均闭合。** 未发现错误交换 minimax 与期望、非法按日程选择环境、冷重置的条件独立性错误，或影响主定理的常数缺口。审计发现一处例子推广的整除说明遗漏，已按主审要求仅补充相关三处说明，详见下文；该遗漏不否定主定理。

本报告按 `prove-stat-ml-probability-theorems/SKILL.md`、`references/proof-protocol.md` 和 `references/adversarial-audit.md` 做解析审计。完整阅读 `theory/random_positive_results.tex`、`theory/random_positive_research.md`、主文新增随机到达定理与说明，并核验 `sections/S1_spectral_proofs.tex` 的 `lem:Z`、原模型与容量定义，以及 `experiments_v2/bayes_supplement.tex` 的有限先验 Bellman 命题。没有阅读阶段评价分数或创新评估文件，没有将稿件自评作为证明证据，也没有把数值检查当作证明。本报告不构成外部同行评审或形式化认证。

## 1. 冻结的命题与假设

固定有限个非空批次、标签、相对寿命及其顺序。设 $H\sim Q$ 为有限支持正整数随机变量，且每个 $\alpha_jH$ 是整数；终点 $T$ 固定、已知并覆盖最大寿命。到达时间为 $T-\alpha_jH+1$，因此每个区间长度 $d_jH$ 是正整数。

量词顺序为：给定模板、$T,Q$，策略可利用这三项；任意奖励环境 $P$ 先固定，随后独立抽取 $H$ 和奖励流。最终风险为

$$
\inf_\pi\sup_P\mathbb E_{H\sim Q,P}^{\pi}R_T.
$$

| 假设或约定 | 来源与状态 | 在证明中的用途 |
|---|---|---|
| 每臂奖励为独立同分布的 $[0,1]$ 变量，臂间独立 | `sections/02_geometry.tex` 原模型，给定 | MGF、Hoeffding、未来奖励重构及动态 KL |
| 日程尺度与奖励、策略随机化独立 | 正面定理明确给定 | 条件于 $H$ 后奖励法律不变 |
| 每个 $P$ 对所有 $H$ 相同 | joint minimax 定义，给定 | 固定 gap 的平均上界及共同环境下界 |
| 标签及批次顺序固定 | 给定 | 每一区间的 gap 向量不随 $H$ 改变 |
| 模板、终点已知，首批揭示 $H$ | 给定并由到达式推出 | 区间 MOSS 的 horizon 使用合法 |
| 正整数支持及整除条件 | 给定 | 整数测试窗口、合法轮次和缩放恒等 |
| 丢弃全部统计量 | 仅上界策略选择 | 支持条件于过去的全新局部实验，不限制下界策略 |
| 常数可依赖整个模板 | 明示 | 不推出对增长臂数、批次数或相对寿命的一致速率 |

“stationary distributions” 必须按原模型的独立同分布奖励流解释；若另行改为仅平稳、时间相关的奖励过程，本文集中与冷重置证明均不自动适用。当前稿件已由原模型给出足够假设，并无实际缺口。

## 2. 正面定理的逐项核验

### 2.1 $W$ 的有限最大化、尾界和缩放

对应 `theory/random_positive_results.tex:263–288`。在相邻支持点间，函数为 $u/\sqrt{x}+v\sqrt{x}$，导数符号为 $vx-u$；唯一可能的内部临界点为极小值。最小支持点左侧单调上升，最大支持点右侧单调下降。有限支持点处的最大化结论成立，也覆盖单点分布、支持包含 $1$、两点分布及支持有大间隔的情形。

特别核验了 $d<1$ 的情形：仅做连续变量替换会把约束 $x\ge1$ 改为 $x\ge1/d$，不能直接略过。稿件使用支持点最大化，在 $H$ 与 $dH$ 均为正整数的假设下给出

$$
W_{dH}
=\max_{h\in\operatorname{supp}(Q)}
\frac{\mathbb E\min\{dH,dh\}}{\sqrt{dh}}
=\sqrt d\,W(Q).
$$

因此缩放恒等没有定义域遗漏。有限最大化的证明不依赖 regret 上下界，虽排版在平均引理之后，逻辑上不循环。

对任意 $t>0$，若 $h$ 是严格大于 $t$ 的最小支持点，则 $\mathbb P(H>t)=\mathbb P(H\ge h)\le V/\sqrt h\le V/\sqrt t$。最大支持点外尾概率为零。因此尾积分给出 $W\le2V$，而 $\min(H,h)\ge h\mathbf 1\{H\ge h\}$ 给出 $V\le W$。在原子点使用严格尾概率不造成误差，积分不受有限个端点影响。

### 2.2 固定 gap 平均不等式

对应 `theory/random_positive_results.tex:162–197`。固定 $0<\Delta\le1$，令 $x=\Delta^{-2}\ge1$。对 $L\le x$ 使用 $L\Delta$，对 $L>x$ 使用另一项。所有被积项非负，且 $L$ 有限支持。独立复算为

$$
\sqrt x\left[a\mathbb P(L>x)+b\int_x^\infty\frac{\mathbb P(L>t)}t\,dt\right]
\le(a+2b)W_L.
$$

小寿命部分至多 $W_L$，总系数确为 $1+a+2b$。该引理不允许将 $\Delta$ 换成依赖 $H$ 的值；上界应用中使用固定标签、固定区间的确定 gap，满足要求。

### 2.3 `lem:Z` 及 MOSS 局部常数

对应 `sections/S1_spectral_proofs.tex:3–44` 与正面证明 `116–159`。已重新核验 Hoeffding MGF 超鞅、无限前缀阈值不等式和 dyadic peeling。对块 $m_k<n\le2m_k$，所用阈值 $m_kx+\sqrt{m_kk\log2}$ 有效；平方展开后舍弃非负交叉项，恰给出 $2^{-k}\exp\{-vx^2/2^{k+1}\}$。多项式尾求和给出 $5/(vx^2)$，严格尾到非严格尾的极限步骤合法。

固定一个最优臂后，局部 MOSS 的四项 regret 上界分别为

$$
\frac{20k}{\Delta},\qquad
\frac1\Delta,\qquad
\frac8\Delta,\qquad
\frac{1+16\log(n\Delta^2)}\Delta
\quad(n\Delta^2\ge1).
$$

其和为 $[20k+10+16\log(n\Delta^2)]/\Delta$。关键计数步骤是每次选同一臂前的计数 $r$ 不重复，因此可对全部确定前缀求和，无需也没有声称随机计数与均值独立。若所选臂已观察而固定最优臂未观察，其无限 index 会阻止该选择，故 index 比较合法。

已核验 $n<k$、最优臂不唯一、$n\Delta^2=1$ 与 $n\Delta^2<1$。后者由确定界 $n\Delta<1/\Delta$ 覆盖。小区间中尚未初始化的臂不会破坏结论。将 $a=20k+10,b=16$ 代入平均引理，确得 $20k+43$。

### 2.4 冷重置与完整前缀信息

对应 `theory/random_positive_results.tex:292–320`。条件于 $H=h$，所有区间边界为确定时刻。采用每标签、每日历轮次独立的 $X_{i,t}\sim P_i$，对每次因果动作仅揭示当前 $X_{I_t,t}$，通过逐轮条件分布相同可知其观测法律与原潜在拉取序列相同。

在区间边界，过去只由过去日历变量、日程和独立策略随机化生成；未来日历变量与这个 sigma-field 独立。清空统计量后重新运行确定 tie rule 的 MOSS，条件于完整过去及 $H$，其观测实验满足局部引理。因此该步骤没有把旧经验均值错误地当作条件独立的新样本。

首批之前只有锚臂，regret 为零。其后区间不重叠并覆盖所有剩余轮次；每一区间至多 $k_j-1$ 个正 gap。最佳可用臂可随区间改变，但不随 $H$ 改变。所有前缀 regret 均已计费。

### 2.5 公共环境、Bernoulli KL 与下界常数

对应 `theory/random_positive_results.tex:199–259`。测试尺度 $x$ 从已知 $Q$ 的支持中选取，随后固定两环境，唯一改变最后批次一个新标签的 Bernoulli 均值，取 $\delta=1/(8\sqrt x)$。环境及二点先验均不依赖实现后的 $H$。

条件于 $H=h$，该标签出现前的全部奖励、动作及策略随机化的联合分布在两环境中相同。此前所有批次的适应性抽样均不会泄露符号。截取该标签出现后的最初 $\ell_h=\min(h,x)$ 轮。保留完整此前历史后，动态 likelihood 仍仅由该标签的观测产生。独立复算：

$$
\operatorname{kl}(1/2-\delta,1/2+\delta)
=2\delta\log\frac{1+2\delta}{1-2\delta}
\le\frac{8\delta^2}{1-2\delta}
\le16\delta^2,
$$

$$
\operatorname{KL}(\mathbb P_{-,h},\mathbb P_{+,h})
=\mathbb E_{-,h}N\,\operatorname{kl}(1/2-\delta,1/2+\delta)
\le16\delta^2\ell_h\le\frac14.
$$

策略 kernels 在两环境中相同；策略随机种子是同一独立分布，故将其纳入历史不会增加未计的 KL。Pinsker 给出 total variation 至多 $1/\sqrt8<1/2$。因 $0\le N\le\ell_h$，两个期望的差至多 $\ell_h/2$。二点平均 regret 因而至少为

$$
\frac\delta2\left[\ell_h+\mathbb E_{-,h}N-\mathbb E_{+,h}N\right]
\ge\frac{\min(h,x)}{32\sqrt x}.
$$

最后先对 $h$ 平均，再在两个固定环境中选整体风险较大的一个。量词是“对每个策略，存在一个不依赖 $H$ 的环境”，而不是“对每个 $h$，另选一个环境”。提前把 $H$ 告诉策略时，条件历史同分布及 KL 链式分解仍有效。无须隐藏日程，亦不需要假设策略忽略旧样本。

### 2.6 容量推论及常数范围

对应 `theory/random_positive_results.tex:323–354`。单个末批候选分配 $h$ 次给出 $\sqrt h$ 下界。全部非锚臂的寿命至多为整数 $\alpha_1h$；容量约束在该整数处给出总分配不超过 $\alpha_1h$。由 $\phi(n)\le\sqrt n$ 与 Cauchy–Schwarz 得到上界 $\sqrt{(K-1)\alpha_1h}$。由此与主定理组合得到稿件两个显式比例常数，方向正确。

逐点 $\min(H,x)/\sqrt x\le\sqrt H$，所以 $D\ge1$。“当且仅当 $D$ 有界”是对固定模板的族成立；它不暗含增长模板的一致常数。点质量和固定乘法区间例子正确。

## 3. 已修正的一处整除说明

位置：`theory/random_positive_results.tex:360–368`、`sections/06_random_arrivals.tex:123–125`，研究记录中也有对应的“任何固定多批次模板”推广句。

所显示的原始几何分布 $\mathbb P(H=4^j)=c_m2^{-j}$ 包含 $H=1$，因此只直接适用于所有 $\alpha_j$ 均为整数的模板。举例，合法模板 $\boldsymbol\alpha=(4/3,1)$ 可以配合 $H\in\{3,12,48,\ldots\}$，却不能配合包含 $1$ 的原始几何分布。故将这一个分布不加说明地直接用于“每个固定模板”会违反已声明的整数到达假设。

这不是主定理反例，修补无需改变结论。任一具有非空合法支持的模板，其所有 $\alpha_j$ 必为有理数。固定一个正整数 $q$ 使所有 $q\alpha_j$ 为整数，令 $H=q4^J$。取相应合法整数终点，则

$$
W(H)=\sqrt q\,W(4^J)<3\sqrt q,
\qquad
\mathbb E\sqrt H=\sqrt q\,c_m(m+1).
$$

固定模板时 $q$ 固定，所述 order-one 对 logarithmic 分离完全保留。按主审随后要求，已仅在正面证明、主文和研究记录三处推广句补充这一共同整数伸缩，并复核修补后假设与结论匹配；未改动定理、引理或证明常数。

## 4. 主文与研究记录的忠实性

`sections/06_random_arrivals.tex` 新增 theorem 的上下界、常数、因果策略、提前给 $H$ 的下界信息类，以及对 MC-MOSS、未知终点、非揭示模板和增长模板的限制，均与技术证明一致。没有把存在性冷重置策略的界移植给 MC-MOSS，也没有把固定模板常数说成普适常数。

研究记录中的六项核心证明义务均由解析证明兑现，其“数值仅作有限诊断”的限定准确。本次审计未运行或核验记录所列的测试数量，不能据本报告进一步声称这些数字已独立复现。上一节整除说明修补后，没有发现实质性主文扩张。

## 5. 有限先验动态规划命题

已审 `experiments_v2/bayes_supplement.tex:17–40` 的 `prop:exact-finite-bayes`。该命题在所述有限 Bernoulli 先验、严格位于 $(0,1)$ 的有理均值、正有理先验权重、已知确定日程下成立。

固定一条观察历史，策略动作 kernels 对每个环境相同，因而 posterior likelihood 中的环境依赖只来自每臂成功及失败次数。即使多个历史有同一个计数状态，对这些历史求和仍只乘上与环境无关的因子；故状态压缩适用于适应性采样。均值在先验下恒定的臂，其奖励不提供环境信息，舍去这些观测不影响 posterior；它们只能额外提供随机化，而有限动作最小化不受益于这种随机化。时间索引 $t$ 保留了已消耗的轮数。

给定状态及动作，下一奖励的预测概率为 $q_i(s)$，当前条件平均 pseudo-regret 为 $g_t(i,s)$。有限时域逐步最小化即是所有因果策略的 Bayes 最优值。正均值及正先验保证所有到达状态的 posterior 分母严格为正。有理数的加、乘、除和有限取最小保持有理，状态数有限。因此“可用精确分数实现”和“随机化不能改善最小值”均有严格根据。

对每一策略先用 supremum 大于先验平均，再取 infimum，得到该最优 Bayes 值不超过确定日程 minimax risk。允许策略知道已固定的先验只是把其参数硬编码在一个可行策略中，不会逆转不等式；已知完整日程也与稿件的确定日程 minimax 信息类一致。

本次只认证该命题的数学论证；未独立执行代码、复算表格或验证全奖励树积分声明，因此不据此认证实现及八个报告数字。

## 6. 反例搜索与未扩张的结论

已检查的攻击点包括：$H=1$、点质量、稀疏两点混合、大范围支持、单批次、多臂同时到达、多个最佳臂、区间短于臂数、$d_j<1$、非整数相对寿命、$n\Delta^2$ 的边界、奖励退化为常数、随机前缀计数、提前揭示整个日程、以及前缀长度依赖 $H$。其中分数模板与原几何例子的整除冲突已在第 3 节记录，其余攻击不破坏被审定理。

本审计没有证明：一般有限日程混合的对应复杂度、仅平稳且相关奖励下的延拓、对增长模板的一致常数、MC-MOSS 达到 $W(Q)$，或该结果的文献新颖性。以上均不应从本次结论推出。

## 7. 审阅版本

以下 SHA-256 对应本次最初完整阅读的文件，便于识别审计发现来源。行号亦针对该版本；第 3 节所述三处说明修补属于本次审计后的明确改动。

| 文件 | SHA-256 |
|---|---|
| `theory/random_positive_results.tex` | `6BC13AFAA00551938A7F92056F8840F86C263A14F85CD37AB17A3E37B49DCBBB` |
| `theory/random_positive_research.md` | `FE79DA78DD307BA2ABB2A974D8B3E0BDDB027FC48BB1959982F2C8B8BB0D49AD` |
| `sections/06_random_arrivals.tex` | `11C9DBEAD60872C25F5CD8E86A9D11B9FF1832D3EB2DC7C2AC025B2D4B2F7761` |
| `sections/S1_spectral_proofs.tex` | `918237FB2BA83968C55F1F1933425AB090C1AAF10D1170E3025BE53145603A66` |
| `experiments_v2/bayes_supplement.tex` | `C8E9B37D5B402C59A2403B6347345720E0C803BDD1873DBC1CBAB50BEB063E5D` |

整除说明修补后的三个文件 SHA-256：

| 文件 | 修补后 SHA-256 |
|---|---|
| `theory/random_positive_results.tex` | `BF8EA5DDCF8A964064C2C0BD8897185207578E89D9070A60C6E34092DA029379` |
| `theory/random_positive_research.md` | `4752E1768CC981FA2EA0BF2FA42F1E11EF3FE632DE9AF3FEEF50CAF154E6DB92` |
| `sections/06_random_arrivals.tex` | `195C7E2178CF71B443410E774B33A4D3D796EE3EAAA5421606DC85D0B1E7109A` |

已检查本次新建或修改的两个 Markdown 文件：没有反斜杠圆括号或方括号数学定界符；所有独立公式的双美元定界符各自独占一行，且成对出现。
