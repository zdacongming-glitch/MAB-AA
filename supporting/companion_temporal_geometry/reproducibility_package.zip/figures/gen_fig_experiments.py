"""Regenerate all figures and TeX tables from saved CSV files."""
from pathlib import Path
import csv
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / 'experiments'
METHODS = ('MC-MOSS', 'Cold MOSS', 'Full-history UCB', 'Global-clock MOSS')
COLORS = ['#0072B2', '#D55E00', '#009E73', '#CC79A7']
STYLES = ['-', '--', '-.', ':']
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'DejaVu Serif'],
                     'font.size': 9, 'axes.titlesize': 9, 'axes.labelsize': 9,
                     'legend.fontsize': 8, 'legend.frameon': False,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.alpha': .15,
                     'lines.linewidth': 1.6, 'savefig.bbox': 'tight',
                     'pdf.fonttype': 42, 'ps.fonttype': 42})


def rows(name):
    with (DATA / name).open(encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def save(fig, name):
    fig.savefig(ROOT / (name + '.pdf'))
    fig.savefig(ROOT / (name + '.png'), dpi=300)
    plt.close(fig)


data = rows('trajectory_regret.csv')
horizon = int(rows('raw_regret.csv')[0]['T'])
scenarios = ['Early batch', 'Late batch', 'Regular arrivals', 'Multiscale arrivals']
configs = ['Persistent incumbent', 'Improving records']
fig, axes = plt.subplots(2, 4, figsize=(7.1, 4.0), sharex=True)
for r, config in enumerate(configs):
    for c, scenario in enumerate(scenarios):
        ax = axes[r, c]
        for i, method in enumerate(METHODS):
            selected = [row for row in data if row['configuration'] == config
                        and row['scenario'] == scenario and row['method'] == method]
            times = sorted({int(row['time']) for row in selected})
            means, ses = [], []
            for t in times:
                values = np.array([float(row['regret']) for row in selected if int(row['time']) == t])
                means.append(values.mean())
                ses.append(values.std(ddof=1) / math.sqrt(len(values)))
            means, ses = np.array(means), np.array(ses)
            x = np.array(times) / horizon
            ax.plot(x, means, label=method, color=COLORS[i], linestyle=STYLES[i])
            ax.fill_between(x, means - 1.96 * ses, means + 1.96 * ses, color=COLORS[i], alpha=.13)
        if r == 0:
            ax.set_title(scenario)
        if c == 0:
            ax.set_ylabel(config + '\nPseudo-regret')
        if r == 1:
            ax.set_xlabel('Fraction of horizon')
        ax.set_xticks([0, .5, 1])
        ax.set_ylim(bottom=0)
handles, labels = axes[0, 0].get_legend_handles_labels()
fig.legend(handles, labels, loc='upper center', ncol=4, bbox_to_anchor=(.5, 1.045), columnspacing=1)
fig.tight_layout(w_pad=.6, h_pad=1)
save(fig, 'fig_policy_comparison')


det = rows('original_snapshot/policy_results.csv')
geo = rows('geometry_separation.csv')
fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.7))
for policy, label, color, style in [('clock-only', 'MC-MOSS', COLORS[0], '-o'),
                                     ('cold-reset', 'Cold MOSS', COLORS[1], '--s')]:
    sub = [r for r in det if r['family'] == 'tied_deterministic' and r['policy'] == policy]
    axes[0].plot([int(r['m']) for r in sub], [float(r['regret']) for r in sub],
                 style, label=label, color=color, markersize=4)
axes[0].set_xlabel('Number of count-doubling segments')
axes[0].set_ylabel('Deterministic pseudo-regret')
axes[0].set_title('(a) Finite trajectories: segment length 65,536')
axes[0].legend()
for family, color, style in [('Multiscale', COLORS[0], '-o'), ('Concentrated', COLORS[1], '--s')]:
    sub = [r for r in geo if r['family'] == family]
    axes[1].plot([int(r['m']) for r in sub], [float(r['S']) / float(r['Gamma']) for r in sub],
                 style, label=family, color=color, markersize=4)
axes[1].set_xlabel(r'Scale parameter $m$, with $T=16^m$')
axes[1].set_ylabel(r'$\mathscr{S}_T/\Gamma_T$')
axes[1].set_title('(b) Arrival geometry, equal final arm counts')
axes[1].legend()
fig.tight_layout(w_pad=2)
save(fig, 'fig_structural_diagnostics')


bound = rows('analytic_restart_bounds.csv')
fig, ax = plt.subplots(figsize=(3.4, 2.6))
xx = [float(r['log_T']) for r in bound]
ax.loglog(xx, [float(r['history_regret_upper_bound']) for r in bound], '-o',
          label='History: proved upper bound', color=COLORS[0], markersize=3)
ax.loglog(xx, [float(r['cold_regret_lower_bound']) for r in bound], '--s',
          label='Cold: proved lower bound', color=COLORS[1], markersize=3)
ax.set_xlabel(r'$\log T$ for $h=2^{16m}$ and $T=mh$')
ax.set_ylabel('Analytic regret bound')
ax.legend(fontsize=7)
fig.tight_layout()
save(fig, 'fig_analytic_restart_bounds')


summary = rows('summary.csv')
tex = [r'\begin{tabular}{llrrrr}', r'\toprule',
       r'Mean configuration & Arrival schedule & MC-MOSS & Cold MOSS & UCB & Global MOSS \\', r'\midrule']
for config in configs:
    for scenario in scenarios:
        vals = []
        for method in METHODS:
            row = next(r for r in summary if r['configuration'] == config and r['scenario'] == scenario and r['method'] == method)
            vals.append(f"{float(row['mean_regret']):.1f} ({float(row['mc_se']):.2f})")
        short_config = 'Incumbent' if config == configs[0] else 'Records'
        tex.append(short_config + ' & ' + scenario + ' & ' + ' & '.join(vals) + r' \\')
    if config == configs[0]:
        tex.append(r'\addlinespace')
tex.extend([r'\bottomrule', r'\end{tabular}'])
(DATA / 'table_regret.tex').write_text('\n'.join(tex) + '\n', encoding='utf-8')

geom = rows('arrival_geometry.csv')
tex = [r'\begin{tabular}{lrrrrr}', r'\toprule',
       r'Arrival schedule & $\mathscr S_T$ & $\mathscr C_T$ & $\Gamma_T$ & $Q_T$ & $D_T^{\rm eff}$ \\', r'\midrule']
for row in geom:
    vals = [f"{float(row[k]):.2f}" for k in ['S', 'C', 'Gamma', 'Q', 'D_eff']]
    tex.append(row['scenario'] + ' & ' + ' & '.join(vals) + r' \\')
tex.extend([r'\bottomrule', r'\end{tabular}'])
(DATA / 'table_geometry.tex').write_text('\n'.join(tex) + '\n', encoding='utf-8')

paired = rows('paired_differences.csv')
def value(scenario, config, method, key='mean_regret'):
    return float(next(r for r in summary if r['scenario'] == scenario and r['configuration'] == config and r['method'] == method)[key])
def difference(scenario, config, baseline, key):
    return float(next(r for r in paired if r['scenario'] == scenario and r['configuration'] == config and r['baseline'] == baseline)[key])

paragraph = (
    'Table~\\ref{tab:regret} and Figure~\\ref{fig:policy-comparison} show that '
    'history retention matters in the regular and multiscale schedules. '
    f"For regular arrivals with a persistent incumbent, MC-MOSS has mean regret {value('Regular arrivals', configs[0], METHODS[0]):.1f}, "
    f"compared with {value('Regular arrivals', configs[0], METHODS[1]):.1f} for Cold MOSS. "
    f"The paired mean reduction is {difference('Regular arrivals', configs[0], METHODS[1], 'mean_baseline_minus_MC'):.1f} "
    f"with Monte Carlo standard error {difference('Regular arrivals', configs[0], METHODS[1], 'paired_mc_se'):.1f}. "
    'MC-MOSS also has lower regret than the global/current comparison in these two schedules. That comparison changes both the clock and capacity calibration, so it does not isolate either effect. '
    'When every competitor arrives at time one, the three MOSS rules make identical decisions. '
    'The late-batch example gives a counterpoint: with a persistent incumbent, '
    f"Cold MOSS has mean regret {value('Late batch', configs[0], METHODS[1]):.2f}, "
    f"versus {value('Late batch', configs[0], METHODS[0]):.2f} for MC-MOSS. "
    f"The paired Cold-minus-MC difference is {difference('Late batch', configs[0], METHODS[1], 'mean_baseline_minus_MC'):.2f} "
    f"with standard error {difference('Late batch', configs[0], METHODS[1], 'paired_mc_se'):.2f}. "
    'History retention therefore does not yield pointwise dominance, even in this small comparison.\n'
)
(DATA / 'results_paragraph.tex').write_text(paragraph, encoding='utf-8')
print('Saved three PDF/PNG figure pairs, two TeX tables, and the results paragraph.')
