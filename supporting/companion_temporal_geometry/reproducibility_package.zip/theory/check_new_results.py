"""Finite diagnostics for the new capacity results; not universal proofs."""
from __future__ import annotations

import itertools
import json
import math
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments" / "original_snapshot"))
from geometry import capacity  # noqa: E402


def main() -> None:
    caps = [Fraction(1, 2), Fraction(1), Fraction(3, 2), Fraction(2),
            Fraction(3), Fraction(5), Fraction(7)]
    cut_checks = submod_checks = rounding_checks = integer_checks = 0
    max_cut_error = max_submod_violation = 0.0
    kappa = 2 * 2 ** 0.25 / (1 + math.sqrt(2))
    min_integer_ratio = 1.0
    for horizon in range(1, 7):
        for hs in itertools.combinations_with_replacement(range(1, horizon + 1), 4):
            values = {}
            for mask in range(16):
                selected = [hs[i] for i in range(4) if mask & (1 << i)]
                result = capacity(selected, horizon)
                values[mask] = result["C"]
                for z in caps:
                    direct = sum((min(n, z) for n in result["n_star"]), Fraction(0))
                    cut = min(Fraction(h) + z * sum(x > h for x in selected)
                              for h in range(horizon + 1))
                    assert direct == cut, (horizon, selected, z, direct, cut)
                    max_cut_error = max(max_cut_error, abs(float(direct - cut)))
                    cut_checks += 1
            for a in range(16):
                for b in range(16):
                    violation = values[a | b] + values[a & b] - values[a] - values[b]
                    max_submod_violation = max(max_submod_violation, violation)
                    assert violation < 1e-12, (hs, a, b, violation)
                    submod_checks += 1

            optimum = capacity(hs, horizon)
            best_integer = 0.0
            for counts in itertools.product(range(horizon + 1), repeat=4):
                if all(sum(counts[:r]) <= hs[r - 1] for r in range(1, 5)):
                    best_integer = max(best_integer, sum(math.sqrt(n) for n in counts))
            ratio = best_integer / optimum["C"]
            assert kappa - 1e-12 <= ratio <= 1 + 1e-12
            min_integer_ratio = min(min_integer_ratio, ratio)
            integer_checks += 1

            sums = list(itertools.accumulate(optimum["n_star"], initial=Fraction(0)))
            for u in [Fraction(k, 37) for k in range(37)]:
                counts = [math.floor(sums[i + 1] + u) - math.floor(sums[i] + u)
                          for i in range(4)]
                assert all(sum(counts[:r]) <= hs[r - 1] for r in range(1, 5))
                assert all(n in (math.floor(x), math.ceil(x))
                           for n, x in zip(counts, optimum["n_star"]))
                rounding_checks += 1

    max_random_gap_envelope = 0.0
    random_gap_checks = 0
    for m in [1, 2, 4, 8, 16, 32, 64, 128]:
        c_m = 1 / sum(2.0 ** (-j) for j in range(m + 1))
        for k in range(4 * (m + 3)):
            delta = 2.0 ** (-k / 4)
            envelope = 0.0
            for j in range(m + 1):
                x = delta * 2.0 ** j
                envelope += c_m * min(x, 50 * (1 + 2 * max(0.0, math.log(x))) / x)
            assert envelope < 380
            max_random_gap_envelope = max(max_random_gap_envelope, envelope)
            random_gap_checks += 1

    sharpness = []
    for arms in [10, 100, 1000, 10000, 100000]:
        horizon = math.floor(math.sqrt(2) * arms)
        x = horizon / arms
        psi = 1 + (x - 1) * (math.sqrt(2) - 1)
        sharpness.append({"arms": arms, "ratio": psi / math.sqrt(x)})
    result = {
        "status": "all finite diagnostics passed; analytic proofs are separate",
        "cut_identity_checks_exact_rational": cut_checks,
        "submodularity_checks": submod_checks,
        "integer_optimum_exhaustive_checks": integer_checks,
        "rounding_feasibility_checks_exact_rational": rounding_checks,
        "max_cut_error": max_cut_error,
        "max_submodularity_floating_violation": max_submod_violation,
        "kappa": kappa,
        "minimum_integer_ratio_in_finite_test": min_integer_ratio,
        "sharpness_sequence": sharpness,
        "random_schedule_gap_envelope_checks": random_gap_checks,
        "maximum_random_schedule_gap_envelope": max_random_gap_envelope,
    }
    destination = Path(__file__).with_name("new_results_checks.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
