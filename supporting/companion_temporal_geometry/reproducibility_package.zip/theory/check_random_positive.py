"""Finite diagnostics for the fixed-template random-arrival theorem.

The analytic proof is in random_positive_results.tex. These checks exercise
finite identities, constants, boundary cases, and a causal implementation;
they are not a numerical proof of the minimax theorem.
"""
from __future__ import annotations

import itertools
import json
import math
import sys
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments" / "original_snapshot"))
from geometry import capacity  # noqa: E402


def positive_compositions(total: int, length: int):
    if length == 1:
        yield (total,)
        return
    for first in range(1, total - length + 2):
        for rest in positive_compositions(total - first, length - 1):
            yield (first,) + rest


def complexity(h, p):
    """Return W, E sqrt(H), weak-tail V and the maximizing support point."""
    h = np.asarray(h, dtype=float)
    p = np.asarray(p, dtype=float)
    assert np.all(h >= 1) and np.all(p >= 0)
    assert abs(p.sum() - 1) < 1e-12
    keep = p > 0
    h, p = h[keep], p[keep]
    values = np.minimum(h[:, None], h[None, :]).T @ p / np.sqrt(h)
    tails = np.array([p[h >= x].sum() for x in h]) * np.sqrt(h)
    index = int(np.argmax(values))
    return float(values[index]), float(p @ np.sqrt(h)), float(tails.max()), int(h[index])


def binary_bayes_window(length: int, delta: float) -> float:
    """Exact finite-state Bayes optimum with a known mean-1/2 anchor.

    A new arm has mean 1/2 +/- delta with equal initial probability. The
    anchor observations are uninformative about that sign. This gives the
    learner extra mean information relative to the theorem.
    """
    log_ratio = math.log((0.5 + delta) / (0.5 - delta))

    @lru_cache(None)
    def value(remaining, successes, failures):
        if remaining == 0:
            return 0.0
        log_odds = (successes - failures) * log_ratio
        probability_plus = 1 / (1 + math.exp(-log_odds))
        incumbent = delta * probability_plus + value(remaining - 1, successes, failures)
        success_probability = 0.5 + delta * (2 * probability_plus - 1)
        candidate = delta * (1 - probability_plus)
        candidate += success_probability * value(remaining - 1, successes + 1, failures)
        candidate += (1 - success_probability) * value(remaining - 1, successes, failures + 1)
        return min(incumbent, candidate)

    return value(length, 0, 0)


class RevealedTemplateMOSS:
    """Causal upper-bound rule; constructor receives no realized H."""

    def __init__(self, endpoint, alphas, batch_sizes):
        self.endpoint = int(endpoint)
        self.alphas = tuple(Fraction(a) for a in alphas)
        self.batch_sizes = tuple(batch_sizes)
        self.available = [0]
        self.scale = None
        self.batch_index = -1
        self.segment_length = None
        self.counts = np.zeros(1 + sum(batch_sizes), dtype=np.int64)
        self.totals = np.zeros(1 + sum(batch_sizes), dtype=float)

    def on_arrival(self, time, labels):
        self.batch_index += 1
        assert len(labels) == self.batch_sizes[self.batch_index]
        if self.scale is None:
            self.scale = Fraction(self.endpoint - time + 1) / self.alphas[0]
            assert self.scale.denominator == 1
        expected_time = self.endpoint - self.alphas[self.batch_index] * self.scale + 1
        assert time == expected_time
        self.available.extend(labels)
        next_alpha = self.alphas[self.batch_index + 1] if self.batch_index + 1 < len(self.alphas) else 0
        duration = (self.alphas[self.batch_index] - next_alpha) * self.scale
        assert duration.denominator == 1 and duration >= 1
        self.segment_length = int(duration)
        self.counts[:] = 0
        self.totals[:] = 0

    def choose(self):
        if self.scale is None:
            return 0
        best_label, best_index = self.available[0], -math.inf
        for label in self.available:
            count = self.counts[label]
            if count == 0:
                index = math.inf
            else:
                exploration = max(0.0, math.log(self.segment_length / (len(self.available) * count)))
                index = self.totals[label] / count + math.sqrt(exploration / count)
            if index > best_index:
                best_label, best_index = label, index
        return best_label

    def observe(self, label, reward):
        self.counts[label] += 1
        self.totals[label] += reward


def simulate_causal_rule(endpoint, alphas, batch_sizes, scale, means, seed):
    """Environment owns scale; the policy learns it only through on_arrival."""
    rng = np.random.default_rng(seed)
    policy = RevealedTemplateMOSS(endpoint, alphas, batch_sizes)
    events, label = {}, 1
    for alpha, size in zip(alphas, batch_sizes):
        time = endpoint - int(Fraction(alpha) * scale) + 1
        events[time] = list(range(label, label + size))
        label += size
    regret = 0.0
    first_time = min(events)
    # Every omitted pre-first-arrival action is forced to the anchor and
    # has zero regret; its reward is discarded at the first reset.
    actions = []
    for time in range(first_time, endpoint + 1):
        if time in events:
            policy.on_arrival(time, events[time])
        arm = policy.choose()
        assert arm in policy.available
        best_mean = max(means[i] for i in policy.available)
        regret += best_mean - means[arm]
        policy.observe(arm, float(rng.random() < means[arm]))
        actions.append(arm)
    assert policy.scale == scale
    return regret, actions


def main():
    counts = dict(exact_tail_inequalities=0, support_maximum_grid=0,
                  scaling_identities=0, averaging_inequalities=0,
                  capacity_bounds=0, common_prior_bayes_windows=0,
                  causal_policy_paths=0, old_mixture_identities=0)
    distributions = []
    for size in range(1, 5):
        for hs in itertools.combinations([1, 4, 9, 16], size):
            for weights in positive_compositions(8, size):
                ps = [Fraction(w, 8) for w in weights]
                values = [sum(p * min(h, x) for h, p in zip(hs, ps)) / math.isqrt(x)
                          for x in hs]
                exact_w = max(values)
                exact_v = max(Fraction(math.isqrt(x)) * sum(p for h, p in zip(hs, ps) if h >= x)
                              for x in hs)
                exact_moment = sum(p * math.isqrt(h) for h, p in zip(hs, ps))
                assert exact_v <= exact_w <= 2 * exact_v
                assert exact_w <= exact_moment
                counts["exact_tail_inequalities"] += 1
                distributions.append((np.array(hs, dtype=float), np.array(ps, dtype=float)))

    rng = np.random.default_rng(20261013)
    for _ in range(200):
        size = int(rng.integers(1, 12))
        hs = np.unique(rng.integers(1, 10001, size=size)).astype(float)
        ps = rng.dirichlet(np.ones(len(hs)))
        distributions.append((hs, ps))

    largest_averaging_ratio = 0.0
    for hs, ps in distributions:
        w, moment, v, _ = complexity(hs, ps)
        assert v <= w * (1 + 1e-12) and w <= 2 * v * (1 + 1e-12)
        assert w <= moment * (1 + 1e-12)
        grid = np.unique(np.r_[hs, np.geomspace(1, 2 * max(hs), 201)])
        values = np.minimum(hs[:, None], grid[None, :]).T @ ps / np.sqrt(grid)
        assert np.max(values) <= w * (1 + 1e-12)
        counts["support_maximum_grid"] += len(grid)
        for multiplier in [2, 3, 7]:
            scaled_w = complexity(multiplier * hs, ps)[0]
            assert math.isclose(scaled_w, math.sqrt(multiplier) * w, rel_tol=1e-12)
            counts["scaling_identities"] += 1
        for k in [2, 3, 8]:
            a, b = 20 * k + 10, 16
            for delta in np.geomspace(1e-5, 1, 31):
                envelope = np.minimum(hs * delta, (a + b * np.maximum(0, np.log(hs * delta**2))) / delta)
                averaged = float(ps @ envelope)
                upper = (1 + a + 2 * b) * w
                assert averaged <= upper * (1 + 1e-12)
                largest_averaging_ratio = max(largest_averaging_ratio, averaged / upper)
                counts["averaging_inequalities"] += 1

    templates = [([1], [1]), ([4, 2, 1], [1, 1, 1]),
                 ([3, 1], [2, 3]), ([Fraction(3, 2), 1], [1, 2])]
    for alphas, sizes in templates:
        total = sum(sizes)
        for scale in [2, 4, 10, 20, 100]:
            hs = [int(alpha * scale) for alpha, size in zip(alphas, sizes) for _ in range(size)]
            cap = capacity(hs, max(hs))["C"]
            assert math.sqrt(scale) - 1e-12 <= cap <= math.sqrt(total * float(alphas[0]) * scale) + 1e-12
            counts["capacity_bounds"] += 1
            for seed in range(8):
                means = np.linspace(0.45, 0.65, total + 1)
                endpoint = max(hs) + 7
                regret, actions = simulate_causal_rule(endpoint, alphas, sizes, scale, means, seed)
                assert 0 <= regret <= max(hs)
                assert len(actions) == max(hs)
                counts["causal_policy_paths"] += 1

    smallest_bayes_to_bound_ratio = math.inf
    for x in range(1, 21):
        delta = 1 / (8 * math.sqrt(x))
        for h in range(1, 21):
            length = min(h, x)
            bayes = binary_bayes_window(length, delta)
            lower = length / (32 * math.sqrt(x))
            assert bayes + 1e-12 >= lower
            smallest_bayes_to_bound_ratio = min(smallest_bayes_to_bound_ratio, bayes / lower)
            counts["common_prior_bayes_windows"] += 1

    mixtures = []
    for m in [1, 2, 4, 8, 16, 32, 64]:
        hs = np.array([4.0**j for j in range(m + 1)])
        ps = np.array([2.0**(-j) for j in range(m + 1)])
        ps /= ps.sum()
        c = float(ps[0])
        w, moment, v, _ = complexity(hs, ps)
        for r in range(m + 1):
            direct = float(ps @ np.minimum(hs, 4.0**r)) / 2.0**r
            closed = c * (3 - 2.0**(-r) - 2.0**(r - m))
            assert math.isclose(direct, closed, rel_tol=1e-12)
            counts["old_mixture_identities"] += 1
        assert 1 <= w < 3 and math.isclose(moment, c * (m + 1), rel_tol=1e-12)
        mixtures.append(dict(m=m, W=w, E_sqrt_H=moment, V=v, concentration_ratio=moment / w))

    report = dict(status="all finite diagnostics passed", seed=20261013,
                  diagnostic_only=True, counts=counts,
                  largest_averaging_bound_fraction=largest_averaging_ratio,
                  smallest_exact_bayes_to_test_bound_ratio=smallest_bayes_to_bound_ratio,
                  old_mixture_diagnostics=mixtures,
                  theorem_scope="Fixed arm/batch template, known endpoint, revealing common stretch; constants depend on template.")
    output = Path(__file__).with_name("random_positive_checks.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "counts": counts, "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
