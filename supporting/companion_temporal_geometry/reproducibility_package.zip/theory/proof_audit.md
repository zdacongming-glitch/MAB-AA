# Independent proof audit and added results

Date: 2026-10-13. Scope: the mathematical statements in `proposal/temporal_geometry_research/theory.md`, especially Sections 3–8; the matching sections of the reconstruction proposal have the same statements. The original files were not edited. This report does not assign an innovation score.

**Status: Complete proof for the three supplementary results in `new_results.tex`; no defect requiring withdrawal of the deterministic-schedule main theorem was found in the independent audit.** This is a mathematical audit, not a formal proof-assistant certificate. Numerical checks below are diagnostics and do not supply missing universal arguments.

The proof skill and its proof protocol, domain routes, and adversarial audit were read before accepting any result. The main statements were reconstructed from their assumptions rather than accepted from the source document's description of its own proofs as complete.

## 1. Frozen contract and assumption ledger

The main risk is expected pseudo-regret against the largest mean among the arms available at each round. Each arm has an independent i.i.d. potential reward stream in $[0,1]$. Arrivals are fixed, exogenous, persistent, and locally finite. The policy observes the current available set before acting. The lower-bound policy may know the entire arrival schedule and the horizon. MC-MOSS knows neither and retains all observed rewards.

The deterministic-schedule claim is

$$
\frac{\mathscr S_T}{10000}
\le \inf_\pi\sup_P\mathbb E_P^\pi R_T
\le\sup_P\mathbb E_P^{\mathrm{MC}}R_T
\le\min\{T,300\mathscr S_T\}.
$$

All constants are universal. The statement is at each fixed deterministic terminal time; it is not a stopping-time guarantee or an almost-sure limit theorem. Empty competition gives zero regret and zero capacity.

| Assumption | Status | Role |
|---|---|---|
| Fixed exogenous arrival times | Given | Clock segment endpoints and true optimal-arm labels are deterministic once the environment is fixed. |
| Independent bounded stationary potential streams | Given | Uniform empirical-prefix concentration and bandit likelihood decomposition. |
| Local finiteness | Given | Maximal-index action, capacity optimization, and finite sums at each terminal time are defined. |
| Future schedule and horizon available to lower-bound policies | Given | Stronger decision class makes the deterministic lower bound valid for causal policies too. |
| Fresh old observations after a clock reset | Forbidden | The upper proof does not use this false conditional-independence assumption. |
| Gap or benchmark-jump regularity | Not used | Lower-bound mean increments are a construction, not a model restriction. |
| Simultaneous hard means for all randomly realized schedules | Not given | The new two-arm counterexample proves that this cannot be supplied in general. |

## 2. Obligation graph and resolution

| Obligation | Source location | Independent check and status |
|---|---|---|
| Maximal lower-confidence deviation | Section 3.2, equations (3.4)–(3.7) | Dyadic peeling uses potential reward prefixes, not selected sample counts. The integrated coefficient is below 5; the tail coefficient 5 and truncated first-moment coefficient 10 are valid. Closed. |
| Total adaptive overestimation | Section 3.3, equation (3.8) | Each arm/count pair appears once. Truncation at a deterministic positive threshold gives a summable bound over all potential prefixes. No independence between a selected count and its sample mean is assumed. Closed. |
| Full-history local regret | Section 4.2, equation (4.4) | The true current best label is deterministic. Its maximal deviation bound may be summed over the physical segment time. Initialization, overestimation, and bonus charges sum to less than $15\sqrt{dh}$. Closed. |
| Clock segments charged to spectrum | Section 5.3, equations (5.3)–(5.5) | Every triggering batch enters the new segment before action. Previous competition counts grow geometrically; the suffix after competition exceeds remaining time is charged once. The geometric factor yields less than $210\mathscr S_T$, safely below the claimed 300. Closed. |
| Common hard prior | Sections 6.3–6.5 | Parity separation prevents later selected groups from arriving inside earlier charging windows; deterministic reference means prevent leakage of earlier latent alternatives; the sum of selected gaps fits inside the bounded mean range. Closed. |
| Information from early observations | Section 6.5, equation (6.7) | The KL uses the entire history through the end of the charging window, including observations preceding that window. Total candidate pulls since earliest possible group arrival are at most the scale length. Closed. |
| Capacity/spectrum equivalence | Section 7.2 | The explicit allocation with group total $b_\ell/4$ is suffix-feasible, even if only part of the largest relevant dyadic group is contained in a suffix. Linear truncation of the square root is essential. Closed. |
| Hull optimum and exact dual | Sections 7.3–7.4 | Hull slopes are positive and nondecreasing; the last repeated lifetime is used at every tight vertex. Supergradient multipliers handle slope 1 and nonuniqueness. Closed. |
| Fixed point and square-spectrum equivalence | Section 8.1 | Saturated large scales are impossible above the Euclidean norm. The reverse bound uses a small-scale geometric square sum plus twice the lifetime tail. Cases $\Gamma=T$ and $\lceil Q\rceil>T$ are included. Closed. |

### The lower-bound compatibility calculation

For a selected scale with upper endpoint $b$, each selected arm has lifetime greater than $b/2$, so every such arm is available throughout the charging window

$$
\{T-b/2+1,\ldots,T-b/4\}.
$$

The next selected scale is at most $b/4$, since scales have one parity. Its earliest arrival is therefore after this window. The benchmark within a window is the reference mean in the null alternative or the raised candidate mean in a spike alternative. Earlier groups cannot exceed the current reference level. This verifies the pathwise loss comparisons used before changing measure.

The chosen scale parameters grow by more than a factor of 2 along the selected temporal sequence and never exceed 1. Their sum is at most 2. Consequently the accumulated mean increase is at most $1/16$. Conditioning on the latent choices in every other group changes neither the current null/spike probability weights nor the fact that only one reward law differs in the current comparison.

For $m$ candidates and gap increment $\epsilon$, the average total-variation bound is

$$
\frac1m\sum_i\sqrt{D_i/2}
\le\sqrt{16\epsilon^2b/m}\le\frac18.
$$

All pre-window candidate observations are in $D_i$. The conditional Bayes loss is at least $\epsilon h/4$, and disjoint charging windows permit summation under one product prior. The single-candidate and smallest-scale remainder uses a separate lower bound and combines with this result by taking the maximum, not by adding unrelated worst-case environments.

### The full-history seam

At a non-initialization action the comparator inequality is pathwise:

$$
\Delta_{I_t}(t)
\le Z_{i_t^*}(s/d)
 +(\widehat\mu_{I_t,n}-\mu_{I_t})_+
 +\sqrt{\frac{\log_+(s/(dn))}{n}}.
$$

The maximal deviation is defined over the entire independent potential stream. The nonrepeated pair is the arm label together with its **lifetime** pre-pull count. Thus the proof survives arbitrary reward-dependent action choices within the segment. It does not condition on the segment-start history. Segment endpoints must remain determined by exogenous arrivals. Replacing this reasoning by a conditional fresh-sample argument would invalidate the proof.

## 3. Additional original-claim checks and limits

The following checks did not uncover an invalid statement: the fixed-probability lower bound uses a bounded proxy rather than inferring a probability lower bound from expected regret alone; the learning boundary uses uniform risk and doubles the terminal time in the necessary direction; the gap proof partitions actions before counting; the cold-reset separation establishes actual sample-count lower bounds; clipping at reward upper bound 1 preserves the needed comparator inequality; and inserted observations preserve nonrepeated lifetime counts.

The manuscript should preserve these limits explicitly:

1. $K_t=o(t)$ characterizes the stated uniform expected and uniform in-probability notions, not an already-proved almost-sure property of MC-MOSS for every such schedule.
2. The fixed-point quantity is equivalent to the Euclidean spectrum norm; it is not alone equivalent to regret.
3. Capacity is a deterministic schedule functional, not an estimator of the arm means or an implementable policy recommendation.
4. A constant-factor equivalence does not transfer exact additive inequalities, submodularity, or Lipschitz constants from capacity to minimax regret.
5. The cold-reset comparison is with a specifically defined paired policy, not a dominance claim over all prior bandit algorithms.
6. Conditioning on an independent random schedule preserves the upper bound, but does not preserve an integrated lower bound with an environment selected before schedule randomization. The new counterexample below makes this boundary substantive.

## 4. Added results: exact scope and proof status

### 4.1 Cut integral and diminishing marginal capacity

For a subset $A$ of a fixed candidate universe and common per-arm cap $z>0$, define

$$
F_z(A)=\max_{n\in\mathcal N(A)}\sum_{i\in A}\min\{n_i,z\}.
$$

The new explicit representation is

$$
F_z(A)=\min_{h=0,\ldots,T}\{h+z|\{i\in A:H_i>h\}|\},
\qquad
\mathscr C(A)=\frac12F_1(A)
 +\frac14\int_1^\infty F_z(A)z^{-3/2}\,dz.
$$

The same hull allocation maximizes every capped problem. An elementary comparison of two minimizing cut times proves submodularity of each $F_z$, which the nonnegative integral transfers to $\mathscr C$. Therefore adding an arm has decreasing marginal capacity as the candidate set grows, and the marginal contribution of arm $i$ never exceeds $\sqrt{H_i}$.

**Status: Complete proof. Attribution constraint:** general submodularity of separable concave optimization over a polymatroid is prior work. The occupancy constraints form a polymatroid with rank $r(D)=\max_{i\in D}H_i$. The theorem is presented as a specialization with an explicit cut integral, not a new general submodularity principle. The primary publisher page for [He, Zhang, and Zhang (2012)](https://pubsonline.informs.org/doi/10.1287/opre.1110.1000) was checked. Its article concerns the general concave-polymatroid mechanism; the mathematical proof here is self-contained.

### 4.2 Sharp integer-versus-fractional capacity ratio

For integer feasible counts, define

$$
\mathscr C_{\mathrm{int}}
 =\max_{N\in\mathcal N\cap\mathbb Z_+^m}\sum_i\sqrt{N_i}.
$$

The verified result, proposed by the parent agent and independently checked here, is

$$
\kappa\mathscr C\le\mathscr C_{\mathrm{int}}\le\mathscr C,
\qquad
\kappa=\frac{2\,2^{1/4}}{1+\sqrt2}
 =0.985171431\ldots.
$$

The lower bound uses one common random shift to round all cumulative allocations. Every suffix-capacity constraint remains satisfied for every shift. Expected rounded utility is the linear interpolation of the square root at integers. Its smallest ratio to $\phi$ occurs at $x=\sqrt2$. The constant is sharp: take $m$ arms with a common lifetime $\lfloor\sqrt2m\rfloor$ and let $m$ tend to infinity. Balanced integer allocations use counts 1 and 2 and approach the stated ratio.

**Status: Complete proof, including sharpness.** This supplies an exact interpretation of the fractional relaxation. It does not imply that the maximizing schedule-only allocation is an optimal bandit strategy. Priority of this specialized sharp ratio is not claimed solely from its derivation here.

### 4.3 Independent random arrivals can have much smaller minimax risk

Let $T=4^m$. There are exactly two arms: an initial anchor and a competitor whose remaining lifetime equals $4^j$ with probability $c_m2^{-j}$, $j=0,\ldots,m$, where $c_m$ normalizes the distribution. Arrivals are independent of the reward streams. Then

$$
\mathbb E\mathscr C_T=c_m(m+1)=\Theta(\log T).
$$

If both reward laws are fixed before the schedule draw, and policies may know the horizon and schedule distribution, then

$$
\frac1{16}\le
\inf_\pi\sup_{P_1,P_2}\mathbb E_{\tau,P_1,P_2}^\pi R_T
\le380.
$$

The upper proof is uniform over all bounded reward laws. At the competitor's arrival, the policy knows the remaining horizon from the current time and the known terminal time; a fixed-horizon two-arm MOSS policy satisfies

$$
\mathbb E R_H\le
\min\left\{H\Delta,
 \frac{50[1+\log_+(H\Delta^2)]}{\Delta}\right\}.
$$

This needed local gap bound is fully proved in `new_results.tex`, with the maximal-deviation argument restated. Weighted summation is uniformly finite after splitting the geometric sequence $\Delta2^j$ at 1. The lower bound uses two fixed Bernoulli environments differing only in the competitor mean, and the final-round arrival event, which has probability at least $1/2$.

**Status: Complete proof of a logarithmic separation.** This is a separate model extension with explicitly different quantifiers. It disproves the tempting universal inequality that lower-bounds joint random-schedule minimax risk by a constant times expected deterministic-schedule capacity. It strengthens the original manuscript's warning about exchanging supremum and expectation into a concrete mathematical obstruction. No new conditional upper-bound guarantee for MC-MOSS is needed for this argument.

## 5. Counterexample and boundary ledger

| Check | Resolution |
|---|---|
| No competitor | All capacities and regret vanish; every added theorem includes this case or explicitly assumes two arms. |
| One-round horizon or terminal arrival | Initialization handles the upper bound; one-step uncertainty gives the random-schedule lower bound. |
| Large terminal batch | The linear part of $\phi$ limits total capacity to one remaining time unit. |
| Repeated lifetimes | Prefix constraints inside a tied group are redundant; a tight hull vertex cannot precede a positive allocation at the same lifetime. |
| Hull slope at 1 | The supergradient interval permits the source choice; integer interpolation agrees exactly on $[0,1]$. |
| Very small gap | The random-schedule upper sum uses the trivial $H\Delta$ branch below the scale threshold, avoiding division-by-gap artifacts. |
| Zero gap | Regret is exactly zero and is treated separately. |
| Comparator arm still unseen | Infinite indices prevent selecting an observed finite-index arm; clipped indices use the known reward upper bound instead. |
| Reward-dependent reset time | Not covered by the deterministic local-kernel proof. No extension is claimed. |
| Future references leaking earlier latent spikes | Reference means depend only on fixed scale increments, not on any latent spike choices. |
| Replacing $\sup_P\mathbb E_\tau$ by $\mathbb E_\tau\sup_P$ | The new two-arm logarithmic separation rules out a universal constant-factor replacement. |

## 6. Finite diagnostic record

`check_new_results.py` imports the original geometry routine without changing it and writes `new_results_checks.json`. It checked every four-arm lifetime multiset for horizons 1 through 6, all labeled subsets of each such universe, rational cap levels, and exact common-shift rounding constraints. Executed results:

| Diagnostic | Count/result |
|---|---|
| Capped-allocation/cut identities using exact rational arithmetic | 28,224 checks; no discrepancy |
| Submodular inequalities over every pair of labeled subsets | 64,512 checks; largest floating residue $8.88\times10^{-16}$ |
| Exhaustive integer optima | 252 schedules; all ratios within the proved interval |
| Common-shift rounding feasibility | 9,324 rational-shift checks; all passed |
| Smallest integer/fractional ratio in the finite set | 0.9855985596534889 |
| Sharpness sequence at 100,000 equal-lifetime arms | 0.9851714310101974 |
| Random-schedule gap-envelope checks | 1,116 gap/horizon configurations; all below the proved bound 380 |

The cut identity and rounding checks used rational arithmetic; square-root capacities and submodular residuals used floating point. The integral, submodularity, sharp universal constant, and random-schedule separation are justified analytically in `new_results.tex`; the finite checks only detect implementation or transcription errors.

## 7. Handoff notes

`new_results.tex` contains three self-contained supplement sections, a short local gap lemma, and a full proof of the random-schedule separation suitable for moving into the main text. It uses standard theorem/proof environments and the bibliography key `he2012polymatroid`. The parent manuscript should either retain the local maximal-deviation derivation or replace it with a precise reference to its corresponding proved lemma. No `corrected_proofs.tex` was needed because no invalid original theorem was identified within the audited scope.

The final manuscript still needs a separate pass checking that its English statements preserve the assumptions and quantifiers audited here. This report does not certify prose or mathematical notation that had not yet been written at the time of the audit.
