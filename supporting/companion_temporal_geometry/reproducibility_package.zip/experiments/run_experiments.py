"""Reproducible finite experiments for the temporal-geometry manuscript.

Run from any directory: python run_experiments.py --replications 256
All policy decisions receive only current counts, observed sums, present arm
count, and current time. The simulator owns arrivals, horizon and true means.
The sole dependence of preallocated arrays on final K is storage capacity;
indices beyond current k are never read by a policy decision.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import platform
import sys
import time
from pathlib import Path

import numpy as np
import numba
from numba import njit

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'original_snapshot'))
from geometry import spectrum, capacity, fixed_point
from mc_moss import MCMOSS

METHODS = ('MC-MOSS', 'Cold MOSS', 'Full-history UCB', 'Global-clock MOSS')


@njit
def choose(n, sums, k, t, base, start, method):
    """No future arrivals, horizon or reward means enter this decision."""
    if k == 1:
        return 0, base, start
    if method <= 1:
        if base == 0 or k - 1 >= 2 * base:
            base = k - 1
            start = t
            if method == 1:
                for i in range(k):
                    n[i] = 0
                    sums[i] = 0.0
        clock, denom = t - start + 1, 2 * base
    else:
        clock, denom = t, 2 * (k - 1)
    chosen, maximum = 0, -np.inf
    for i in range(k):
        if n[i] == 0:
            return i, base, start
        if method == 2:
            bonus = math.sqrt(2 * math.log(t) / n[i])
        else:
            q = clock / (denom * n[i])
            bonus = math.sqrt(math.log(q) / n[i]) if q > 1 else 0.0
        index = sums[i] / n[i] + bonus
        if index > maximum:
            chosen, maximum = i, index
    return chosen, base, start


@njit
def simulate(arrivals, means, horizon, method, uniforms, deterministic=False):
    n = np.zeros(len(arrivals), dtype=np.int64)
    sums = np.zeros(len(arrivals), dtype=np.float64)
    pulls = np.zeros(len(arrivals), dtype=np.int64)
    actions = np.empty(horizon, dtype=np.int64)
    cumulative = np.empty(horizon, dtype=np.float64)
    k = base = start = 0
    best = -1.0
    regret = 0.0
    for tt in range(horizon):
        t = tt + 1
        while k < len(arrivals) and arrivals[k] <= t:
            best = max(best, means[k])
            k += 1
        chosen, base, start = choose(n, sums, k, t, base, start, method)
        reward = means[chosen] if deterministic else (1.0 if uniforms[tt] < means[chosen] else 0.0)
        n[chosen] += 1
        pulls[chosen] += 1
        sums[chosen] += reward
        actions[tt] = chosen
        regret += best - means[chosen]
        cumulative[tt] = regret
    return regret, pulls, actions, cumulative


def csv_write(path, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def audit_implementation():
    """Compare decision-by-decision against the original public online API."""
    checked = 0
    rng = np.random.default_rng(2026101301)
    for z in range(12):
        horizon = 257
        arrivals = np.sort(np.r_[1, rng.integers(1, horizon + 1, 17)]).astype(np.int64)
        means = rng.uniform(.05, .95, len(arrivals))
        uniforms = rng.random(horizon)
        for method in range(4):
            r, n, actions, _ = simulate(arrivals, means, horizon, method, uniforms)
            assert np.all(arrivals[actions] <= np.arange(1, horizon + 1))
            short = 153
            # Hide future labels entirely in the prefix rerun.
            present = arrivals <= short
            rr, nn, aa, _ = simulate(arrivals[present], means[present], short, method, uniforms[:short])
            assert np.array_equal(aa, actions[:short])
            checked += 1
            if method <= 1:
                policy = MCMOSS(cold_reset=bool(method))
                for tt in range(horizon):
                    new = np.where(arrivals == tt + 1)[0].tolist()
                    chosen = policy.select(new)
                    assert chosen == int(actions[tt])
                    policy.update(float(uniforms[tt] < means[chosen]))
                assert policy.lifetime_counts == {i: int(n[i]) for i in range(len(arrivals))}
    return {'paired_prefix_checks': checked, 'original_api_action_checks': 12 * 2 * 257,
            'status': 'all checks passed'}


def make_schedules(horizon=16384):
    # Eighty-five competitors: 1 + 4 + 16 + 64.
    lifetimes = np.repeat([horizon, horizon // 4, horizon // 16, horizon // 64], [1, 4, 16, 64])
    multi = np.r_[1, horizon - lifetimes + 1].astype(np.int64)
    return {
        'Early batch': np.ones(86, dtype=np.int64),
        'Late batch': np.r_[1, np.full(85, horizon - 255)].astype(np.int64),
        'Regular arrivals': np.r_[1, np.linspace(1, horizon - 255, 85).astype(np.int64)],
        'Multiscale arrivals': multi,
    }


def mean_vector(configuration, size):
    if configuration == 'Persistent incumbent':
        return np.r_[.6, np.full(size - 1, .5)]
    # Same means by label across schedules. Four record labels appear in order.
    means = np.full(size, .4)
    for arm, mean in zip([1, 22, 43, 85], [.45, .50, .55, .60]):
        means[arm] = mean
    return means


def run(replications, horizon, seed):
    started = time.perf_counter()
    audit = audit_implementation()
    raw, trajectories, geom, environments = [], [], [], []
    checkpoints = np.unique(np.r_[np.linspace(1, horizon, 65).astype(int), horizon - 255, horizon - 1023, horizon - 4095])
    checkpoints = checkpoints[checkpoints >= 1]
    for si, (scenario, arrivals) in enumerate(make_schedules(horizon).items()):
        hs = [int(horizon - a + 1) for a in arrivals[1:]]
        sp, cap = spectrum(hs, horizon), capacity(hs, horizon)
        geom.append({'scenario': scenario, 'T': horizon, 'K': len(arrivals),
                     'S': sp['S'], 'C': cap['C'], 'Gamma': fixed_point(hs, horizon),
                     'Q': sp['Q'], 'D_eff': sp['D_eff']})
        for ci, config in enumerate(('Persistent incumbent', 'Improving records')):
            means = mean_vector(config, len(arrivals))
            for i, (a, mu) in enumerate(zip(arrivals, means)):
                environments.append({'scenario': scenario, 'configuration': config,
                                     'arm': i, 'arrival': int(a), 'mean': float(mu)})
            for rep in range(replications):
                run_seed = seed + 10000 * si + 1000 * ci + rep
                # Common independent uniform draw per calendar round across methods.
                # This is a coupling for paired MC differences, not shared observations.
                uniforms = np.random.default_rng(run_seed).random(horizon)
                for mi, method in enumerate(METHODS):
                    r, pulls, actions, cumulative = simulate(arrivals, means, horizon, mi, uniforms)
                    assert np.all(arrivals[actions] <= np.arange(1, horizon + 1))
                    raw.append({'scenario': scenario, 'configuration': config, 'method': method,
                                'replication': rep, 'seed': run_seed, 'T': horizon, 'regret': r})
                    for t in checkpoints:
                        trajectories.append({'scenario': scenario, 'configuration': config,
                                             'method': method, 'replication': rep,
                                             'time': int(t), 'regret': float(cumulative[t - 1])})
            print(f'Completed {scenario}; {config}; {replications} replications', flush=True)
    summary, paired = [], []
    for g in geom:
        for config in ('Persistent incumbent', 'Improving records'):
            grouped = {method: np.array([r['regret'] for r in raw
                       if r['scenario'] == g['scenario'] and r['configuration'] == config
                       and r['method'] == method]) for method in METHODS}
            for method, values in grouped.items():
                summary.append({'scenario': g['scenario'], 'configuration': config, 'method': method,
                                'replications': replications, 'mean_regret': float(values.mean()),
                                'mc_se': float(values.std(ddof=1) / math.sqrt(replications)),
                                'mean_over_S': float(values.mean() / g['S'])})
                if method != METHODS[0]:
                    diff = values - grouped[METHODS[0]]
                    paired.append({'scenario': g['scenario'], 'configuration': config,
                                   'baseline': method, 'mean_baseline_minus_MC': float(diff.mean()),
                                   'paired_mc_se': float(diff.std(ddof=1) / math.sqrt(replications))})
    csv_write(ROOT / 'raw_regret.csv', raw)
    csv_write(ROOT / 'trajectory_regret.csv', trajectories)
    csv_write(ROOT / 'summary.csv', summary)
    csv_write(ROOT / 'paired_differences.csv', paired)
    csv_write(ROOT / 'arrival_geometry.csv', geom)
    csv_write(ROOT / 'environments.csv', environments)

    separation = []
    for m in range(1, 9):
        T = 16 ** m
        hs = [4 ** (2*m-j) for j in range(m + 1) for _ in range(4**j)]
        comparator = [T] * (m + 1) + [1] * (len(hs) - m - 1)
        for family, values in [('Multiscale', hs), ('Concentrated', comparator)]:
            sp, cap = spectrum(values, T), capacity(values, T)
            separation.append({'family': family, 'm': m, 'T': T, 'K': len(values)+1,
                               'S': sp['S'], 'C': cap['C'], 'Gamma': fixed_point(values, T),
                               'Q': sp['Q'], 'D_eff': sp['D_eff']})
    csv_write(ROOT / 'geometry_separation.csv', separation)
    analytic = []
    for m in [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]:
        log_h = 16 * m * math.log(2)
        log_T = math.log(m) + log_h
        analytic.append({'m': m, 'log_h': log_h, 'log_T': log_T,
                         'cold_regret_lower_bound': m * math.floor(log_h) / 4,
                         'history_regret_upper_bound': .25 + 4 * log_T,
                         'record_type': 'analytic_bound_not_simulation'})
    csv_write(ROOT / 'analytic_restart_bounds.csv', analytic)
    audit.update(replications=replications, horizon=horizon, seed=seed,
                 bernoulli_trajectories=len(raw), bernoulli_policy_rounds=len(raw)*horizon,
                 runtime_seconds=time.perf_counter()-started, python=platform.python_version(),
                 numpy=np.__version__, numba=numba.__version__,
                 interpretation='Finite comparisons; no minimax estimation or universal dominance claim.')
    (ROOT / 'run_manifest.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--replications', type=int, default=256)
    parser.add_argument('--horizon', type=int, default=16384)
    parser.add_argument('--seed', type=int, default=20261013)
    args = parser.parse_args()
    if args.replications < 2 or args.horizon < 4096:
        parser.error('Use at least two replications and horizon >= 4096')
    run(args.replications, args.horizon, args.seed)
