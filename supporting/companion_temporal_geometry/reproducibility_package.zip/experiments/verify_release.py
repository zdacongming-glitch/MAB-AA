"""Verify saved tables, source provenance, and artifact presence."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent.parent / 'proposal' / 'temporal_geometry_research'


def read(name):
    with (ROOT / name).open(encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


source_hashes = {}
provenance = json.loads((ROOT / 'source_provenance.json').read_text(encoding='utf-8'))
original_available = ORIGINAL.is_dir()
for name in ['geometry.py', 'mc_moss.py', 'audit_geometry.py', 'test_online_api.py',
             'policy_diagnostics.py', 'policy_results.csv']:
    reproduced = (ROOT / 'original_snapshot' / name).read_bytes()
    source_hashes[name] = hashlib.sha256(reproduced).hexdigest()
    assert source_hashes[name] == provenance['original_sha256'][name], name
    if original_available:
        assert (ORIGINAL / name).read_bytes() == reproduced, name

raw, summary = read('raw_regret.csv'), read('summary.csv')
manifest = json.loads((ROOT / 'run_manifest.json').read_text())
assert len(raw) == manifest['bernoulli_trajectories']
assert sum(int(r['T']) for r in raw) == manifest['bernoulli_policy_rounds']
assert len(summary) == 32
assert len({(r['scenario'], r['configuration'], r['method'], r['replication']) for r in raw}) == len(raw)
for row in summary:
    values = [float(r['regret']) for r in raw if all(r[k] == row[k] for k in ['scenario', 'configuration', 'method'])]
    assert len(values) == int(row['replications'])
    assert math.isclose(statistics.mean(values), float(row['mean_regret']), rel_tol=1e-12, abs_tol=1e-12)
    assert math.isclose(statistics.stdev(values)/math.sqrt(len(values)), float(row['mc_se']), rel_tol=1e-12, abs_tol=1e-12)
assert all(int(r['replications']) == 256 for r in summary)

for stem in ['fig_policy_comparison', 'fig_structural_diagnostics', 'fig_analytic_restart_bounds']:
    for extension in ['pdf', 'png']:
        assert (ROOT.parent / 'figures' / (stem + '.' + extension)).stat().st_size > 1000
for name in ['experiments.tex', 'table_regret.tex', 'table_geometry.tex', 'results_paragraph.tex']:
    assert (ROOT / name).stat().st_size > 100
for path in ROOT.rglob('*.md'):
    content = path.read_text(encoding='utf-8')
    for bad in ['\\(', '\\)', '\\[', '\\]']:
        assert bad not in content, (path, bad)

hashes = {}
for folder in [ROOT, ROOT.parent / 'figures']:
    for path in sorted(folder.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name == 'release_verification.json':
            continue
        hashes[str(path.relative_to(ROOT.parent)).replace('\\', '/')] = hashlib.sha256(path.read_bytes()).hexdigest()
result = {'status': 'all release checks passed', 'raw_rows': len(raw),
          'summary_rows': len(summary), 'embedded_sources_match_recorded_original_hashes': True,
          'original_source_and_reproduced_csv_identical': True if original_available else None,
          'external_originals_available': original_available,
          'markdown_math_delimiters_checked': True,
          'original_sha256': source_hashes, 'release_sha256': hashes}
(ROOT / 'release_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if 'sha256' not in k}, indent=2))
