# Reproducibility record

Date: 2026-10-13. All work in this directory uses copies of the original diagnostic scripts; the original proposal and its results remain unchanged.

## Environment and execution

The recorded environment is Python 3.11.7, NumPy 1.26.4, Numba 0.59.0, and Matplotlib 3.8.0 on Windows. The geometry and original online API checks use only the Python standard library. Policy simulation additionally uses NumPy and Numba; rendering additionally uses Matplotlib. Version pins are in `requirements.txt`.

From the reconstruction directory, run:

```powershell
python experiments/original_snapshot/audit_geometry.py
python experiments/original_snapshot/test_online_api.py
python experiments/original_snapshot/policy_diagnostics.py
python experiments/run_experiments.py --replications 256 --horizon 16384 --seed 20261013
python figures/gen_fig_experiments.py
python experiments/verify_release.py
```

The first three commands reproduce the earlier diagnostic suite within its copied directory. The next two regenerate the present study and figures; the last verifies the saved release. The package is self-contained: embedded source hashes are always checked, and an additional byte comparison with the original proposal directory runs when that directory is present. Numba compilation and host load affect elapsed time. The full command output from the original reruns, smoke test, 64-replication pilot, and final 256-replication study is saved under `logs/`. The final study, rather than the pilot, supplies the manuscript tables.

## Design

The final experiment has four arrival schedules, two fixed Bernoulli mean vectors, four policies, and 256 independent replications per environment. Every schedule has horizon $T=16384$ and 86 final arms. The policies receive only the currently available arm count, time, cumulative counts, and observed reward sums. True means, horizon, and future labels remain in the simulator. Arrays are preallocated for storage, but policy decisions do not read their lengths or unavailable entries. Prefix checks rerun with future labels removed entirely.

The UCB comparison uses the explicit index $\widehat\mu_i+\sqrt{2\log(t)/N_i}$, with infinite index for an unobserved arm. The global-clock MOSS comparison uses the current total time and denominator $2(K_t-1)$, without resets. Neither comparison is called AUER, and no spectrum-optimal theorem is claimed for them. There is no parameter tuning or dataset selection based on final results.

Independent calendar-time uniforms produce the selected reward. Within a replication the same uniforms couple methods; across replications the seeds differ. A policy observes only the reward associated with its selected arm. This produces the specified conditional Bernoulli law under adaptive selection. The recorded statistic is cumulative pseudo-regret relative to the best currently available mean, not realized reward regret. Monte Carlo standard errors use the sample standard deviation divided by the square root of the number of replications. Paired differences use the standard deviation of within-replication differences; the code does not substitute marginal standard errors for the paired standard error.

## Files

- `environments.csv`: complete arm labels, arrival times, and fixed means for every environment.
- `raw_regret.csv`: endpoint pseudo-regret and seed for every replication and policy.
- `trajectory_regret.csv`: pseudo-regret at saved calendar-time checkpoints.
- `summary.csv`: endpoint Monte Carlo means and standard errors.
- `paired_differences.csv`: baseline-minus-MC-MOSS differences and paired Monte Carlo standard errors.
- `arrival_geometry.csv`: spectrum, capacity, fixed point, quadratic spectrum, and effective scale count for each simulation schedule.
- `geometry_separation.csv`: exact arrival-only calculations for the two theoretical schedule families, up to scale parameter eight. The largest horizon is $16^8$; no trajectory of that length was simulated.
- `analytic_restart_bounds.csv`: evaluated analytic upper and lower bounds for the exponential-segment construction. Every row is labeled `analytic_bound_not_simulation`.
- `original_snapshot/policy_results.csv`: independently regenerated original diagnostics, byte-identical to the supplied original CSV.
- `run_manifest.json`: final run counts, runtime, seed, environment versions, and implementation-check counts.
- `verify_release.py` and `release_verification.json`: verification of all summary means and standard errors, source provenance, artifact presence, Markdown formula delimiters, and SHA-256 fingerprints.
- `table_regret.tex`, `table_geometry.tex`, `results_paragraph.tex`, and `experiments.tex`: manuscript inputs.
- `../figures/gen_fig_experiments.py`: regeneration of all figure PDF/PNG pairs and TeX tables.

## Checks and limitations

All original geometry assertions passed on 1,715 exhaustive and 10,000 random schedules. Floating-point primal--dual gaps differ slightly from the supplied audit because the Python environment differs; they remain below the declared numerical tolerance. The original API checks completed 2,001 policy steps. The original main policy suite completed 4,105,304 steps, and its CSV is byte-identical to the supplied file. The new decision implementation was compared against the original online API on 6,168 actions, and all 48 common-prefix checks passed. The new final Bernoulli study contains 8,192 policy trajectories and 134,217,728 policy rounds. Compilation warm-up and implementation audit rounds are not included in that final study count.

The finite deterministic restart runs use segment length 65,536, rather than the theoretical exponentially growing segment length. They show repeated exploration but do not numerically prove a logarithmic-order separation. The latter follows from the manuscript proof. The analytical-bound figure is kept separate and is not inserted as empirical evidence.

The eight stochastic environments and four comparison rules do not establish universal dominance or estimate a minimax constant. Cold MOSS can have lower regret on a late-batch environment; that observation is reported in the manuscript. The plots use pointwise Monte Carlo bands, which are neither time-uniform confidence bands nor coverage estimates. These experiments do not include real data, Thompson sampling, AUER, or a parameter-tuned benchmark suite.
