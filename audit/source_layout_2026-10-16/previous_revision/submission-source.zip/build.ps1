$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    $revisionBuild = Join-Path $PSScriptRoot 'revision_2026-10-16/build'
    New-Item -ItemType Directory -Path $revisionBuild -Force | Out-Null
    # The main imports the supplement's actual labels, so build it second.
    foreach ($entry in @('supplement.tex', 'manuscript.tex')) {
        & latexmk -pdf -interaction=nonstopmode -halt-on-error '-outdir=revision_2026-10-16/build' $entry
        if ($LASTEXITCODE -ne 0) { throw "Compilation failed: $entry" }
        # Generate this build's own bibliography even if legacy root-level
        # products are present. No historical build products are deleted.
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($entry)
        & bibtex "revision_2026-10-16/build/$stem"
        if ($LASTEXITCODE -ne 0) { throw "Bibliography failed: $entry" }
        & latexmk -g -pdf -interaction=nonstopmode -halt-on-error '-outdir=revision_2026-10-16/build' $entry
        if ($LASTEXITCODE -ne 0) { throw "Compilation failed after bibliography: $entry" }
    }
    Copy-Item -LiteralPath (Join-Path $revisionBuild 'manuscript.pdf') -Destination (Join-Path $PSScriptRoot 'manuscript.pdf') -Force
    Copy-Item -LiteralPath (Join-Path $revisionBuild 'supplement.pdf') -Destination (Join-Path $PSScriptRoot 'supplement.pdf') -Force
} finally {
    Pop-Location
}
