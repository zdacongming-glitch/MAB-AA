from pathlib import Path
import pandas as pd, numpy as np
from protocol import ROOT,TEST
s=pd.read_csv(ROOT/'test-summary.csv');paired=pd.read_csv(ROOT/'paired-primary.csv')
zh={'stable':'稳定最优','improvements':'多次改善','burst':'突发到达','arrivals_stop':'到达后停止','near_boundary':'判别边界附近','near_tied_top':'多个近似并列最好臂','late_best':'后期到达强臂','low_variance':'非Bernoulli低方差','many_heterogeneous':'较多异质臂','near_upper_boundary':'奖励上边界附近'}
rows=['| 场景 | ALL+ regret | CCP regret | ALL+ 未决面积/1000 | CCP 未决面积/1000 |', '|---|---:|---:|---:|---:|']
for sc in [v['name'] for v in TEST]:
 a=s[(s.scenario==sc)&(s.method=='ALLplus-beta1')].iloc[0];c=s[(s.scenario==sc)&(s.method=='CCP-beta1')].iloc[0]
 rows.append(f'| {zh[sc]} | {a.regret_mean:.1f} | {c.regret_mean:.1f} | {a.area_mean/1000:.2f} | {c.area_mean/1000:.2f} |')
table='\n'.join(rows)
text=r'''# CCP 算法探索报告：比固定检查点更有效的证书成本规划

日期：2026-10-16。正文与补充证明、可执行代码、开发记录和独立测试数据配套交付。

## 1. 结论

本轮找到了一个比固定检查点FIFO更值得继续推进的候选：**Certificate-Cost Planning（CCP，证书成本规划）**。在没有用测试奖励流调参的10个新场景中，默认CCP与使用完全相同报告工具和收益预算的升级ALL-ε基线相比，9个场景的平均未决面积更小；5个场景的regret与面积两个点估计同时更小。对10个场景的指标均值再取平均，regret从607.16降到585.15（下降3.6%），面积从39196.51降到29731.47（下降24.1%）。这是这些预设场景上的描述，不是总体或全环境平均效率定理。

理论上完成了一个有用的区分：**固定有限探索预算的配置具有regret最优阶；无预算拒绝的配置具有最坏维护面积最优阶。**没有证明同一个配置达到完整联合最优前沿，也没有找到在所有环境和所有基线上全面占优的算法。

因此，本轮的积极结论是“得到有明确理论保护、在独立小规模测试上强于合理联合基线的新候选”，不是“已经找到最终万能算法”。

## 2. 我们改变了什么

原CP的三个有限预算限制：报告前必须等整份固定配额完成；服务不区分证书的实际困难与采样代价；按物理时钟固定FIFO，容易在昂贵或暂时无用的问题上继续投入。

CCP将这三个部件分开处理。

### 2.1 报告可以在固定检查点之前发生

每个观测后更新时间一致的beta-mixture置信序列，同时保留一个事前检查点作为有限工作量兜底。真实标签不是后验猜测：置信序列的全部bounded奖励有效性由混合超鞅和Ville不等式证明。固定检查点不再是报告启动条件。

区间给出本臂真实gap的完整可行范围：
\[
g_i^-=(\max_{j\ne i}\ell_j-u_i)_+,\qquad
g_i^+=(\max_{j\ne i}u_j-\ell_i)_+.
\]
上端点≤ε时报告近优，下端点>ε时报告非近优。其余继续未决。若整个gap范围已在[ε−η,ε+η]内，可以暂不为该臂安排主动服务，但仍然报告未决；以后到达可重新激活任务。这没有改变原来的正确性或未决面积定义。

### 2.2 不再只问“哪个区间最宽”，而是问“哪个证书值得现在完成”

对一个未完成候选i，找一个当前参照/阻碍者j。用当前观察形成规划中心m_i、半径r_i，估计这两个端点还需多少样本才能到一个足以认证或证明位于容忍带内的精度。

其代理问题是
\[
\min_{x_i\ge\bar n_i,x_j\ge\bar n_j}
 c_i(x_i-\bar n_i)+c_j(x_j-\bar n_j),\qquad
 a_i/\sqrt{x_i}+a_j/\sqrt{x_j}\le h_i,
\]
其中 \(\bar n_i=\max(1,n_i),a_i=r_i\sqrt{\bar n_i}\)。正价格保证可求解；两坐标内点解有闭式，见theory.md命题C。系统先选总代价最小的证书，再执行其中最有用的一个真实样本，然后重新规划。

关键不是公式看起来更复杂，而是：同样的剩余误差，有时适合多采一个高收益参照，有时适合少量采一个快能判清的候选，不能一律平摊。

这只是**真实统计任务的局部确定性代理**，不是已经证明的全局最优分配。多个正认证障碍、均值中心变化、未来到达等因素仍可能使代理不准。

### 2.3 用可观测的探索账本保护regret

令J_i(t)为使用全部实际样本的截断MC-MOSS指数，定义
\[
\zeta_t(i)=\max_j J_j(t)-J_i(t).
\]
这是可以实时计算的数，不是真实gap。设 \(\mathcal S_t\) 为由已经发生的到达计算的当前前缀寿命谱，预算为
\[
B_t^{\rm tax}=\beta\max_{s\le t}\mathcal S_s.
\]
一个主动认证动作只有在累计指数差账本仍不超过预算时才执行；否则选最大指数动作。本轮规划价格采用 \(c_i=\nu+\zeta_t(i)\)，默认ν=0.1。

因此，每一个偏离收益指数最大化的决定都有明确可观测的收费。便宜但有信息的观察优先，过于昂贵的精细认证会受到预算限制。

独立Temporal Geometry工作中的MC-MOSS及谱定理是既有项目输入。本轮不是重新宣称发明MOSS或寿命谱，而是推导“允许带预算偏离”的保证，并用它支持新的采样调度。

## 3. 算法执行摘要

默认参数：β=1，ν=0.1，p=2，ρ=η/4。β越大通常允许更多认证探索，但不保证每条实际轨迹单调改善。β=None是不拒绝服务的另一配置。

```text
每个物理时刻：
  接纳本轮新臂，分配标签、初始[0,1]区间和终身检查点；保留所有旧样本。
  按当前到达数量更新MC-MOSS的虚拟时钟，不重置计数。
  从置信区间计算近优、非近优、未决，以及可证实位于边界带的未决臂。
  如果仍有待处理的边界带外可能任务：
      增加busy时钟。
      每p个busy轮，按证书成本规划提出一条采样臂；其余轮选最大收益指数。
  若拟选动作的指数差使总账本超预算，则改选最大收益指数。
  只观察一个真实奖励；更新总样本数、奖励和、混合置信区间。
  达到固定检查点时再交入该检查点区间，但以后仍可用新混合区间收缩。
  重新计算全部已到达臂的报告。
  不因负标签删除收益资格；不利用未来到达或真均值。
```

完整增量接口在ccp.py，冻结比较引擎在engine.py。前者与后者在包括新臂到达的64000个动作上逐步一致。

## 4. 实際尝试过的算法路线

开发阶段不是只尝试一个UCB变体。完成3488条开发轨迹，涉及四个开发场景和四轮配置筛选，包括：固定CP；UCB、Growing-MOSS、MC-MOSS、Thompson sampling、KL-UCB收益核；最宽区间、最少计数、ST2式三角色服务；简单双端精度配额；有价和无价平滑信息进度；Monte Carlo标签信息增益；连续凸规划；共享参照折价；基于经验gap或乐观指数差的价格；累计探索预算。

开发阶段的TS或信息增益启发式没有稳定胜出，这不等于否定Thompson或IDS算法家族。标签信息方案只用了40个后验样本，并非Russo–Van Roy原版IDS；ST2式规则是明示的单步到达适配，不是FAREAST/(ST)^2的原版复现。所有开发结果保留，未只保存获胜路线。

## 5. 独立测试协议

测试前固定10类新环境、21个配置，每环境64次配对重复，总计13440条测试轨迹。每条轨迹T=16000或20000，最多23臂；9类Bernoulli、一类非Bernoulli低方差有界两点奖励。δ=0.05，其他任务参数与完整均值/到达表在protocol.json。

所有同场景同重复使用相同潜在奖励流；算法的第n次观察同一臂看到同一个潜在值，但选择时刻可以不同。政策API不接收未来日程、真均值、最终K或T。

主对照是ALLplus-beta1：与默认CCP使用相同置信序列、相同精确标签、相同边界带门控、相同检查点兜底、相同收益核、相同预算。差别主要是主动服务选择：ALL+选择未决臂及最大上界参照中的最宽区间，CCP做有价证书规划。

另有β∈{0.25,0.5,1,2}的匹配参数网格、两个无限预算配置、原式CP、前缀ALL-UCB、纯MC/TS/KL-UCB，以及关键消融。TEST后不改变算法或参数。完整Table 2旧仿真源码没有提供到当前运行环境，本轮不声称重现旧表，也不把新数值与旧表直接相减。

## 6. 默认配置的测试结果

以下为64次重复均值；完整标准误、分位数与配对区间在CSV中。ALL+和CCP均取β=1。

__TABLE__

### 结果如何解读

- 稳定环境：regret几乎相同（配对差−0.57，95%区间约[−5.03,3.89]），未决面积减少31.8%。
- 突发环境：CCP regret增加5.5%，面积减少33.3%；这是更好的部分权衡点，而不是双指标同时严格下降。
- 停止到达、边界附近、近似并列最好、较多异质臂：两个指标的均值都下降。其中近似并列最好场景，regret下降29.6%，面积下降14.9%。
- 多次改善：CCP regret增加7.3%，面积只减少1.6%，不足以称为有说服力的优势。
- 奖励上边界：默认配置面积略增0.9%，差异的配对区间跨零；在更大β或无限预算配置下，CCP面积也可以明显落后于ALL+，保留这些结果。

所有配对区间都是描述性的逐比较区间，不是对全部场景和全部方法作多重校正后的联合显著性声明。经验95%分位数只有64个重复，精度有限。

以默认β=1得到的10个均值点，在本轮冻结的有限配置集合中均未被另一单点在两指标上同时严格支配；这只描述测试网格，不能称作已知真实Pareto前沿。

### 消融告诉了我们什么

将CCP的混合置信序列换回完整Hoeffding前缀区间，10场景平均regret仍约586，但平均面积从29731升到53563。报告工具确实重要；正因为如此，主要ALL+对照也得到了同样混合置信序列，不能把这部分增益独占给调度。

删除边界带门控后，本轮所有默认配置端点指标与原配置完全相同。因此目前没有实验证据说默认优势来自这一门控。

将规划中的指数差价格换成经验gap价格，结果非常接近：平均regret581.23、面积30025.40。指数差价格的主要额外价值是与可证明预算合同一致，不是已证明其数值上必然优于经验gap。

### 没有隐藏的失败事件

未观察到错误正/负标签，但13440次配对运行中记录了69次区间未覆盖、51次空交集回退；同一潜在流在多个配置共享，所以这些事件相关。默认CCP的640条轨迹中，4条记录到区间未覆盖、3条发生全未决回退；ALLplus-beta1相同。全部保留在报告均值、面积和分位数中。零误标不等于没有统计失败，更不证明全环境有效性。

## 7. 本轮已经证明什么

详细证明见theory.md。

**A. 全过程报告可靠。** Beta-mixture超鞅与事前固定检查点各分配δ/2，总覆盖至少1−δ。界适用于独立iid[0,1]奖励，不只是Bernoulli。

**B. 可观测指数差控制regret。** 对任意合法动作规则，
\[
\mathbb ER_T\le\min\{T,300\mathcal S_T+
\mathbb E\sum_{t\le T}\zeta_t(I_t)\}.
\]
固定β的预算给出
\[
\mathbb ER_T\le\min\{T,(300+2\beta)\mathcal S_T\}.
\]
结合既有谱下界，是逐日程regret最优阶。它在报告错误路径上也成立，没有遗漏δT；不是两个算法轨迹之差的保证。常数非常保守，不是精确最优常数。

**C. 无预算拒绝时，最坏维护面积最优阶。** 每p个busy轮完成一次尚欠的检查点观察，故共同覆盖事件上
\[
\mathcal U_T(\eta)\le
\min\{K_TT,pK_T(\sum_iq_i+1)\}
=O\!\left(\min\{K_TT,pK_T^2\eta^{-2}\log(K_T/\delta)\}\right).
\]
既有最坏面积下界在规定参数范围内匹配这一阶数。此配置的regret还须支付认证成本，不自动具有固定β配置的最优阶。

**D. 有预算拒绝时，面积有可解释的诊断界。** 将上式中的工作量改为 \(\sum_iq_i+D_T+1\)，D_T为实际被拒绝的服务次数。不能省略D_T后称默认配置面积最优。有限臂到达最终停止时，有限β的预算增长可避免永久服务饥饿，但这只是较粗的最终边界外完成保证。

**E. 局部凸规划有精确解。** 其最优性仅属于冻结当前中心/半径后的代理问题，不等于对未知均值原问题的统计最优性。

## 8. 推荐的论文定位

这轮之后，有理由把CCP作为优先开发的实际候选，而不是仅把CP保守构造放在论文中。比较的进展主要是：在相同报告工具与预算下，用证书完成成本取代单纯最宽区间，独立小规模测试出现稳定的未决量改进；同时借助可观测指数差给收益保护。

不建议写“CCP是一般联合最优算法”或“优于所有ALL-ε方法”。准确定位应为：有严格可靠性及分配置的最优阶保底，局部规划启发式带来有限预算实证收益。

更强主张至少还需：标准FAREAST/(ST)^2忠实适配与更广泛强对照；更大臂集/计算开销验证；把服务拒绝或真实证书完成过程与联合信息下界连接。当前低方差测试也不证明区间已经实现方差最优适应。

本轮没有更改Codex正在整理的稿件，没有把既有Temporal Geometry理论重新算成新贡献；全部新代码、证明、失败轨迹与开发过程单独交付。
'''
(ROOT/'算法探索报告_CCP.md').write_text(text.replace('__TABLE__',table),encoding='utf8')
# Compact reviewer-facing summaries as machine-readable metadata.
cc=s[s.method=='CCP-beta1'];aa=s[s.method=='ALLplus-beta1'];cc=cc.set_index('scenario');aa=aa.set_index('scenario')
meta={'completed_development_runs':3488,'completed_test_runs':13440,'test_scenarios':10,'replications_per_scenario':64,'policy_configurations':21,
      'primary_candidate':'CCP-beta1','primary_comparator':'ALLplus-beta1','area_mean_wins':int((cc.area_mean<aa.area_mean).sum()),
      'both_mean_wins':int(((cc.area_mean<aa.area_mean)&(cc.regret_mean<aa.regret_mean)).sum()),
      'mean_of_scenario_regrets_ccp':float(cc.regret_mean.mean()),'mean_of_scenario_regrets_all':float(aa.regret_mean.mean()),
      'mean_of_scenario_areas_ccp':float(cc.area_mean.mean()),'mean_of_scenario_areas_all':float(aa.area_mean.mean()),
      'primary_label_failures':int(cc.label_failures.sum()),'primary_interval_failures':int(cc.interval_failures.sum()),'primary_empty_intersections':int(cc.empty_intersections.sum()),
      'theory_status':{'finite_beta':'schedule-minimax regret order, not full joint frontier','unlimited':'worst-schedule area order, not automatically same regret order'},
      'not_a_reproduction_of_manuscript_table_2':True,'no_post_test_tuning':True}
import json
(ROOT/'research-summary.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print('Report characters',len((ROOT/'算法探索报告_CCP.md').read_text()))
print(json.dumps(meta,ensure_ascii=False,indent=2))
