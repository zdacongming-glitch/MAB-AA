from pathlib import Path
import pandas as pd,json
R=Path(__file__).resolve().parents[1]
s=pd.read_csv(R/'results/holdout-summary.csv');p=pd.read_csv(R/'results/pure-regret-paired.csv')
order=['two_close','few_arrivals','stable','successive_improvements','burst','membership_boundary','many_close_means','late_improvement','rare_rewards','ceiling','larger_pool','bounded_low_variance']
names=dict(zip(order,['两条接近的臂','少量到达','稳定最优','多次改善','突发到达','判别边界附近','多条均值接近','后期强臂','稀有奖励','奖励上边界','较多候选','低方差有界奖励']))
cols=['UCB1','Growing-MOSS','MC-MOSS','Thompson','KL-UCB','F-R']
t=s[s.method.isin(cols)].pivot(index='scenario',columns='method',values='regret_mean').loc[order,cols];t.index=[names[x] for x in t.index]
regtable=t.to_markdown(floatfmt='.2f')
suite=s.groupby('method')[['regret_mean','area_mean','service_pulls_mean']].mean()
mods=['F-R','F-auto-0.1','F-auto-0.3','F-auto-0.6','F-auto-0.9','F-all-service-budgeted','F-area','CCP-original','ALL-auto-costmatched','ALL-area']
mode=suite.loc[mods].copy();mode['area_mean']/=1000;mode.columns=['Regret','未决面积/1000','主动服务次数'];modetable=mode.to_markdown(floatfmt='.2f')
report=r'''# F-CCP：可调收益—维护目标的 CCP 扩展

日期：2026-10-17（项目本地日期）。本轮交付包括算法、书面证明、冻结实验、负面诊断与单次创新性评价。未改动正在由 Codex 重构的论文。

## 结论先行

可以把 CCP 做成可选择收益核、可调整认证优先级和两个探索预算的家族。我们已经实现 **F-CCP（Flexible CCP）**，支持纯收益、分类优先、固定混合和数据依赖的自适应偏好。这里的 F 只是版本区分，不是依靠命名宣称新颖性。

默认纯收益候选 F-R 在本轮12个新测试环境中，11个环境的平均 regret 低于全部五个指定基线；余下两臂接近环境中，它为52.07，标准Thompson为51.37。全部60个“场景×基线”对比有59个均值更低。按场景等权平均，F-R为60.73，标准Thompson为75.43，下降19.5%。

**这不是全面零劣保证。** 只有52/60个Bonferroni校正的单侧t区间上端点小于0。宽松的预设5%+2单位非劣门槛也只通过54/60；不能把它表述成达到用户的严格全部不劣要求。F-R在若干场景的95%经验regret分位数还比Thompson差。

另一个更强但范围不同的保证确实成立：**关闭认证服务及收益投影，并选择某个基线作为收益核时，F-CCP与这个指定基线的动作、样本数和regret逐路径完全相同。** 因而添加报告工具不会额外损害该基线的采样收益；但它不会自动知道哪个基线是当前环境的最佳者。

## 1. 保持原统计任务不变

独立平稳的[0,1]奖励，臂外生到达后永久可用；算法只看当前到达和已观察历史，每轮一个实际拉取，随后报告所有已到达臂。

\[
G_t^\varepsilon=\{i\in A_t:B_t-\mu_i\le\varepsilon\},\quad
R_T=\sum_{t\le T}(B_t-\mu_{I_t}).
\]

报告(P_t,N_t,V_t)划分A_t，要求全过程所有确定标签共同正确的概率不低于1−δ。原及时性损失仍为

\[
\mathcal U_T(\eta)=\sum_{t\le T}\sum_{i\in A_t}
1\{i\in V_t,\ |B_t-\mu_i-\varepsilon|>\eta\}.
\]

所有模式在比较中使用同样的ε、η、δ；没有把目标改成期望加权和，也没有用真实未决面积在线调参。ε决定近优集合，η只豁免边界带的及时性费用，δ控制误报。三者不能为了让某一模式胜出而改变。

## 2. 算法：独立调整收益选择、服务强度和探索保护

### 2.1 首先关闭一个不该强制存在的组件

在priority=0时，证书规划彻底退出采样决策。报告层仍可利用获得的数据，但不索取任何额外样本。收益核可以选择UCB1、Growing-MOSS、MC-MOSS、Thompson或KL-UCB。

因此，纯收益端的改进不来自“更高效的证书调度”，因为该调度没有运行；它来自更合适的收益核及其保护规则。本轮默认F-R使用

\[
Z_i(t)\sim\operatorname{Beta}
\left(1+\frac{S_i}{\theta},1+\frac{N_i-S_i}{\theta}\right),
\qquad\theta=0.5.
\]

较低温度使动作评分相对更集中，但可能更早过度确信，所以它再受到虚拟MC-MOSS指数差预算保护。θ=1才是Bernoulli奖励下标准Beta(1,1) Thompson的后验。θ=0.5只是行动启发式，不把观察次数翻倍，更不改报告置信区间的真实样本数。非Bernoulli测试中的分数Beta更新也不声称是正确参数后验。

### 2.2 单个偏好参数λ控制“多大程度愿意服务认证”

λ=0完全不服务；λ=1在存在主动待办时每轮尝试服务。中间值既可以固定服务比例，也可以采用可观察的负担反馈。

从同时置信区间构造gap的精确矩形范围

\[
g_i^-=\max\{0,\max_{j\ne i}\ell_j-u_i\},\quad
g_i^+=\max\{0,\max_{j\ne i}u_j-\ell_i\}.
\]

g_i^+≤ε时正认证，g_i^−>ε时负认证，其他未决。若一个未决臂的整个gap范围已落入[ε−η,ε+η]，只暂停它的主动服务，仍报告未决。其余待办集合记W_t，b_t=|W_t|。

先由CCP规划提出一个认证动作j_t，以区间内的规划中心m_i估计它的采样代价

\[
\widehat c_t=\max_i m_i-m_{j_t}.
\]

采用本轮预设控制器

\[
w_t=0.02+0.98\frac{b_t}{b_t+4}
\frac{\varepsilon}{\varepsilon+\widehat c_t},\qquad
p_t=\frac{\lambda w_t}{1-\lambda+\lambda w_t}
\quad(W_t\ne\varnothing).
\]

W_t为空时p_t=0。p_t通过相位累积器执行，不增加每轮样本量。

这样，待办较少或服务臂收益损失较高时更偏重收益；待办多且服务便宜时更偏重分类。**这不等于根据真实gap作了最优控制。** λ与价格均可基于过去可预测地改变，而报告证据仍保持同一个错误控制。

“全部均值接近”也不等于“靠近ε判别边界”。前者通常使一次服务的regret小，后者才可能造成极高的资格辨别成本。控制器不假装知道这两种真实状态。

### 2.3 两个账本，避免收益探索占满认证额度

虚拟截断MC-MOSS指数使用实际终身计数和已发生到达；定义

\[
\zeta_t(i)=\max_jJ_j(t)-J_i(t)\in[0,1].
\]

分别累计实际收益轮和实际服务轮的指数差：

\[
C_R(t)=\sum_{u\le t:\,R\text{轮}}\zeta_u(I_u),\quad
C_C(t)=\sum_{u\le t:\,C\text{轮}}\zeta_u(I_u).
\]

两者分别受β_R\bar S_t与β_C\bar S_t限制，\bar S_t是仅由当前及历史到达计算的running prefix spectrum。**ζ不是实际regret，更不是两条独立算法轨迹的收益差。**

服务动作超出C账本则退回收益轮；收益轮在R账本可行的臂里选择当前随机/确定收益评分最大者。最大虚拟指数臂的ζ=0，总能作为合法备选。无论拒绝几次提议，物理时刻只观察最后动作的一个奖励。

旧CCP的非服务动作总是最大MC指数，因而不消耗ζ。Thompson等新收益核没有这一性质，故不能原封不动沿用旧的“总付费次数有界、认证终将得到服务”推理。本轮用独立C账本保留这个接口；未证明双账本是唯一必要方法。

### 2.4 四个可直接使用的预设

| 模式 | λ | 控制 | β_R | β_C | 默认收益核 |
|---|---:|---|---:|---:|---|
| F-R：纯收益候选 | 0 | 无服务 | 16 | 0 | θ=0.5的受保护Beta评分 |
| 均衡自适应 | 0.6 | 待办/代价反馈 | 16 | 1 | 同上 |
| 分类优先 | 1 | 每忙轮服务 | 16 | ∞ | 无待办时才转收益 |
| 指定基线兼容 | 0 | 无服务、无投影 | ∞ | 0 | 用户事前选择的原基线 |

还提供λ=0.1、0.3、0.9等配置。增大λ一般会提高服务意愿，但预算拒绝和不同随机轨迹使实际regret/面积不保证逐路径单调。设置λ=1却继续限制很小的β_C，不等于开放的分类优先端点。

## 3. 本轮理论结论

完整证明与假设见`theory.md`，旧输入依赖见`dependencies/ccp_theory_20261016.md`。

### 3.1 全过程报告可靠

混合置信序列加事前固定检查点共享δ预算，在任意可预测模式切换下

\[
\Pr(E_{\mathrm{lab}})\ge1-\delta.
\]

所有模式用实际样本完成报告；冷温度评分不参与置信校准。

### 3.2 与指定基线完全等价的端点

从实验开始λ=0且β_R=∞，相同收益核、状态和随机源下

\[
I_t^{F}=I_t^{\mathrm{base}},\quad R_T^F=R_T^{\mathrm{base}}
\qquad\text{对全部}t,T.
\]

这是由归纳直接得到的路径性质。若以前已经额外采过服务样本，后来切为λ=0，只表示以后停止主动服务，不会把历史变成一个从头独立运行的基线。

### 3.3 任意收益核的双预算保护

由旧CCP的任意动作指数差界和\bar S_T≤2S_T，得到

\[
\boxed{\mathbb ER_T\le
\min\{T,(300+2\beta_R+2\beta_C)S_T\}.}
\]

纯收益关闭服务后可去掉β_C，默认F-R得到min{T,332S_T}。有限常数β的这些模式保持已有逐日程minimax regret阶数，但不是精确常数或逐实例最优。

分类预算无限时，以实际服务工作量Q_T=Σ_iq_i支付：

\[
\mathbb ER_T\le\min\{T,(300+2\beta_R)S_T+Q_T\}.
\]

该界不条件于报告正确事件，未遗漏δT成本。

### 3.4 未决量的可变服务率保证

固定λ>0的自适应模式在每个忙轮都有

\[
p_t\ge p_{\min}=\frac{.02\lambda}{1-\lambda+.02\lambda}>0.
\]

令D_T是认证预算拒绝次数，则共同覆盖事件上

\[
\boxed{\mathcal U_T(\eta)\le
K_T\min\{T,(Q_T+D_T+1)/p_{\min}\}.}
\]

分类优先模式p_min=1、D_T=0，从而得到已有最坏面积阶数

\[
O\!\left(\min\{K_TT,K_T^2\eta^{-2}\log(K_T/\delta)\}\right).
\]

相应匹配只在原下界列明的参数范围内使用。它不证明每个实例上比所有识别算法都快。

独立认证账本还给出有限臂、最终停止到达时的非永久饥饿：当β_C>0且p_min>0，E上边界带外未决最终消失；一个显式但很松的面积包络是

\[
K_T\min\!\left\{T,
\left\lceil(Q_T/\beta_C)^2\right\rceil+1+
(Q_T+1)/p_{\min}\right\}.
\]

这不是无条件几乎必然精确集合恢复。

### 3.5 为什么不能保证一个未知环境算法零余项胜过所有基线

两条初始臂、T=1即可说明。MC-MOSS按固定编号先选臂1，标准对称Thompson先各以1/2概率选臂。任何未知均值策略设首轮选臂1概率p：

- 在(3/4,1/4)下，比最好基线多损失(1−p)/2；
- 在(1/4,3/4)下，比最好基线多损失p/2−1/4。

二者最大值对p的最小值为1/8。因此“每环境每终点同时不差于每个基线、零附加代价”的要求不可能成立。它不否定本轮均值改善或更合理的带附加项算法选择。

## 4. 实验：纯收益端重点比较

开发三轮共14,016条有效轨迹；随后冻结12个新测试实例和24配置，每配置每场景96个配对重复，共27,648条测试轨迹。每个终点12,000–16,000，最终2–20条臂。另有对照实现修正后的1,152条补跑，不改变F-CCP或纯收益基线。

测试和开发分开，但两边都包含稳定、改善、边界等任务类型；不能把它说成对任意未知任务分布的保证。每次测试共同随机置换批内均值标签并共享潜在奖励前缀。所有方法保持自己的采样决策，收益基线没有被强制插入认证服务。UCB主表采用标准UCB1，另保留较保守UCB实现。

### 4.1 五个指定基线与F-R的全部场景均值

@@REGTABLE@@

12个场景的等权均值分别为UCB1 343.18、Growing-MOSS 113.95、MC-MOSS 102.51、Thompson 75.43、KL-UCB 150.74、F-R 60.73。不同场景T和任务参数不同，所以这种等权汇总只是描述性比较，不是共同分布风险或minimax估计。

F-R对全部五个基线的均值在11个场景都更低；two_close对Thompson略高0.70（1.37%），配对95%区间约[−5.28,6.68]。这不支持宣称它更差，也不支持在零容忍要求下断言它不差。

60个配对比较中59个点估计更低；Bonferroni校正的单侧t区间只有52个上端点小于0。预设宽松5%+2单位门槛通过54个，不把这个门槛偷换成用户严格要求。

### 4.2 尾部风险不能隐藏

平均regret下降不等于风险分布整体更好。burst场景F-R/Thompson的95%经验分位数为208.89/123.07，ceiling为90.94/48.97，larger_pool为237.30/184.18。受保护冷温度版本依然可能更容易经历早期错误确信。

报告中的理论是期望regret最优阶，不是对这些分位数的优势定理。若更看重稳定的Thompson行为，可直接选择θ=1、β_R=∞的兼容模式，不需要为了保留算法名称强行承担冷温度风险。

### 4.3 纯收益兼容模式的实测确认

主测试中F-R-TS-exact与Thompson的1,152对全部端点指标完全一致；另有交互API与五个独立维护状态的基线共50,000轮逐动作、逐计数检查通过。等价保证来自理论，不以数值一致代替证明。

## 5. 改变目标偏好后的权衡

下表仍是12场景等权均值。β_R=16；除注明分类优先外，F的中间配置β_C=1。

@@MODETABLE@@

λ从0调到0.1、0.3、0.6、0.9，平均主动认证次数提高，regret与面积沿不同成本点变化；分类优先打开认证预算后，平均regret升到1,210.02，而面积降到27,121。**不是免费改善两个目标，而是用户可以明确选择牺牲什么。**

F-area在本轮全部测试配置中有11场景的平均面积最低或并列最低，rare_rewards则与λ=.9几乎相同但略高。two_close与rare_rewards的面积即使在分类模式仍接近全未决状态的上限：边界很难时，有限预算不能承诺快速完成。

对公平修正后的ALL-auto-costmatched，F-auto-.6的平均regret降低9.8%、面积降低13.7%；分类优先F-area对ALL-area分别降低23.5%、26.3%。这些是明确自然适配与预设配置上的结果，不是优于全部ALL-ε方法或原版FAREAST/(ST)^2。

相对旧CCP-original，F-auto-.6平均regret降低10.7%，面积上升5.4%，说明它处在更偏收益的一点，不应写成全面支配旧版。

自动偏好也有直接诊断：λ=.6时，few_arrivals的忙轮平均提议服务率为.213，many_close_means为.422。这符合“少量待办偏收益、较多且便宜待办偏认证”的设计；但不是最优适应定理。

## 6. 失败、实现修正和比较范围

本轮不是全部零错误。F-auto-.6有1/1,152轨迹出现错误确定标签，F-R与F-area为0；三者置信覆盖失败数分别为7、6、8，空交集分别为1、1、0。所有这些轨迹均计入成绩，不能因为报告回退全未决就删除它们。

审计发现，初始ALL自适应对照的服务函数将经验代价返回为0，导致控制率并非相同的成本敏感规则。于是只修正该输入，冻结后补跑1,152条同样测试；原数据保留但不用作主调度优势证据。F-CCP、五个纯收益基线和ALL-area均不受此修正影响。

精确算术相位与浮点实现存在整数边界晚一个服务槽的细微差异；全部检查与保留说明见audit.md。Numba与交互API的随机数后端不同，不能声称相同seed跨后端逐动作一致。

只检验了小臂数和中等终点，没有验证千臂计算效率、完整Pareto前沿或所有环境支配。算法直接实现每轮有O(K_t^2)的报告/证书扫描，不主张计算最优。

## 7. 创新性评价（仅本轮新增F-CCP）

读取了用户指定仓库的创新性标准。实际完成当前上下文单次判断，未完成五轮隔离上下文重复，不报告方差或伪造独立执行标识。

**总体：第三级，3.8/10；深入适配与组合。** 这评价的是本輪调参、收益核接口、双账本与新实验，不是对已经形成的整篇集合维护理论打3.8分，也不是对尚未读取的Codex改稿评分。

| 新增内容 | 评分 | 原因 |
|---|---:|---|
| 指定基线兼容端点 | 2.0 | 关闭附加采样后的直接归纳性质 |
| 待办数与经验服务代价控制率 | 3.1 | 实用且可预测，未证明其选择原则最优 |
| 双账本与任意收益核的保护/服务接口 | 3.8 | 修复旧零税收益核前提不适用的组合问题，但主要界是旧任意动作定理的推论 |
| 温度TS+投影的纯收益配置 | 3.5 | 有独立测试优势，但随机评分、限制探索已有近邻；非全实例优势 |
| 两臂零余项不可能性 | 2.0 | 澄清要求的简洁诊断，而非新的普遍下界原理 |

为什么不直接给第二级5–6分：本轮没有新的紧联合复杂度、匹配前沿或实质的新统计最优分配原理。调参接口和良好实验增强文章的方法可用性，却不能靠组件数量跨过4.0门槛。后续若能给出相对强基线的非平凡自适应代价界，或同任务下新的实例效率机制，则需重新评价。

最近邻原始文献核查范围为正式摘要与明确方法定位，不声称逐项审计其全部证明：

1. Jin, Xu, Shi, Xiao, Gu (2021), MOTS: Minimax Optimal Thompson Sampling. ICML/PMLR 139. 随机评分的截断与minimax保证已有；本轮不是MOTS原版实现。 https://proceedings.mlr.press/v139/jin21d.html
2. Wu, Shariff, Lattimore, Szepesvári (2016), Conservative Bandits. ICML/PMLR 48. 预算式安全探索已有；本文ζ预算不等于其真实收益基线约束。 https://proceedings.mlr.press/v48/wu16.html
3. Agarwal, Luo, Neyshabur, Schapire (2017), Corralling a Band of Bandit Algorithms. COLT/PMLR 65. 学习器聚合需要处理反馈不足和附加代价；本轮未实现一个无代价的最佳基线选择器。 https://proceedings.mlr.press/v65/agarwal17b.html
4. Degenne, Nedelec, Calauzenes, Perchet (2019), Bridging the gap between regret minimization and best arm identification. AISTATS/PMLR 89. 收益与识别时间可调权衡已有。 https://proceedings.mlr.press/v89/degenne19a.html
5. Cho, Meier, Gan, Kallus (2025), Reward Maximization for Pure Exploration. AISTATS/PMLR 258. 收益核与anytime认证结合已有；其固定阈值目标与本文持续相对集合不同。 https://proceedings.mlr.press/v258/cho25a.html
6. Garivier, Cappé (2011), The KL-UCB Algorithm for Bounded Stochastic Bandits and Beyond. COLT/PMLR 19. 基线方法来源；本文是其全历史到达适配，不据此沿用全部静态定理。 https://proceedings.mlr.press/v19/garivier11a.html

## 8. 对论文的使用建议

把F-CCP作为CCP的统一参数化接口。保留两个不同用途的纯收益选择：需要原基线行为的兼容模式，以及本轮均值更好但尾部更重的受保护冷温度候选。分类优先和中间自适应模式维持同一报告目标，不改ε/η偷换任务。

正文可以展示明确的偏好—代价曲线与默认值的独立验证，但不写“无需调参就全环境最佳”“纯收益全面不劣”“完整最优前沿已得到”。本轮方法是已有理论主线的可用性增强，不应替代原有共同认证成本与临时任务权衡作为整篇创新来源。
'''
report=report.replace('@@REGTABLE@@',regtable).replace('@@MODETABLE@@',modetable)
(R/'研究报告_FCCP可调版本.md').write_text(report)
print('wrote',len(report),'characters')
